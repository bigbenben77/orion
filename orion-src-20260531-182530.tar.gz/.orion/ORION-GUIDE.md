# Orion 实战上手教程

> 你不是在学一个工具，是在学一套"怎么让 AI 帮你干活"的方法论

---

## 一句话说清 Orion 是什么

> Orion = 任务清单 (Task Master) + AI 执行引擎 (Claude Code) + 安全阀 (Shield) + 技能库 (Skills)
> 但你不是"用 Orion"，而是"Orion 管着你的项目和 AI"

---

## 典型工作流（日常使用）

### 👤 手动模式（白天，你在电脑前）

```
1. orion web                            → 打开 Web UI
2. 点"创建任务"，输入"给用户列表加搜索功能"
   → Orion 自动匹配"REST API 端点"技能
   → 自动拆解成 4 个子任务（schema/handler/route/test）
3. 点"开始"让 AI 执行第一个子任务
   → AI 写代码
   → 测试失败 → Shield 弹出断点通知栏
   → 你看一眼错误，点"批准继续"或"需要修改"
4. 任务完成后，双击任务卡片 → 输入技能名称
   → Orion 自动从执行记录生成可复用的技能
5. 继续下一个任务...

你的角色: 审批者 + 方向指示者
AI 的角色: 执行者 + 建议者
```

### ⚡ 自动模式（晚上，你不在）

```bash
orion auto --enable    # 一键开启全自动
```

```
AI 执行任务:
  → 测试失败 → 自动重试（最多 3 次）
  → 仍然失败 → 自动切换方案继续
  → 仍然不行 → 在 tasks.json 里标记 blocked
  → 下一个任务继续...
  
你第二天早上来看:
  orion status         # 看完成进度
  orion task blocked   # 看卡在哪
  orion checkpoint list # 看 AI 自动处理了哪些断点
```

---

## 三个实战场景

### 场景 1：新项目开工（从上到下的规划）

```bash
# 1. 先做规划（不写代码，只建任务树）
orion task create "用户认证系统" -p critical -t "auth"
orion task create "注册/登录 API" -D "task-1" -t "api"
orion task create "JWT 中间件" -D "task-2" -t "api,security"
orion task create "密码重置" -D "task-2" -t "api,email"
orion task create "个人中心页面" -D "task-2" -t "frontend"
orion task create "前端登录页" -D "task-2" -t "frontend"

# 2. 看依赖图（确定执行顺序）
orion task ready      # 显示 task-1（无依赖，先做）
orion task blocked    # 显示哪些在等什么

# 3. 逐个执行
orion execute task task-1 --provider local  # 先本地看计划
orion execute task task-1 --provider anthropic-api  # 有 API key 就全自动

# 4. 更新状态
orion task status task-1 --set done
orion task ready  # 看现在谁可以做了
```

### 场景 2：修 Bug（从下到上的执行）

```bash
# 1. 创建一个 bug 修复任务
orion task create "登录页白屏" -p critical -t "bug,frontend" -f "src/pages/login.tsx"

# 2. Orion 自动匹配"Bug 修复工作流"技能
#    拆解为: 复现 → 写测试 → 修复 → 验证

# 3. 让 AI 执行
orion execute task task-7 --provider claude-code

# 4. AI 执行流程:
#    → 读 login.tsx → 发现错误原因
#    → 写测试用例（测试应该失败）
#    → 修复代码（测试通过）
#    → 运行完整测试套件 → Shield 验证
#    → 标记 done

# 5. 顺便学个技能
#    → 双击 Web UI 任务卡片 → "保存为技能: React 白屏修复"
#    → 下次同样问题直接复用
```

### 场景 3：长期项目维护（技能积累）

```
Week 1: 你手动做了 10 个任务
        → Orion 学会了 3 个技能

Week 2: AI 自动执行 30 个任务
        你只需要处理 5 个断点
        → Orion 又学会了 5 个技能

Week 3: 技能库达到 12 个
        80% 的常见工作 AI 能全自动完成
        你只处理真正复杂的决策
```

---

## 和现有工具配合

### 如果你用 VS Code / Cursor

```bash
# 一个终端跑 Orion，另一个编辑器写代码
orion web   # Web UI 在浏览器里
orion mcp   # MCP Server 让编辑器插件可以调用
```

边写代码边看 Orion 的任务看板，完成后双击自动学习技能。

### 如果你用 Claude Code

```bash
# 终端 1: Orion Web UI
orion web

# 终端 2: Claude Code 执行任务（通过 MCP）
claude "看 .orion/tasks.json 里第一个 ready 任务是什么，
        然后执行它，完成后更新任务状态为 done"
```

### 如果你只用 CLI

```bash
# 一切在终端完成
orion task create "..." -p high -t "..."
orion task list
orion task status task-1 --set in-progress
orion task status task-1 --set done
```

---

## 最常用的 5 个命令

```bash
orion web              # 打开 Web 界面（首选！）
orion task create ...  # 创建任务
orion task list        # 看所有任务
orion auto             # 切换自动模式
orion checkpoint list  # 看 AI 在哪等你决定
```

---

## 一句话总结

> **别把 Orion 当工具学，把它当你的 AI 项目经理用。你定方向（创建任务），AI 干活（执行），Shield 看门（防循环），技能库积累（越用越聪明）。** 😊
