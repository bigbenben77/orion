// Orion — Shield 保护层
// 循环检测 + 失败阈值管理 + 人类断点

import type { ActionRecord, DetectedPattern, LoopResponse, FailureThresholdConfig, HumanCheckpointConfig, ShieldConfig, PermissionConfig, PermissionCheckResult, PermissionLevel, PermissionMode } from '../types/shield.js'
import { getPermissionLevel, checkPermissionByMode } from '../types/shield.js'
import type { Task, TaskAttempt } from '../types/task.js'
import type { CheckpointReason, CheckpointMode } from '../types/checkpoint.js'

const DEFAULT_CONFIG: ShieldConfig = {
  enabled: true,
  loopDetection: {
    enabled: true,
    historySize: 100,
    warningThreshold: 40,
    criticalThreshold: 80,
  },
  failureThreshold: {
    maxToolCallsPerTask: 50,
    maxRetriesPerAction: 3,
    maxConsecutiveFailures: 5,
    maxDurationMs: 30 * 60 * 1000, // 30 分钟
  },
  humanCheckpoints: {
    triggers: {
      onTaskComplete: false,
      onTestFailure: true,
      onNewFileCreation: false,
      onThresholdReached: true,
    },
    mode: 'suggest-and-continue',
    channel: 'terminal',
  },
  permissions: {
    mode: 'normal',
    rules: {},
  },
  agentLimits: {
    maxIterations: 100,
    maxContextRestarts: 5,
    contextThreshold: 0.6,
    wrapUpAtContext: 0.45,
  },
}

export class Shield {
  private config: ShieldConfig
  private history: ActionRecord[] = []
  private taskFailures: Map<string, number> = new Map()

  constructor(config?: Partial<ShieldConfig>) {
    this.config = this.mergeConfig(DEFAULT_CONFIG, config || {})
  }

  private mergeConfig(base: ShieldConfig, override: Partial<ShieldConfig>): ShieldConfig {
    return {
      ...base,
      ...override,
      loopDetection: { ...base.loopDetection, ...(override.loopDetection || {}) },
      failureThreshold: { ...base.failureThreshold, ...(override.failureThreshold || {}) },
      humanCheckpoints: { ...base.humanCheckpoints, ...(override.humanCheckpoints || {}) },
      agentLimits: { ...base.agentLimits, ...(override.agentLimits || {}) },
    }
  }

  getConfig(): ShieldConfig {
    return this.config
  }

  updateConfig(updates: Partial<ShieldConfig>): void {
    this.config = this.mergeConfig(this.config, updates)
  }

  // ===== 循环检测 =====

  recordAction(action: ActionRecord): void {
    this.history.push(action)
    if (this.history.length > this.config.loopDetection.historySize) {
      this.history.shift()
    }
  }

  detectLoop(): LoopResponse | null {
    if (!this.config.loopDetection.enabled) return null
    const patterns = this.analyzePatterns()
    return this.evaluatePatterns(patterns)
  }

  private analyzePatterns(): DetectedPattern[] {
    const patterns: DetectedPattern[] = []
    const window = Math.max(20, Math.floor(this.config.loopDetection.historySize / 2))
    const recent = this.history.slice(-window)

    // 1. 同一工具重复
    const toolCounts = new Map<string, number>()
    for (const a of recent) {
      toolCounts.set(a.tool, (toolCounts.get(a.tool) || 0) + 1)
    }
    for (const [tool, count] of toolCounts) {
      if (count >= this.config.loopDetection.warningThreshold) {
        patterns.push({
          type: 'same-tool-repeat',
          count,
          threshold: this.config.loopDetection.warningThreshold,
          details: `${tool} 被调用了 ${count} 次`,
        })
      }
    }

    // 2. 同文件反复修改
    const fileMods = new Map<string, number>()
    for (const a of recent) {
      if (a.file && (a.tool === 'write' || a.tool === 'edit')) {
        fileMods.set(a.file, (fileMods.get(a.file) || 0) + 1)
      }
    }
    for (const [file, count] of fileMods) {
      if (count >= this.config.loopDetection.warningThreshold) {
        patterns.push({
          type: 'file-churn',
          count,
          threshold: this.config.loopDetection.warningThreshold,
          details: `${file} 被修改了 ${count} 次`,
        })
      }
    }

    // 3. 连续失败
    let consecutiveFailures = 0
    for (let i = recent.length - 1; i >= 0; i--) {
      if (recent[i].result === 'failure') consecutiveFailures++
      else break
    }
    if (consecutiveFailures >= this.config.loopDetection.warningThreshold) {
      patterns.push({
        type: 'fix-fail-cycle',
        count: consecutiveFailures,
        threshold: this.config.loopDetection.warningThreshold,
        details: `连续 ${consecutiveFailures} 次失败`,
      })
    }

    return patterns
  }

  private evaluatePatterns(patterns: DetectedPattern[]): LoopResponse | null {
    if (patterns.length === 0) return null

    const worst = patterns.reduce((a, b) =>
      a.count / a.threshold > b.count / b.threshold ? a : b
    )

    const ratio = worst.count / worst.threshold
    if (ratio >= 2) {
      return {
        level: 'critical',
        action: 'stop-and-wait',
        message: `⚠️ 检测到严重循环: ${worst.details}`,
        question: '是否停止当前任务并等待人工介入？',
      }
    }
    if (ratio >= 1) {
      return {
        level: 'escalate',
        action: 'pause-and-ask',
        message: `⚠️ 检测到循环模式: ${worst.details}`,
        question: '是否继续自动执行，或暂停等待指导？',
      }
    }
    return {
      level: 'warn',
      action: 'notify',
      message: `⚠️ 注意: ${worst.details}`,
    }
  }

  // ===== 失败阈值 =====

  checkFailureThreshold(task: Task): 'ok' | 'retry-limit' | 'consecutive-failures' | 'duration-exceeded' {
    const ft = this.config.failureThreshold

    // 检查重试次数
    if (task.attempts.length >= task.maxRetries) return 'retry-limit'

    // 检查连续失败
    const recentFailures = task.attempts.slice(-ft.maxConsecutiveFailures)
      .filter(a => a.result === 'failure').length
    if (recentFailures >= ft.maxConsecutiveFailures) return 'consecutive-failures'

    // 检查执行时长
    if (task.attempts.length > 0) {
      const firstAttempt = task.attempts[0]
      if (firstAttempt && (Date.now() - firstAttempt.timestamp) >= ft.maxDurationMs) {
        return 'duration-exceeded'
      }
    }

    return 'ok'
  }

  /** 将 Shield 检测结果转换为 Checkpoint 原因 */
  thresholdToCheckpointReason(
    result: 'ok' | 'retry-limit' | 'consecutive-failures' | 'duration-exceeded'
  ): CheckpointReason | null {
    switch (result) {
      case 'retry-limit': return 'threshold-reached'
      case 'consecutive-failures': return 'threshold-reached'
      case 'duration-exceeded': return 'context-too-large'
      default: return null
    }
  }

  loopToCheckpointReason(loop: LoopResponse): CheckpointReason | null {
    switch (loop.level) {
      case 'critical': return 'loop-detected'
      case 'escalate': return 'loop-detected'
      default: return null
    }
  }

  loopToCheckpointMode(loop: LoopResponse): CheckpointMode {
    switch (loop.action) {
      case 'stop-and-wait': return 'wait-for-approval'
      case 'pause-and-ask': return 'suggest-and-continue'
      default: return 'notify'
    }
  }

  thresholdToCheckpointMode(
    result: 'ok' | 'retry-limit' | 'consecutive-failures' | 'duration-exceeded'
  ): CheckpointMode {
    return result === 'retry-limit' ? 'wait-for-approval' : 'suggest-and-continue'
  }

  // ===== 人类断点 =====

  // ===== 权限检查 =====

  getPermissionConfig(): PermissionConfig {
    return this.config.permissions
  }

  setPermissionMode(mode: PermissionMode): void {
    this.config.permissions.mode = mode
  }

  setToolPermission(tool: string, level: PermissionLevel): void {
    this.config.permissions.rules[tool] = level
  }

  checkPermission(tool: string): PermissionCheckResult {
    const level = getPermissionLevel(tool, this.config.permissions)
    return checkPermissionByMode(level, this.config.permissions.mode)
  }

  shouldPauseForHuman(task: Task, event: string): boolean {
    const hc = this.config.humanCheckpoints
    switch (event) {
      case 'task-complete': return hc.triggers.onTaskComplete
      case 'test-failure': return hc.triggers.onTestFailure
      case 'new-file': return hc.triggers.onNewFileCreation
      case 'threshold': return hc.triggers.onThresholdReached
      default: return false
    }
  }

  formatCheckpointMessage(task: Task, event: string, details?: string): string {
    const mode = this.config.humanCheckpoints.mode
    const modeLabel =
      mode === 'wait-for-approval' ? '【需要确认】' :
      mode === 'suggest-and-continue' ? '【建议已生成】' :
      '【通知】'

    return [
      `\n${modeLabel} 任务 [${task.id}] ${task.title}`,
      `  事件: ${event}`,
      details ? `  详情: ${details}` : '',
      mode === 'wait-for-approval' ? '  等待你的确认...' : '',
    ].filter(Boolean).join('\n')
  }
}
