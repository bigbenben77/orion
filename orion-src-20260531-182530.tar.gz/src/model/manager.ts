// Orion — 模型管理器
// 让用户方便地切换大模型，不用记环境变量

import { readFileSync, writeFileSync, existsSync, mkdirSync } from 'node:fs'
import { join, dirname } from 'node:path'

export interface ProviderConfig {
  type: 'local' | 'anthropic-api' | 'openai-api' | 'claude-code' | 'openai-compatible'
  name: string
  model: string
  apiKey?: string
  baseUrl?: string
  timeoutMs?: number
  maxContextTokens?: number
  maxConcurrency?: number  // 该模型允许多少个任务同时运行
}

const DEFAULTS_VERSION = 2

interface ModelStore {
  version: string
  activeProvider: string
  providers: Record<string, ProviderConfig>
  defaultsVersion?: number
}

const DEFAULT_PROVIDERS: Record<string, ProviderConfig> = {
  local: {
    type: 'local',
    name: '本地执行（仅生成计划）',
    model: 'none',
    timeoutMs: 10000,
    maxConcurrency: 99,
  },
  deepseek: {
    type: 'openai-compatible',
    name: 'DeepSeek V4',
    model: 'deepseek/deepseek-v4-flash',
    baseUrl: 'https://api.openai.com/v1',
    apiKey: '',
    timeoutMs: 120000,
    maxContextTokens: 128_000,
    maxConcurrency: 2,
  },
  'claude-sonnet': {
    type: 'anthropic-api',
    name: 'Claude Sonnet 4',
    model: 'claude-sonnet-4-20250514',
    apiKey: '',
    timeoutMs: 120000,
    maxContextTokens: 200_000,
    maxConcurrency: 2,
  },
  'gpt-4o': {
    type: 'openai-api',
    name: 'GPT-4o',
    model: 'gpt-4o',
    apiKey: '',
    timeoutMs: 120000,
    maxContextTokens: 128_000,
    maxConcurrency: 3,
  },
  'deepseek-chat': {
    type: 'openai-compatible',
    name: 'DeepSeek 原生',
    model: 'deepseek-chat',
    baseUrl: 'https://api.deepseek.com/v1',
    apiKey: '',
    timeoutMs: 120000,
    maxContextTokens: 128_000,
    maxConcurrency: 2,
  },
  'qwen-coder': {
    type: 'openai-compatible',
    name: '通义千问 Qwen',
    model: 'qwen-plus',
    baseUrl: 'https://dashscope.aliyuncs.com/compatible-mode/v1',
    apiKey: '',
    timeoutMs: 120000,
    maxContextTokens: 128_000,
    maxConcurrency: 3,
  },
  'ollama': {
    type: 'openai-compatible',
    name: 'Ollama 本地',
    model: 'qwen2.5-coder:14b',
    baseUrl: 'http://localhost:11434/v1',
    apiKey: 'ollama',
    timeoutMs: 300000,
    maxContextTokens: 128_000,
    maxConcurrency: 10,
  },
  'lmstudio': {
    type: 'openai-compatible',
    name: 'LM Studio 本地',
    model: 'local-model',
    baseUrl: 'http://localhost:1234/v1',
    apiKey: 'lm-studio',
    timeoutMs: 300000,
    maxContextTokens: 128_000,
    maxConcurrency: 10,
  },
  'kimi': {
    type: 'openai-compatible',
    name: 'Kimi (Moonshot)',
    model: 'moonshot-v1-8k',
    baseUrl: 'https://api.moonshot.cn/v1',
    apiKey: '',
    timeoutMs: 120000,
    maxContextTokens: 128_000,
    maxConcurrency: 2,
  },
  'minimax': {
    type: 'openai-compatible',
    name: 'MiniMax',
    model: 'abab6.5s-chat',
    baseUrl: 'https://api.minimax.chat/v1',
    apiKey: '',
    timeoutMs: 120000,
    maxContextTokens: 256_000,
    maxConcurrency: 2,
  },
  'zhipu': {
    type: 'openai-compatible',
    name: '智谱 GLM',
    model: 'glm-4-flash',
    baseUrl: 'https://open.bigmodel.cn/api/paas/v4',
    apiKey: '',
    timeoutMs: 120000,
    maxContextTokens: 128_000,
    maxConcurrency: 2,
  },
  'doubao': {
    type: 'openai-compatible',
    name: '豆包 (火山引擎)',
    model: 'doubao-1.5-pro-32k',
    baseUrl: 'https://ark.cn-beijing.volces.com/api/v3',
    apiKey: '',
    timeoutMs: 120000,
    maxContextTokens: 128_000,
    maxConcurrency: 2,
  },
}

export class ModelManager {
  private store: ModelStore
  private configPath: string

  constructor(projectRoot?: string) {
    const root = projectRoot || process.cwd()
    this.configPath = join(root, '.orion', 'config.json')
    this.store = this.loadStore()
  }

  private loadStore(): ModelStore {
    try {
      if (existsSync(this.configPath)) {
        const raw = readFileSync(this.configPath, 'utf-8')
        const parsed = JSON.parse(raw) as ModelStore

        // 仅在 defaultsVersion 升级时合并新增的默认 provider，不恢复已删除的
        if ((parsed.defaultsVersion || 0) < DEFAULTS_VERSION) {
          for (const [key, def] of Object.entries(DEFAULT_PROVIDERS)) {
            if (!parsed.providers[key]) {
              parsed.providers[key] = def
            }
          }
          parsed.defaultsVersion = DEFAULTS_VERSION
        }
        return parsed
      }
    } catch { /* fall through */ }
    return this.createDefault()
  }

  private createDefault(): ModelStore {
    return {
      version: '1.0.0',
      activeProvider: 'local',
      providers: { ...DEFAULT_PROVIDERS },
      defaultsVersion: DEFAULTS_VERSION,
    }
  }

  private save(): void {
    const dir = dirname(this.configPath)
    if (!existsSync(dir)) mkdirSync(dir, { recursive: true })
    writeFileSync(this.configPath, JSON.stringify(this.store, null, 2), 'utf-8')
  }

  // ===== 查询 =====

  listProviders(): { id: string; config: ProviderConfig; active: boolean }[] {
    return Object.entries(this.store.providers).map(([id, config]) => ({
      id,
      config,
      active: id === this.store.activeProvider,
    }))
  }

  getActiveProvider(): { id: string; config: ProviderConfig } | null {
    const config = this.store.providers[this.store.activeProvider]
    if (!config) return null
    return { id: this.store.activeProvider, config }
  }

  getProvider(id: string): ProviderConfig | undefined {
    return this.store.providers[id]
  }

  // ===== 切换 =====

  switchProvider(id: string): boolean {
    if (!this.store.providers[id]) return false
    this.store.activeProvider = id
    this.save()
    return true
  }

  // ===== 配置 =====

  setApiKey(providerId: string, apiKey: string): boolean {
    const provider = this.store.providers[providerId]
    if (!provider) return false
    provider.apiKey = apiKey
    this.save()
    return true
  }

  setModel(providerId: string, model: string): boolean {
    const provider = this.store.providers[providerId]
    if (!provider) return false
    provider.model = model
    this.save()
    return true
  }

  setBaseUrl(providerId: string, baseUrl: string): boolean {
    const provider = this.store.providers[providerId]
    if (!provider) return false
    provider.baseUrl = baseUrl
    this.save()
    return true
  }

  addCustomProvider(id: string, config: ProviderConfig): boolean {
    if (this.store.providers[id]) return false
    this.store.providers[id] = config
    this.save()
    return true
  }

  removeProvider(id: string): boolean {
    if (id === 'local') return false // 不能删除默认
    if (!this.store.providers[id]) return false
    delete this.store.providers[id]
    if (this.store.activeProvider === id) {
      this.store.activeProvider = 'local'
    }
    this.save()
    return true
  }

  /** 构建 ProviderEngine 需要的参数 */
  buildProviderConfig(providerId?: string): { type: string; apiKey?: string; model?: string; baseUrl?: string; timeoutMs?: number } {
    const id = providerId || this.store.activeProvider
    const p = this.store.providers[id]
    if (!p) return { type: 'local' }

    // 优先用环境变量（安全原因，API key 不存文件）
    const envKey = this.resolveEnvApiKey(id, p)
    return {
      type: p.type,
      apiKey: envKey || p.apiKey,
      model: p.model,
      baseUrl: p.baseUrl,
      timeoutMs: p.timeoutMs,
    }
  }

  private resolveEnvApiKey(providerId: string, p: ProviderConfig): string | undefined {
    // 按 provider ID 映射环境变量（优先级高于通用 type 映射）
    const providerEnvMap: Record<string, string> = {
      'deepseek-chat': 'DEEPSEEK_API_KEY',
      'kimi': 'MOONSHOT_API_KEY',
      'zhipu': 'ZHIPU_API_KEY',
      'doubao': 'ARK_API_KEY',
      'qwen-coder': 'DASHSCOPE_API_KEY',
    }
    // 先在 provider ID 映射里查
    const specificVar = providerEnvMap[providerId]
    if (specificVar) {
      const env = process.env[specificVar]
      if (env) return env
      const lower = process.env[specificVar.toLowerCase()]
      if (lower) return lower
    }
    // 然后按 API type 查通用环境变量
    const typeEnvMap: Record<string, string> = {
      'anthropic-api': 'ANTHROPIC_API_KEY',
      'openai-api': 'OPENAI_API_KEY',
      'openai-compatible': 'OPENAI_API_KEY',
    }
    const envVar = typeEnvMap[p.type]
    if (envVar) {
      const env = process.env[envVar]
      if (env) return env
      const lower = process.env[envVar.toLowerCase()]
      if (lower) return lower
    }
    // 通用 fallback
    return process.env.ORION_API_KEY
  }
}
