// Orion — Orion CLI 入口
// 一个命令式的任务管理 CLI

import { Command } from 'commander'
import { TaskOrchestrator } from './orchestrator/index.js'
import { Shield } from './shield/index.js'
import { SkillsEngine } from './skills/index.js'
import type { TaskStatus } from './types/task.js'

const program = new Command()
const orion = new TaskOrchestrator()
const shield = new Shield()
const skills = new SkillsEngine()

program
  .name('orion')
  .description('🧠 Orion — AI 驱动的智能工作站框架')
  .version('0.1.0')

// ===== task 子命令 =====

const task = program.command('task').description('任务管理')

// memory 命令
program.command('memory')
  .description('记忆系统：查看/搜索/管理 AI 记忆')
  .argument('[action]', 'stats | search | recent | important | cleanup')
  .argument('[query]', '搜索关键词')
  .action(async (action, query) => {
    const { MemoryManager } = await import('./memory/manager.js')
    const mm = new MemoryManager()

    if (!action || action === 'stats') {
      const stats = mm.getStats()
      console.log('🧠 记忆统计:')
      console.log(`  总计: ${stats.total} 条`)
      console.log(`  重要: ${stats.important} 条`)
      console.log('  按类型:')
      for (const [type, count] of Object.entries(stats.byType)) {
        console.log(`    ${type}: ${count}`)
      }
      return
    }

    if (action === 'search') {
      if (!query) { console.log('请输入搜索关键词'); return }
      const results = mm.search(query)
      if (results.length === 0) { console.log('未找到相关记忆'); return }
      console.log(`🔍 找到 ${results.length} 条相关记忆:`)
      for (const r of results) {
        const date = new Date(r.memory.timestamp).toLocaleString('zh-CN')
        console.log(`  [${r.memory.type}] (${(r.relevance * 100).toFixed(0)}%) ${date}`)
        console.log(`    ${(r.memory.summary || r.memory.content).slice(0, 120)}`)
        console.log('')
      }
      return
    }

    if (action === 'recent') {
      const recent = mm.getRecent(10)
      if (recent.length === 0) { console.log('暂无记忆'); return }
      console.log('📝 最近记忆:')
      for (const m of recent) {
        const date = new Date(m.timestamp).toLocaleString('zh-CN')
        console.log(`  [${m.type}] ⭐${'🌟'.repeat(Math.floor(m.importance / 3))} ${date}`)
        console.log(`    ${(m.summary || m.content).slice(0, 100)}`)
        console.log('')
      }
      return
    }

    if (action === 'important') {
      const imp = mm.getImportant()
      if (imp.length === 0) { console.log('暂无重要记忆'); return }
      console.log('⭐ 重要记忆:')
      for (const m of imp) {
        console.log(`  [${m.type}] 重要度: ${m.importance}/10`)
        console.log(`    ${m.summary || m.content.slice(0, 100)}`)
        console.log('')
      }
      return
    }

    if (action === 'cleanup') {
      const removed = mm.cleanup()
      console.log(`🧹 已清理 ${removed} 条过期记忆`)
      return
    }

    console.log('用法: orion memory [stats|search|recent|important|cleanup]')
  })

// model 命令
program.command('model')
  .description('大模型管理：查看/切换/配置 AI 模型')
  .argument('[action]', 'list | switch | key | add | remove')
  .argument('[arg2]', 'provider ID 或参数')
  .argument('[arg3]', '值或模型名')
  .action(async (action, arg2, arg3) => {
    const { ModelManager } = await import('./model/manager.js')
    const mm = new ModelManager()

    if (!action || action === 'list') {
      const list = mm.listProviders()
      console.log('📡 可用模型:\n')
      for (const p of list) {
        const mark = p.active ? ' ⬅️ 当前' : ''
        const key = p.config.apiKey ? '🔑' : '⚪'
        const env = p.config.apiKey ? '' : ' (需设 API Key)'
        console.log(`  ${p.id}`)
        console.log(`    ${p.config.name}${mark}`)
        console.log(`    模型: ${p.config.model}`)
        if (p.config.baseUrl) console.log(`    地址: ${p.config.baseUrl}`)
        console.log(`    ${key} API Key: ${p.config.apiKey ? '***' : '未设置'}${env}`)
        console.log('')
      }
      return
    }

    if (action === 'switch') {
      if (!arg2) { console.log('请指定 provider ID，如: orion model switch deepseek'); return }
      if (!mm.switchProvider(arg2)) { console.log(`❌ 未找到 provider: ${arg2}`); return }
      const p = mm.getActiveProvider()
      console.log(`✅ 已切换到: ${p?.config.name || arg2}`)
      return
    }

    if (action === 'key') {
      if (!arg2) { console.log('请指定 provider ID 和 API Key'); return }
      if (!arg3) { console.log('请指定 API Key'); return }
      mm.setApiKey(arg2, arg3)
      console.log(`✅ ${arg2} 的 API Key 已保存`)
      return
    }

    if (action === 'add') {
      if (!arg2) { console.log('请指定 provider ID 和类型'); return }
      const type = arg3 || 'openai-compatible'
      mm.addCustomProvider(arg2, {
        type: type as any,
        name: arg2,
        model: 'custom-model',
        apiKey: '',
        timeoutMs: 120000,
      })
      console.log(`✅ 已添加自定义 provider: ${arg2}`)
      return
    }

    if (action === 'remove') {
      if (!arg2) { console.log('请指定 provider ID'); return }
      if (mm.removeProvider(arg2)) {
        console.log(`✅ 已删除: ${arg2}`)
      } else {
        console.log(`❌ 无法删除: ${arg2}`)
      }
      return
    }

    console.log(`用法: orion model [list|switch|key|add|remove]`)
  })

task.command('create')
  .description('创建新任务')
  .argument('<title>', '任务标题')
  .option('-d, --description <desc>', '任务描述')
  .option('-p, --priority <level>', '优先级: low/medium/high/critical', 'medium')
  .option('-m, --mode <mode>', '执行模式: code/architect/ask/debug', 'code')
  .option('-D, --deps <ids>', '依赖任务 ID (逗号分隔)')
  .option('-f, --files <paths>', '关联文件 (逗号分隔)')
  .option('-t, --tags <tags>', '标签 (逗号分隔)')
  .action((title, options) => {
    const deps = options.deps ? options.deps.split(',').map((s: string) => s.trim()) : undefined
    const files = options.files ? options.files.split(',').map((s: string) => s.trim()) : undefined
    const tags = options.tags ? options.tags.split(',').map((s: string) => s.trim()) : undefined
    const task = orion.createTask({
      title,
      description: options.description || title,
      priority: options.priority,
      mode: options.mode,
      dependencies: deps,
      files,
      tags,
    })
    console.log(`✅ 创建任务 [${task.id}] ${task.title}`)

    // 自动匹配技能
    const matched = skills.matchSkills(task)
    if (matched.length > 0) {
      console.log(`\n📋 匹配到技能:`)
      for (const m of matched.slice(0, 3)) {
        console.log(`   ${m.skill.name} (匹配度: ${(m.score * 100).toFixed(0)}%)`)
      }
    }
  })

task.command('list')
  .description('列出所有任务')
  .option('-s, --status <status>', '按状态筛选')
  .option('-p, --priority <priority>', '按优先级筛选')
  .action((options) => {
    let tasks = orion.getAllTasks()

    if (options.status) tasks = tasks.filter(t => t.status === options.status)
    if (options.priority) tasks = tasks.filter(t => t.priority === options.priority)

    if (tasks.length === 0) {
      console.log('没有任务')
      return
    }

    // 按状态分组显示
    const grouped: Record<string, typeof tasks> = {}
    for (const t of tasks) {
      ;(grouped[t.status] ||= []).push(t)
    }

    const statusOrder: TaskStatus[] = ['in-progress', 'ready', 'pending', 'review', 'blocked', 'done', 'cancelled', 'deferred']
    for (const s of statusOrder) {
      const group = grouped[s]
      if (!group) continue
      const icon: Record<string, string> = {
        'in-progress': '▶️', ready: '⏳', pending: '⬜',
        review: '👀', blocked: '🚫', done: '✅', cancelled: '❌', deferred: '📅'
      }
      console.log(`\n${icon[s] || '◻️'} ${s} (${group.length}):`)
      for (const t of group) {
        const deps = t.dependencies.length > 0 ? ` [依赖: ${t.dependencies.join(', ')}]` : ''
        const attempts = t.attempts.length > 0 ? ` [尝试: ${t.attempts.length}]` : ''
        console.log(`  ${t.id} ${t.title}${deps}${attempts}`)
      }
    }

    // 统计
    const stats = orion.getStats()
    console.log(`\n📊 总计: ${Object.values(stats).reduce((a, b) => a + b, 0)} 任务`)
    console.log(`   ✅ done: ${stats.done} | ▶️ 进行中: ${stats['in-progress']} | ⏳ 待处理: ${stats.pending + stats.ready} | 🚫 blocked: ${stats.blocked}`)
  })

task.command('status')
  .description('查看或更新任务状态')
  .argument('<id>', '任务 ID')
  .option('-s, --set <status>', '设置新状态')
  .option('-r, --reason <reason>', '阻塞原因 (仅 blocked)')
  .action((id, options) => {
    if (options.set) {
      const task = orion.updateStatus(id, options.set as TaskStatus, options.reason)
      if (!task) { console.error(`❌ 任务 ${id} 不存在`); return }
      console.log(`✅ ${id} → ${options.set}`)
      return
    }

    const task = orion.getTask(id)
    if (!task) { console.error(`❌ 任务 ${id} 不存在`); return }
    console.log(`[${task.id}] ${task.title}`)
    console.log(`  状态: ${task.status}`)
    console.log(`  优先级: ${task.priority}`)
    console.log(`  依赖: ${task.dependencies.join(', ') || '无'}`)
    console.log(`  尝试: ${task.attempts.length} 次`)
    console.log(`  文件: ${task.scope.files.join(', ') || '未指定'}`)
    console.log(`  标签: ${task.scope.tags.join(', ') || '未指定'}`)
    if (task.blockedReason) console.log(`  阻塞原因: ${task.blockedReason}`)
  })

task.command('delete')
  .description('删除任务')
  .argument('<id>', '任务 ID')
  .action((id) => {
    if (orion.deleteTask(id)) {
      console.log(`✅ 已删除 ${id}`)
    } else {
      console.error(`❌ 任务 ${id} 不存在`)
    }
  })

task.command('ready')
  .description('显示可执行的任务')
  .action(() => {
    const ready = orion.getReadyTasks()
    if (ready.length === 0) {
      console.log('当前没有可执行的任务')
      return
    }
    console.log('⏳ 可执行的任务:')
    for (const t of ready) {
      console.log(`  ${t.id} ${t.title}`)
    }
  })

task.command('blocked')
  .description('显示阻塞的任务')
  .action(() => {
    const blocked = orion.getBlockedTasks()
    if (blocked.length === 0) {
      console.log('没有阻塞的任务')
      return
    }
    console.log('🚫 阻塞的任务:')
    for (const { task, reason } of blocked) {
      console.log(`  ${task.id} ${task.title} — ${reason}`)
    }
  })

task.command('reset')
  .description('重置所有进行中任务为 pending（恢复用）')
  .action(() => {
    const count = orion.resetActiveTasks()
    console.log(`✅ 已重置 ${count} 个任务`)
  })

task.command('graph')
  .description('显示依赖图')
  .action(() => {
    const graph = orion.getDependencyGraph()
    console.log('依赖关系:')
    for (const [from, to] of graph.edges) {
      console.log(`  ${from} → ${to}`)
    }
  })

// ===== execute 子命令 =====

const execCmd = program.command('execute').description('执行任务')

execCmd.command('task')
  .description('执行指定任务')
  .argument('<id>', '任务 ID')
  .option('-p, --provider <type>', 'Provider: claude-code/anthropic-api/local/human', 'local')
  .action(async (id, options) => {
    const { ProviderEngine, createDefaultProvider } = await import('./provider/index.js')
    const engine = createDefaultProvider(orion, shield, skills, options.provider)
    console.log(`▶️ 正在执行任务 ${id}...`)
    const result = await engine.executeTask(id)
    if (result.success) {
      console.log(`✅ 执行完成 (${result.durationMs}ms)`)
      if (result.output) console.log(result.output.slice(0, 500))
    } else {
      console.log(`❌ 执行失败: ${result.error?.slice(0, 200)}`)
    }
  })

execCmd.command('ready')
  .description('执行所有可执行的任务')
  .option('-p, --provider <type>', 'Provider 类型', 'local')
  .action(async (options) => {
    const ready = orion.getReadyTasks()
    if (ready.length === 0) { console.log('没有可执行的任务'); return }
    console.log(`▶️ 开始执行 ${ready.length} 个任务...`)
    const { ProviderEngine, createDefaultProvider } = await import('./provider/index.js')
    const engine = createDefaultProvider(orion, shield, skills, options.provider)
    for (const task of ready) {
      console.log(`
[${task.id}] ${task.title}`)
      const result = await engine.executeTask(task.id)
      const icon = result.success ? '✅' : '❌'
      console.log(`  ${icon} ${result.durationMs}ms | ${result.error?.slice(0, 100) || 'ok'}`)
    }
  })

// ===== shield 子命令 =====

const shieldCmd = program.command('shield').description('保护层管理')

shieldCmd.command('status')
  .description('显示保护层状态')
  .action(() => {
    const cfg = shield.getConfig()
    console.log('🛡️ Shield 保护层:')
    console.log(`  状态: ${cfg.enabled ? '✅ 启用' : '❌ 禁用'}`)
    console.log(`  循环检测: ${cfg.loopDetection.enabled ? '✅' : '❌'}`)
    console.log(`  警告阈值: ${cfg.loopDetection.warningThreshold} 次`)
    console.log(`  临界阈值: ${cfg.loopDetection.criticalThreshold} 次`)
    console.log(`  最大重试: ${cfg.failureThreshold.maxRetriesPerAction}`)
    console.log(`  连续失败上限: ${cfg.failureThreshold.maxConsecutiveFailures}`)
  })

shieldCmd.command('config')
  .description('更新配置')
  .option('--max-retries <n>', '最大重试次数', parseInt)
  .option('--max-failures <n>', '连续失败上限', parseInt)
  .action((options) => {
    const updates: any = {}
    if (options.maxRetries) updates.failureThreshold = { maxRetriesPerAction: options.maxRetries }
    if (options.maxFailures) updates.failureThreshold = { ...updates.failureThreshold, maxConsecutiveFailures: options.maxFailures }
    shield.updateConfig(updates)
    console.log('✅ 配置已更新')
  })

// ===== skill 子命令 =====

const skillCmd = program.command('skill').description('技能管理')

skillCmd.command('list')
  .description('列出所有技能')
  .option('-t, --tag <tag>', '按标签筛选')
  .action((options) => {
    const count = skills.loadAll()
    let all = skills.getAllSkills()
    if (options.tag) all = skills.getSkillsByTag(options.tag)

    console.log(`📚 已加载 ${count} 个技能:`)
    for (const s of all) {
      console.log(`  ${s.name} v${s.version}`)
      console.log(`    ${s.description}`)
      console.log(`    标签: ${s.tags.join(', ') || '无'}`)
      console.log(`    使用: ${s.usageStats.successCount}次成功 / ${s.usageStats.failureCount}次失败`)
      console.log('')
    }
  })

skillCmd.command('match')
  .description('为任务匹配技能')
  .argument('<task-title>', '任务标题')
  .action((title) => {
    skills.loadAll()
    const matched = skills.matchSkills({ title })
    if (matched.length === 0) {
      console.log('没有匹配到技能')
      return
    }
    console.log(`📋 为 "${title}" 匹配到 ${matched.length} 个技能:`)
    for (const m of matched) {
      console.log(`  ${m.skill.name} (${(m.score * 100).toFixed(0)}%)`)
      console.log(`    匹配点: ${m.matchedOn.join(', ')}`)
    }
  })

// ===== watch 子命令 =====

program.command('watch')
  .description('监听文件变化，自动关联任务')
  .action(async () => {
    const { FileWatcher } = await import('./watcher/index.js')
    const watcher = new FileWatcher(orion)
    watcher.start(process.cwd())
    console.log('按 Ctrl+C 停止监听')
  })

// ===== checkpoint 子命令 =====

// 自动模式命令
program.command('auto')
  .description('切换自动模式（断点自动处理，全自动化工作流）')
  .option('-e, --enable', '开启自动模式')
  .option('-d, --disable', '关闭自动模式')
  .option('-s, --status', '查看当前模式')
  .action(async (options) => {
    const { CheckpointManager } = await import('./checkpoint/manager.js')
    const cm = new CheckpointManager()
    if (options.enable) { cm.setAutoMode(true); console.log('⚡ 自动模式已开启'); return }
    if (options.disable) { cm.setAutoMode(false); console.log('⏸️ 自动模式已关闭，断点需人工响应'); return }
    // toggle
    const mode = cm.toggleAutoMode()
    console.log(mode ? '⚡ 自动模式已开启' : '⏸️ 自动模式已关闭')
  })

const cpCmd = program.command('checkpoint').description('人类断点管理')

cpCmd.command('list')
  .description('列出所有待处理的断点')
  .action(async () => {
    const { CheckpointManager, formatCheckpointTerminal } = await import('./checkpoint/manager.js')
    const cm = new CheckpointManager()
    const pending = cm.getPendingCheckpoints()
    if (pending.length === 0) {
      console.log('✅ 没有待处理的断点')
      return
    }
    console.log(`📌 ${pending.length} 个待处理断点:`)
    for (const cp of pending) {
      console.log(formatCheckpointTerminal(cp))
    }
  })

cpCmd.command('approve')
  .description('批准断点，AI 继续执行')
  .argument('<id>', '断点 ID')
  .argument('[comment]', '备注')
  .action(async (id, comment) => {
    const { CheckpointManager } = await import('./checkpoint/manager.js')
    const cm = new CheckpointManager()
    const cp = cm.approve(id, comment)
    if (!cp) { console.error('❌ 断点不存在或已处理'); return }
    console.log(`✅ 已批准断点 ${id}，AI 可继续执行`)
  })

cpCmd.command('reject')
  .description('拒绝断点，需要修改后重试')
  .argument('<id>', '断点 ID')
  .argument('[comment]', '修改意见')
  .action(async (id, comment) => {
    const { CheckpointManager } = await import('./checkpoint/manager.js')
    const cm = new CheckpointManager()
    const cp = cm.reject(id, comment || '需要修改')
    if (!cp) { console.error('❌ 断点不存在或已处理'); return }
    console.log(`❌ 已拒绝断点 ${id}，任务将重试`)
  })

cpCmd.command('redirect')
  .description('提供新方向，AI 按新方向执行')
  .argument('<id>', '断点 ID')
  .argument('<direction>', '新方向描述')
  .action(async (id, direction) => {
    const { CheckpointManager } = await import('./checkpoint/manager.js')
    const cm = new CheckpointManager()
    const cp = cm.redirect(id, direction)
    if (!cp) { console.error('❌ 断点不存在或已处理'); return }
    console.log(`🔄 已重定向断点 ${id}: ${direction}`)
  })

cpCmd.command('status')
  .description('断点统计')
  .action(async () => {
    const { CheckpointManager } = await import('./checkpoint/manager.js')
    const cm = new CheckpointManager()
    const stats = cm.getStats()
    const autoMode = cm.isAutoMode()
    console.log('📊 断点统计:')
    console.log(`  待处理: ${stats.pending}`)
    console.log(`  已批准: ${stats.approved}`)
    console.log(`  已拒绝: ${stats.rejected}`)
    console.log(`  总计: ${stats.total}`)
    console.log(`')\n⚡ 自动模式: ${autoMode ? '✅ 开启 (断点自动处理)' : '❌ 关闭 (需人工响应)'}`)
  })

// ===== web 子命令 =====

program.command('web')
  .description('启动 Web UI 管理界面')
  .option('-p, --port <port>', '端口号', '3939')
  .action(async (options) => {
    const { WebServer } = await import('./web/server.js')
    const server = new WebServer(orion, shield, skills, parseInt(options.port))
    server.start()
  })

// ===== mcp 子命令 =====

program.command('mcp')
  .description('启动 MCP Server（供 AI 工具调用）')
  .action(async () => {
    const { OrionMCPServer } = await import('./mcp-server.js')
    const server = new OrionMCPServer()
    server.start()
  })

// ===== 默认命令 =====

program.command('status')
  .description('显示 Orion 状态概览')
  .action(() => {
    const stats = orion.getStats()
    const total = Object.values(stats).reduce((a, b) => a + b, 0)

    console.log('🧠 Orion 工作站')
    console.log('━'.repeat(40))
    console.log(`📋 任务: ${total} 个`)
    console.log(`  ✅ 完成: ${stats.done}`)
    console.log(`  ▶️ 进行中: ${stats['in-progress']}`)
    console.log(`  ⏳ 待处理: ${stats.pending + stats.ready}`)
    console.log(`  👀 审查中: ${stats.review}`)
    console.log(`  🚫 阻塞: ${stats.blocked}`)

    const skillCount = skills.loadAll()
    console.log(`\n📚 技能: ${skillCount} 个`)

    console.log('\n🛡️ Shield: ' + (shield.getConfig().enabled ? '✅ 运行中' : '❌ 已禁用'))
  })

// ===== 解析参数 =====

program.parse()
