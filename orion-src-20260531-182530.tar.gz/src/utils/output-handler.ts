// Orion — 产出物自动执行
// 任务完成后检测产物文件类型，自动用对应程序打开/执行
// 仅在 autoMode 开启时生效

import { execSync, spawn } from 'node:child_process'
import { existsSync, readFileSync, writeFileSync } from 'node:fs'
import { extname, join, dirname, basename } from 'node:path'
import type { FileChange } from '../agent/tools.js'

export interface OutputAction {
  type: 'run' | 'browser' | 'open'
  file: string
  command?: string
  description: string
}

interface FileTypeRule {
  exts: string[]
  type: OutputAction['type']
  command?: string
  description: string
}

// 文件类型 → 打开方式映射
const FILE_RULES: FileTypeRule[] = [
  // === 浏览器预览 ===
  { exts: ['.html', '.htm', '.shtml'], type: 'browser', description: '网页' },

  // === 脚本直接执行 ===
  { exts: ['.py'], type: 'run', command: 'python "{file}"', description: 'Python 脚本' },
  { exts: ['.sh', '.bash'], type: 'run', command: 'bash "{file}"', description: 'Shell 脚本' },
  { exts: ['.ps1'], type: 'run', command: 'powershell -ExecutionPolicy Bypass -File "{file}"', description: 'PowerShell 脚本' },

  // === Node.js（.js/.mjs 需运行时检测） ===
  // 在 detectOutputActions 中特殊处理，此处仅作兜底
  { exts: ['.cjs'], type: 'run', command: 'node "{file}"', description: 'CommonJS 脚本' },

  // === 编译型语言（编译后执行） ===
  { exts: ['.java'], type: 'run', command: 'javac "{file}" && java -cp "{dir}" {name}', description: 'Java 程序' },
  { exts: ['.cpp', '.cc', '.cxx'], type: 'run', command: 'g++ -std=c++17 "{file}" -o "{dir}/{name}.out" && "{dir}/{name}.out"', description: 'C++ 程序' },
  { exts: ['.c'], type: 'run', command: 'gcc "{file}" -o "{dir}/{name}.out" && "{dir}/{name}.out"', description: 'C 程序' },
  { exts: ['.go'], type: 'run', command: 'go run "{file}"', description: 'Go 程序' },

  // === 文档（调用系统默认程序） ===
  { exts: ['.pdf', '.doc', '.docx', '.xls', '.xlsx', '.ppt', '.pptx', '.csv', '.odt', '.ods', '.odp'], type: 'open', description: '文档' },
  { exts: ['.md', '.txt', '.log', '.json', '.yaml', '.yml', '.toml', '.xml'], type: 'open', description: '文本' },

  // === 图片 ===
  { exts: ['.png', '.jpg', '.jpeg', '.gif', '.bmp', '.svg', '.webp', '.ico', '.tiff', '.tif'], type: 'open', description: '图片' },

  // === 音频 ===
  { exts: ['.mp3', '.wav', '.ogg', '.flac', '.aac', '.wma', '.m4a', '.opus'], type: 'open', description: '音频' },

  // === 视频 ===
  { exts: ['.mp4', '.avi', '.mkv', '.mov', '.webm', '.wmv', '.flv', '.m4v'], type: 'open', description: '视频' },
]

// 项目级检测：如果产物目录包含项目配置，返回项目运行命令
interface ProjectDetector {
  file: string
  command?: string
  description: string
  type?: 'run' | 'browser'
  /** 如果 type 是 browser，提供 dev server URL */
  devUrl?: string
  /** 检查是否匹配（用于需要读取文件内容的场景） */
  match?: (configPath: string) => boolean
}

const PROJECT_DETECTORS: ProjectDetector[] = [
  { file: 'package.json', command: 'npm start', description: 'Node.js/npm 项目',
    match: (p) => {
      try {
        const raw = readFileSync(p, 'utf-8')
        const pkg = JSON.parse(raw)
        const deps = { ...pkg.dependencies, ...pkg.devDependencies }
        if (deps.vite || deps['@vitejs/plugin-vue'] || deps['@vitejs/plugin-react']) {
          return true // handled below as browser type
        }
      } catch {}
      return false
    }
  },
  { file: 'package.json', type: 'browser', devUrl: 'http://localhost:5173', description: 'Vite 前端项目',
    match: (p) => {
      try {
        const raw = readFileSync(p, 'utf-8')
        const pkg = JSON.parse(raw)
        const deps = { ...pkg.dependencies, ...pkg.devDependencies }
        return !!(deps.vite || deps['@vitejs/plugin-vue'] || deps['@vitejs/plugin-react'])
      } catch { return false }
    }
  },
  { file: 'Cargo.toml', command: 'cargo run', description: 'Rust/Cargo 项目' },
  { file: 'go.mod', command: 'go run .', description: 'Go 项目' },
  { file: 'Makefile', command: 'make && make run', description: 'Makefile 项目' },
  { file: 'pyproject.toml', command: 'python -m main', description: 'Python 项目' },
  { file: 'requirements.txt', command: 'pip install -r requirements.txt && python main.py', description: 'Python 项目' },
  { file: 'deno.json', command: 'deno run --allow-all main.ts', description: 'Deno 项目' },
]

// 浏览器 JS 特征（DOM / Canvas / Web API）
const BROWSER_API_PATTERNS = /\b(document\.|window\.|addEventListener\(|getElementById\(|querySelector\(|createElement\(|getContext\(|innerHTML\b|localStorage\.|sessionStorage\.|Canvas|requestAnimationFrame\(|fetch\(|navigator\.|location\.|history\.|alert\(|confirm\()/

// Node.js 特征（如果同时出现则偏向 Node，因为可能在写 SSR 模板）
const NODE_ONLY_PATTERNS = /\b(process\.(?!env)|require\(|module\.exports|__dirname|__filename|fs\.read|fs\.write|path\.join|Buffer\.from|child_process|express\(|createServer\(|listen\(\d)/

// ===== 公共 API =====

/** 扫描任务产出文件，生成自动执行动作列表 */
export function detectOutputActions(
  newFiles: string[],
  changes: FileChange[],
  projectRoot: string,
): OutputAction[] {
  const actions: OutputAction[] = []
  const allPaths = new Set([
    ...newFiles,
    ...changes.map(c => c.path),
  ])

  // 1. 项目级检测: 如果产物目录有项目配置，优先运行项目
  const projectDirs = new Set<string>()
  for (const p of allPaths) {
    const dir = dirname(join(projectRoot, p))
    if (!projectDirs.has(dir)) {
      projectDirs.add(dir)
      for (const detector of PROJECT_DETECTORS) {
        const configPath = join(dir, detector.file)
        if (existsSync(configPath) && (!detector.match || detector.match(configPath))) {
          if (detector.type === 'browser' && detector.devUrl) {
            actions.push({
              type: 'browser',
              file: detector.devUrl,
              description: detector.description + ': ' + configPath,
            })
          } else {
            actions.push({
              type: 'run',
              file: configPath,
              command: detector.command,
              description: detector.description,
            })
          }
          break
        }
      }
    }
  }

  // 2. 先收集所有 HTML 文件所在的目录
  const htmlDirs = new Set<string>()
  for (const p of allPaths) {
    const ext = extname(p).toLowerCase()
    if (ext === '.html' || ext === '.htm') {
      htmlDirs.add(dirname(join(projectRoot, p)))
    }
  }

  // 3. 文件级检测
  for (const p of allPaths) {
    const fullPath = join(projectRoot, p)
    if (!existsSync(fullPath)) continue

    const ext = extname(p).toLowerCase()
    const parentDir = dirname(fullPath)

    // === JS/TS 文件: 运行时检测 ===
    if (ext === '.js' || ext === '.mjs' || ext === '.ts') {
      // 检查是否已被项目级 action 覆盖
      const alreadyHasProject = actions.some(a =>
        dirname(a.file) === parentDir && a.type === 'run',
      )
      if (alreadyHasProject) continue

      const isBrowser = isBrowserJS(fullPath)
      const hasHTML = htmlDirs.has(parentDir)

      if (isBrowser) {
        if (hasHTML) {
          // 同目录已有 HTML，JS 会被页面加载，跳过
          continue
        }
        // 浏览器 JS 但没有宿主 HTML → 生成包装页
        const wrapperPath = generateHTMLWrapper(fullPath, parentDir)
        actions.push({
          type: 'browser',
          file: wrapperPath,
          description: '浏览器游戏/应用: ' + p,
        })
        continue
      }

      // Node.js 脚本
      const name = basenameNoExt(p)
      actions.push({
        type: 'run',
        file: fullPath,
        command: `node "${fullPath}"`,
        description: 'Node.js 脚本: ' + p,
      })
      continue
    }

    // === 常规文件类型匹配 ===
    for (const rule of FILE_RULES) {
      if (rule.exts.includes(ext)) {
        const alreadyHasProject = actions.some(a =>
          dirname(a.file) === parentDir && a.type === 'run',
        )
        if (alreadyHasProject && rule.type === 'run') continue

        const dir = dirname(fullPath)
        const name = basenameNoExt(p)
        let command = rule.command
        if (command) {
          command = command.replace(/\{file\}/g, fullPath)
            .replace(/\{dir\}/g, dir)
            .replace(/\{name\}/g, name)
        }

        actions.push({
          type: rule.type,
          file: fullPath,
          command,
          description: rule.description + ': ' + p,
        })
        break
      }
    }
  }

  return actions
}

/** 执行产出动作 */
export function executeOutputActions(
  actions: OutputAction[],
  projectRoot: string,
  onProgress?: (msg: string) => void,
): string[] {
  const results: string[] = []

  for (const action of actions) {
    try {
      switch (action.type) {
        case 'browser': {
          const isUrl = /^https?:\/\//.test(action.file)
          const url = isUrl
            ? action.file
            : `file:///${action.file.replace(/\\/g, '/')}`
          openWithSystem(url)
          const msg = `🌐 浏览器打开: ${action.file}`
          onProgress?.(msg)
          results.push(msg)
          break
        }
        case 'open': {
          openWithSystem(action.file)
          const msg = `📄 打开${action.description}`
          onProgress?.(msg)
          results.push(msg)
          break
        }
        case 'run': {
          if (!action.command) break
          const msg = `▶ 执行${action.description}: ${action.command}`
          onProgress?.(msg)
          results.push(msg)
          spawn(action.command, [], {
            cwd: dirname(action.file),
            shell: true,
            detached: true,
            stdio: 'ignore',
            windowsHide: false,
          }).unref()
          break
        }
      }
    } catch (e: any) {
      const errMsg = `❌ ${action.description} 失败: ${e.message}`
      results.push(errMsg)
    }
  }

  return results
}

// ===== JS 运行时检测 =====

/** 扫描 JS 文件前 8KB，判断是浏览器 JS 还是 Node.js */
function isBrowserJS(filePath: string): boolean {
  try {
    const content = readFileSync(filePath, 'utf-8').slice(0, 8192)
    const hasBrowserAPI = BROWSER_API_PATTERNS.test(content)
    const hasNodeOnly = NODE_ONLY_PATTERNS.test(content)

    if (hasNodeOnly) return false
    if (hasBrowserAPI) return true
    // 无特征 → 默认 Node.js（安全优先）
    return false
  } catch {
    return false
  }
}

/** 为浏览器 JS 文件生成最小宿主 HTML */
function generateHTMLWrapper(jsPath: string, outDir: string): string {
  const jsFile = basename(jsPath)
  const title = basenameNoExt(jsFile)
  const wrapperPath = join(outDir, '_orion_preview.html')

  const html = [
    '<!DOCTYPE html>',
    '<html lang="zh-CN">',
    '<head>',
    '<meta charset="UTF-8">',
    '<meta name="viewport" content="width=device-width,initial-scale=1.0">',
    `<title>${title} — Orion 预览</title>`,
    '<style>',
    '  *{margin:0;padding:0;box-sizing:border-box}',
    '  body{display:flex;justify-content:center;align-items:center;min-height:100vh;',
    '    background:#0d1117;color:#e6edf3;font-family:system-ui,sans-serif}',
    '  #orion-preview-root{width:100%;max-width:960px;padding:24px}',
    '  canvas{display:block;margin:0 auto;border:1px solid #30363d}',
    '</style>',
    '</head>',
    '<body>',
    '<div id="orion-preview-root"></div>',
    `<script src="${jsFile}"></script>`,
    '</body>',
    '</html>',
  ].join('\n')

  writeFileSync(wrapperPath, html, 'utf-8')
  return wrapperPath
}

// ===== 内部工具 =====

function basenameNoExt(filePath: string): string {
  const base = filePath.split(/[/\\]/).pop() || ''
  const dot = base.lastIndexOf('.')
  return dot > 0 ? base.slice(0, dot) : base
}

function openWithSystem(filePath: string): void {
  const platform = process.platform
  let command: string
  if (platform === 'win32') {
    command = `start "" "${filePath}"`
  } else if (platform === 'darwin') {
    command = `open "${filePath}"`
  } else {
    command = `xdg-open "${filePath}"`
  }
  execSync(command, { stdio: 'ignore', windowsHide: true })
}
