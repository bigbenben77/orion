// Orion — 内存索引引擎
// 为 JSON 文件存储提供高效的查询索引，无需引入外部数据库
//
// 使用方式:
//   const idx = new Indexer<MyType>()
//   idx.add(records)
//   idx.findBy('status', 'pending')        // O(1) 哈希查找
//   idx.findBy('priority', 'high')         // O(1)
//   idx.findByRange('timestamp', 100, 200) // O(log N) 有序查找
//   idx.findByTag('tags', 'session')       // 数组包含查找

export type IndexType = 'hash' | 'sorted' | 'tag'

export interface IndexConfig {
  /** 索引字段名（支持嵌套，如 'metadata.totalMemories'） */
  field: string
  /** 索引类型 */
  type: IndexType
  /** 是否允许复合（默认 false），true 时支持数组字段的包含查找 */
  multi?: boolean
}

export class Indexer<T extends Record<string, any>> {
  private data: T[] = []
  private hashIndexes = new Map<string, Map<string, T[]>>()
  private sortedIndexes = new Map<string, { keys: number[]; data: T[] }>()
  private tagIndexes = new Map<string, Map<string, T[]>>()
  private configs: IndexConfig[] = []
  private dirty = true

  constructor(configs: IndexConfig[] = []) {
    for (const cfg of configs) {
      this.register(cfg)
    }
  }

  /** 注册一个新索引 */
  register(config: IndexConfig): void {
    this.configs.push(config)
    switch (config.type) {
      case 'hash':
        this.hashIndexes.set(config.field, new Map())
        break
      case 'sorted':
        this.sortedIndexes.set(config.field, { keys: [], data: [] })
        break
      case 'tag':
        this.tagIndexes.set(config.field, new Map())
        break
    }
    this.dirty = true
  }

  /** 批量设置数据并重建索引 */
  setData(items: T[]): void {
    this.data = items
    this.rebuild()
  }

  /** 添加一条记录到索引 */
  add(item: T): void {
    this.data.push(item)
    this.indexItem(item)
  }

  /** 删除一条记录（通过引用相等或自定义匹配） */
  remove(predicate: (item: T) => boolean): boolean {
    const idx = this.data.findIndex(predicate)
    if (idx === -1) return false
    this.data.splice(idx, 1)
    this.rebuild() // 删除导致的索引重建
    return true
  }

  /** 更新一条记录 */
  update(predicate: (item: T) => boolean, updater: (item: T) => T): boolean {
    const idx = this.data.findIndex(predicate)
    if (idx === -1) return false
    this.data[idx] = updater(this.data[idx])
    this.rebuild()
    return true
  }

  /** 获取所有数据 */
  getAll(): T[] {
    return this.data
  }

  /** 获取数据条数 */
  get size(): number {
    return this.data.length
  }

  // ===== 查询方法 =====

  /** 按哈希索引精确查找（O(1)） */
  findBy(field: string, value: string | number | boolean): T[] {
    const map = this.hashIndexes.get(field)
    if (!map) {
      // 降级为全表扫描
      return this.data.filter(item => getField(item, field) === value)
    }
    const key = String(value)
    return map.get(key) || []
  }

  /** 按标签/数组包含查找（O(1)） */
  findByTag(field: string, tag: string): T[] {
    const map = this.tagIndexes.get(field)
    if (!map) {
      // 降级为全表扫描
      return this.data.filter(item => {
        const val = getField<T, any>(item, field)
        return Array.isArray(val) && val.includes(tag)
      })
    }
    return map.get(tag) || []
  }

  /** 按排序索引范围查找（O(log N + K)） */
  findByRange(field: string, min?: number, max?: number): T[] {
    const idx = this.sortedIndexes.get(field)
    if (!idx) {
      // 降级为全表扫描
      return this.data.filter(item => {
        const val = Number(getField(item, field))
        if (min !== undefined && val < min) return false
        if (max !== undefined && val > max) return false
        return true
      })
    }

    const { keys, data: sortedData } = idx
    const lo = min !== undefined ? lowerBound(keys, min) : 0
    const hi = max !== undefined ? upperBound(keys, max) : keys.length - 1

    const result: T[] = []
    for (let i = lo; i <= hi; i++) {
      result.push(sortedData[i])
    }
    return result
  }

  /** 组合查询（AND 逻辑） */
  findWhere(conditions: { field: string; value?: string | number | boolean; tag?: string; min?: number; max?: number }[]): T[] {
    if (conditions.length === 0) return [...this.data]

    // 从最精确的索引开始过滤
    let results: T[] | null = null

    for (const cond of conditions) {
      let filtered: T[]
      if (cond.tag !== undefined) {
        filtered = this.findByTag(cond.field, cond.tag)
      } else if (cond.min !== undefined || cond.max !== undefined) {
        filtered = this.findByRange(cond.field, cond.min, cond.max)
      } else if (cond.value !== undefined) {
        filtered = this.findBy(cond.field, cond.value)
      } else {
        continue
      }

      if (results === null) {
        results = filtered
      } else {
        // AND 交集
        const set: Set<T> = new Set(results)
        results = filtered.filter(item => set.has(item))
      }
    }

    return results || []
  }

  // ===== 内部方法 =====

  private rebuild(): void {
    // 清空所有索引
    for (const [, map] of this.hashIndexes) map.clear()
    for (const [, idx] of this.sortedIndexes) { idx.keys = []; idx.data = [] }
    for (const [, map] of this.tagIndexes) map.clear()

    // 重建
    for (const item of this.data) {
      this.indexItem(item)
    }
    this.dirty = false
  }

  private indexItem(item: T): void {
    for (const cfg of this.configs) {
      const rawVal = getField<T, any>(item, cfg.field)

      switch (cfg.type) {
        case 'hash': {
          const map = this.hashIndexes.get(cfg.field)!
          const key = String(rawVal)
          if (!map.has(key)) map.set(key, [])
          map.get(key)!.push(item)
          break
        }
        case 'sorted': {
          const idx = this.sortedIndexes.get(cfg.field)!
          const numVal = Number(rawVal)
          // 插入排序（二分查找插入位置）
          const pos = upperBound(idx.keys, numVal)
          idx.keys.splice(pos, 0, numVal)
          idx.data.splice(pos, 0, item)
          break
        }
        case 'tag': {
          const map = this.tagIndexes.get(cfg.field)!
          if (Array.isArray(rawVal)) {
            for (const tag of rawVal) {
              const key = String(tag)
              if (!map.has(key)) map.set(key, [])
              map.get(key)!.push(item)
            }
          }
          break
        }
      }
    }
  }
}

// ===== 工具函数 =====

/** 安全获取嵌套字段值 */
function getField<T, V>(obj: T, field: string): V {
  const parts = field.split('.')
  let current: any = obj
  for (const part of parts) {
    if (current == null || typeof current !== 'object') return undefined as unknown as V
    current = current[part]
  }
  return current as V
}

/** 二分查找下界（第一个 >= target 的位置） */
function lowerBound(arr: number[], target: number): number {
  let lo = 0, hi = arr.length
  while (lo < hi) {
    const mid = (lo + hi) >>> 1
    if (arr[mid] < target) lo = mid + 1
    else hi = mid
  }
  return lo
}

/** 二分查找上界（最后一个 <= target 的位置） */
function upperBound(arr: number[], target: number): number {
  let lo = 0, hi = arr.length
  while (lo < hi) {
    const mid = (lo + hi) >>> 1
    if (arr[mid] <= target) lo = mid + 1
    else hi = mid
  }
  return lo - 1
}
