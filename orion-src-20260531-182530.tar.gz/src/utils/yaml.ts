// 极简 YAML 解析器（仅支持 Orion 技能文件所需的子集）

interface StackEntry {
  obj: Record<string, unknown>
  key: string
  indent: number
  listArray?: unknown[]  // 非空表示当前层级是数组上下文
}

export function parse(yaml: string): unknown {
  const lines = yaml.split('\n')
  const root: Record<string, unknown> = {}
  const stack: StackEntry[] = [{ obj: root, key: '', indent: -1 }]
  let current = root

  for (const rawLine of lines) {
    const line = rawLine.replace(/#.*$/, '')
    const trimmed = line.trim()
    if (!trimmed || trimmed.startsWith('---')) continue

    const indent = line.length - line.trimStart().length

    // 缩进减少 → 出栈
    while (stack.length > 1) {
      const top = stack[stack.length - 1]
      if (top.listArray) {
        if (indent < top.indent) stack.pop()
        else break
      } else if (indent <= top.indent) {
        stack.pop()
      } else {
        break
      }
    }

    // 列表项
    if (trimmed.startsWith('- ')) {
      const value = trimmed.slice(2).trim()
      const entry = stack[stack.length - 1]

      if (entry.listArray) {
        // 已在数组上下文中，直接添加
        const colonIdx = value.indexOf(':')
        if (colonIdx !== -1 && !isQuoted(value)) {
          const itemObj: Record<string, unknown> = {}
          const itemKey = value.slice(0, colonIdx).trim()
          const itemVal = value.slice(colonIdx + 1).trim()
          itemObj[itemKey] = parseScalar(itemVal)
          entry.listArray.push(itemObj)
          stack.push({ obj: itemObj, key: entry.key, indent, listArray: entry.listArray })
          current = itemObj
        } else {
          entry.listArray.push(parseScalar(value))
        }
      } else {
        // 在当前 key 上创建数组
        const listKey = entry.key
        if (listKey) {
          stack.pop()
          const parent = stack[stack.length - 1].obj
          const existing = parent[listKey]
          const arr: unknown[] = Array.isArray(existing) ? existing as unknown[] : []
          if (!Array.isArray(existing)) parent[listKey] = arr

          const colonIdx = value.indexOf(':')
          if (colonIdx !== -1 && !isQuoted(value)) {
            const itemObj: Record<string, unknown> = {}
            const itemKey = value.slice(0, colonIdx).trim()
            const itemVal = value.slice(colonIdx + 1).trim()
            itemObj[itemKey] = parseScalar(itemVal)
            arr.push(itemObj)
            stack.push({ obj: itemObj, key: listKey, indent, listArray: arr })
            current = itemObj
          } else {
            arr.push(parseScalar(value))
            stack.push({ obj: {}, key: listKey, indent, listArray: arr })
          }
        }
      }
      continue
    }

    const colonIdx = trimmed.indexOf(':')
    if (colonIdx === -1) continue

    const key = trimmed.slice(0, colonIdx).trim()
    const rawValue = trimmed.slice(colonIdx + 1).trim()

    if (rawValue === '' || rawValue === '|') {
      const newObj: Record<string, unknown> = {}
      current[key] = newObj
      stack.push({ obj: newObj, key, indent })
      current = newObj
    } else if (rawValue.startsWith('[') && rawValue.endsWith(']')) {
      current[key] = rawValue.slice(1, -1).split(',').map(s => parseScalar(s.trim().replace(/^["']|["']$/g, ''))).filter(v => v !== '')
    } else {
      current[key] = parseScalar(rawValue)
    }
  }

  return root
}

function isQuoted(value: string): boolean {
  return (value.startsWith('"') && value.endsWith('"')) || (value.startsWith("'") && value.endsWith("'"))
}

function parseScalar(value: string): unknown {
  if (value === 'true' || value === 'yes') return true
  if (value === 'false' || value === 'no') return false
  if (value === 'null' || value === '~') return null
  const num = Number(value)
  if (!isNaN(num) && value.trim() !== '') return num
  if (isQuoted(value)) return value.slice(1, -1)
  return value
}
