// Orion — Skills Engine (技能引擎)
// 技能加载、匹配、自动学习

import { readFileSync, writeFileSync, existsSync, readdirSync, mkdirSync } from 'node:fs'
import { join } from 'node:path'
import { parse as parseYaml } from '../utils/yaml.js'
import type { Skill, SkillMatchResult } from '../types/skill.js'
import type { Task } from '../types/task.js'
import type { TaskOrchestrator } from '../orchestrator/index.js'

export class SkillsEngine {
  private skills: Map<string, Skill> = new Map()
  private skillDirs: string[]

  constructor(skillDirs?: string[]) {
    // 默认搜索路径：项目级 → 用户级
    this.skillDirs = skillDirs || [
      join(process.cwd(), '.orion', 'skills'),
    ]
  }

  // ===== 加载 =====

  loadAll(): number {
    let count = 0
    for (const dir of this.skillDirs) {
      count += this.loadFromDir(dir)
    }
    return count
  }

  private loadFromDir(dir: string): number {
    if (!existsSync(dir)) return 0
    let count = 0
    try {
      const files = readdirSync(dir)
      for (const file of files) {
        if (file.endsWith('.yaml') || file.endsWith('.yml')) {
          try {
            const skill = this.loadSkillFile(join(dir, file))
            if (skill) {
              this.skills.set(skill.id, skill)
              count++
            }
          } catch (e) {
            console.warn(`[orion] 技能加载失败: ${file}`, e)
          }
        }
      }
    } catch { /* dir not accessible */ }
    return count
  }

  private loadSkillFile(path: string): Skill | null {
    const raw = readFileSync(path, 'utf-8')
    // 尝试 YAML 解析，失败则视为纯文本描述
    try {
      const parsed = parseYaml(raw) as any
      if (parsed?.name && parsed?.content) {
        return {
          id: parsed.id || parsed.name.toLowerCase().replace(/\s+/g, '-'),
          name: parsed.name,
          version: parsed.version || '1.0.0',
          description: parsed.description || '',
          author: parsed.author,
          tags: parsed.tags || [],
          when: {
            taskTypes: parsed.when?.taskTypes,
            filesPresent: parsed.when?.filesPresent,
            keywords: parsed.when?.keywords,
            language: parsed.when?.language,
          },
          content: parsed.content,
          requires: parsed.requires,
          usageStats: parsed.usageStats || { successCount: 0, failureCount: 0, avgDurationMs: 0 },
        }
      }
    } catch { /* fall through to text mode */ }
    return null
  }

  // ===== 查询 =====

  getSkill(id: string): Skill | undefined {
    return this.skills.get(id)
  }

  getAllSkills(): Skill[] {
    return Array.from(this.skills.values())
  }

  getSkillsByTag(tag: string): Skill[] {
    return this.getAllSkills().filter(s => s.tags.includes(tag))
  }

  // ===== 匹配 =====

  matchSkills(task: Partial<Task> & { title?: string; description?: string }): SkillMatchResult[] {
    const results: SkillMatchResult[] = []
    const text = `${task.title || ''} ${task.description || ''}`.toLowerCase()

    for (const skill of this.getAllSkills()) {
      const matchedOn: string[] = []
      let score = 0

      // 匹配任务类型
      if (skill.when.taskTypes && task.scope?.tags) {
        for (const tt of skill.when.taskTypes) {
          if (task.scope.tags.some(t => t.toLowerCase().includes(tt.toLowerCase()))) {
            score += 0.4
            matchedOn.push(`taskType:${tt}`)
          }
        }
      }

      // 匹配关键词
      if (skill.when.keywords) {
        for (const kw of skill.when.keywords) {
          if (text.includes(kw.toLowerCase())) {
            score += 0.3
            matchedOn.push(`keyword:${kw}`)
          }
        }
      }

      // 匹配语言
      if (skill.when.language && task.scope?.files) {
        const extMap: Record<string, string> = {
          '.ts': 'typescript', '.js': 'javascript', '.rs': 'rust',
          '.py': 'python', '.go': 'go', '.java': 'java',
        }
        for (const file of task.scope.files) {
          const ext = Object.keys(extMap).find(e => file.endsWith(e))
          if (ext && extMap[ext] === skill.when.language) {
            score += 0.2
            matchedOn.push(`language:${skill.when.language}`)
            break
          }
        }
      }

      if (score > 0) {
        results.push({ skill, score, matchedOn })
      }
    }

    return results.sort((a, b) => b.score - a.score)
  }

  /** 获取最佳匹配的工作流技能 */
  getBestWorkflowSkill(task: Partial<Task> & { title?: string; description?: string }): Skill | undefined {
    const matches = this.matchSkills(task)
    return matches.find(m => m.skill.content?.type === 'workflow')?.skill
  }

  /** 展开工作流：根据匹配的技能自动创建子任务 */
  expandWorkflow(parentTask: Task, skill: Skill, orchestrator: TaskOrchestrator): Task[] {
    const workflow = skill.content
    if (workflow.type !== 'workflow' || !workflow.tasks?.length) return []

    const subTasks: Task[] = []
    const idMap = new Map<string, string>() // workflow task id → actual task id

    // 第一遍：创建所有子任务
    for (const step of workflow.tasks) {
      const sub = orchestrator.createTask({
        title: step.title || `子任务: ${parentTask.title}`,
        description: step.description || '',
        priority: parentTask.priority,
        files: parentTask.scope.files,
        tags: [...parentTask.scope.tags, 'subtask', skill.id],
        dependencies: [], // 第二遍填充
      })
      idMap.set(step.id || step.title, sub.id)
      subTasks.push(sub)
      orchestrator.updateStatus(sub.id, 'pending')
    }

    // 第二遍：设置子任务之间的依赖
    for (let i = 0; i < workflow.tasks.length; i++) {
      const step = workflow.tasks[i]
      const subId = idMap.get(step.id || step.title)
      if (!subId) continue

      const deps: string[] = []
      if (step.dependencies) {
        for (const depId of step.dependencies) {
          const mapped = idMap.get(depId)
          if (mapped) deps.push(mapped)
        }
      }
      // 第一个子任务依赖父任务
      if (i === 0) {
        deps.push(parentTask.id)
      }

      if (deps.length > 0) {
        const sub = orchestrator.getTask(subId)
        if (sub) {
          orchestrator.updateTask(subId, { dependencies: deps })
        }
      }
    }

    // 父任务等待所有子任务完成
    const allSubIds = subTasks.map(t => t.id)
    orchestrator.updateTask(parentTask.id, { dependencies: [...parentTask.dependencies, ...allSubIds] })
    orchestrator.updateStatus(parentTask.id, 'deferred')

    return subTasks
  }

  /** 从已完成任务自动学习技能 */
  learnFromTask(task: Task, skillName: string): { path: string; name: string } | null {
    const dir = this.skillDirs[0]
    if (!dir) return null

    // 从任务提取关键词
    const text = `${task.title} ${task.description}`.toLowerCase()
    const keywords = this.extractKeywords(text, task.scope.tags)
    const lang = this.detectLanguage(task.scope.files)
    const slug = skillName.toLowerCase().replace(/\s+/g, '-').replace(/[^a-z0-9-]/g, '')

    const yaml = [
      `id: ${slug}`,
      `name: ${skillName}`,
      `version: 1.0.0`,
      `description: 从任务 "${task.title}" 自动学习`,
      `tags:`,
      ...task.scope.tags.map(t => `  - ${t}`),
      `when:`,
      `  keywords:`,
      ...keywords.map(k => `    - ${k}`),
    ]

    if (lang) {
      yaml.push(`  language: ${lang}`)
    }
    if (task.scope.tags.length > 0) {
      yaml.push(`  taskTypes:`)
      task.scope.tags.slice(0, 4).forEach(t => yaml.push(`    - ${t}`))
    }

    yaml.push(
      `content:`,
      `  type: workflow`,
      `  tasks:`,
      `    - title: 分析问题`,
      `      description: 阅读相关代码，理解${task.title}的上下文`,
      `    - title: 设计方案`,
      `      description: 确定实现策略和涉及的文件`,
      `    - title: 实现`,
      `      description: 编写代码实现${task.title}`,
      `    - title: 验证`,
      `      description: 检查结果是否正确`,
    )

    if (!existsSync(dir)) mkdirSync(dir, { recursive: true })
    const filePath = join(dir, `${slug}.yaml`)
    writeFileSync(filePath, yaml.join('\n'), 'utf-8')

    // 加载到内存
    this.loadFromDir(dir)

    return { path: filePath, name: skillName }
  }

  private extractKeywords(text: string, tags: string[]): string[] {
    const stopWords = new Set(['的', '了', '在', '是', '我', '有', '和', '就', '不', '人', '都', '一', '一个', '上', '也', '很', '到', '说', '要', '去', '你', '会', '着', '没有', '看', '好', '自己', '这'])
    const words = text.split(/[\s,，。.!！?？:：;；()（）\[\]【】<>《》"']+/)
    const freq = new Map<string, number>()
    for (const w of words) {
      if (w.length < 2 || stopWords.has(w)) continue
      freq.set(w, (freq.get(w) || 0) + 1)
    }
    return [...freq.entries()]
      .sort((a, b) => b[1] - a[1])
      .slice(0, 6)
      .map(([w]) => w)
  }

  private detectLanguage(files: string[]): string | undefined {
    const extMap: Record<string, string> = {
      '.ts': 'typescript', '.tsx': 'typescript', '.js': 'javascript', '.jsx': 'javascript',
      '.rs': 'rust', '.py': 'python', '.go': 'go', '.java': 'java',
      '.css': 'css', '.html': 'html', '.vue': 'typescript', '.svelte': 'javascript',
    }
    for (const f of files) {
      for (const [ext, lang] of Object.entries(extMap)) {
        if (f.endsWith(ext)) return lang
      }
    }
    return undefined
  }

  /** 给 AI 用的技能清单文本 */
  formatSkillsForPrompt(taskTitle?: string): string {
    let relevant = this.getAllSkills()
    if (taskTitle) {
      const matched = this.matchSkills({ title: taskTitle })
      relevant = matched.map(m => m.skill)
    }

    if (relevant.length === 0) return ''

    const lines = [
      '\n\n[可用技能]',
      '以下技能可用。当任务匹配时，使用 read 工具加载技能文件以获得详细指导。',
      '',
    ]
    for (const skill of relevant.slice(0, 10)) {
      const tags = skill.tags.length > 0 ? ` [${skill.tags.join(', ')}]` : ''
      lines.push(`  - ${skill.name} v${skill.version}${tags}`)
      lines.push(`    ${skill.description}`)
      if (skill.when.keywords) {
        lines.push(`    关键词: ${skill.when.keywords.join(', ')}`)
      }
      lines.push('')
    }
    return lines.join('\n')
  }
}
