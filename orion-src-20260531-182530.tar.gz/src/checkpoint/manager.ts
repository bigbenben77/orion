// Orion — CheckpointManager (断点生命周期管理)
// 当 Shield 决定暂停时，创建 checkpoint，等待用户响应

import { readFileSync, writeFileSync, existsSync, mkdirSync, readdirSync, unlinkSync } from 'node:fs'
import { join, dirname } from 'node:path'
import { randomUUID } from 'node:crypto'
import type {
  Checkpoint,
  CheckpointStatus,
  CheckpointReason,
  CheckpointMode,
  CheckpointChannel,
  CheckpointStore,
} from '../types/checkpoint.js'

const DEFAULT_STORE: CheckpointStore = {
  version: '1.0.0',
  checkpoints: {},
  metadata: { created: Date.now(), updated: Date.now() },
}

type CheckpointListener = (checkpoint: Checkpoint) => void

export class CheckpointManager {
  private store: CheckpointStore
  private storePath: string
  private listeners: CheckpointListener[] = []
  private autoMode = false
  private configPath: string

  constructor(projectRoot?: string) {
    const root = projectRoot || process.cwd()
    this.storePath = join(root, '.orion', 'checkpoints.json')
    this.configPath = join(root, '.orion', 'automation.json')
    this.store = this.loadStore()
    this.autoMode = this.loadAutoMode()
  }

  private loadAutoMode(): boolean {
    try {
      if (existsSync(this.configPath)) {
        const cfg = JSON.parse(readFileSync(this.configPath, 'utf-8'))
        return cfg.autoMode === true
      }
    } catch { /* ignore */ }
    return false
  }

  private saveAutoMode(): void {
    const dir = dirname(this.configPath)
    if (!existsSync(dir)) mkdirSync(dir, { recursive: true })
    writeFileSync(this.configPath, JSON.stringify({ autoMode: this.autoMode, updated: Date.now() }, null, 2), 'utf-8')
  }

  isAutoMode(): boolean { return this.autoMode }

  setAutoMode(enabled: boolean): void {
    this.autoMode = enabled
    this.saveAutoMode()
  }

  toggleAutoMode(): boolean {
    this.autoMode = !this.autoMode
    this.saveAutoMode()
    return this.autoMode
  }

  private loadStore(): CheckpointStore {
    try {
      if (existsSync(this.storePath)) {
        return JSON.parse(readFileSync(this.storePath, 'utf-8'))
      }
    } catch { /* fall through */ }
    return { ...DEFAULT_STORE, metadata: { created: Date.now(), updated: Date.now() } }
  }

  private save(): void {
    this.store.metadata.updated = Date.now()
    const dir = dirname(this.storePath)
    if (!existsSync(dir)) mkdirSync(dir, { recursive: true })
    writeFileSync(this.storePath, JSON.stringify(this.store, null, 2), 'utf-8')
  }

  onCheckpoint(listener: CheckpointListener): void {
    this.listeners.push(listener)
  }

  private notify(checkpoint: Checkpoint): void {
    for (const listener of this.listeners) {
      try { listener(checkpoint) } catch { /* ignore */ }
    }
  }

  // ===== 创建断点 =====

  createCheckpoint(params: {
    taskId: string
    taskTitle: string
    reason: CheckpointReason
    message: string
    suggestion?: string
    details?: string
    attempts?: number
    error?: string
    filePath?: string
    mode?: CheckpointMode
    channel?: CheckpointChannel
    timeoutMinutes?: number
  }): Checkpoint {
    const id = `cp-${randomUUID().slice(0, 8)}`
    const checkpoint: Checkpoint = {
      id,
      taskId: params.taskId,
      taskTitle: params.taskTitle,
      reason: params.reason,
      status: 'pending',
      mode: params.mode || 'suggest-and-continue',
      channel: params.channel || 'both',
      context: {
        message: params.message,
        suggestion: params.suggestion,
        details: params.details,
        attempts: params.attempts,
        error: params.error,
        filePath: params.filePath,
      },
      createdAt: Date.now(),
      expiresAt: params.timeoutMinutes
        ? Date.now() + params.timeoutMinutes * 60 * 1000
        : undefined,
    }

    this.store.checkpoints[id] = checkpoint
    this.save()
    this.notify(checkpoint)

    // 自动模式：自动响应断点，不阻塞工作流
    if (this.autoMode) {
      setImmediate(() => {
        const r = this.autoRespond(checkpoint)
        if (r) console.error(`[orion-auto] 自动模式: 断点 ${checkpoint.id} 已${r.status}`)
      })
    }

    return checkpoint
  }

  autoRespond(cp: Checkpoint): { status: CheckpointStatus; reason: string } | null {
    if (cp.status !== 'pending') return null
    const r = { timestamp: Date.now() }
    switch (cp.mode) {
      case 'notify':
        cp.status = 'skipped'; cp.respondedAt = Date.now()
        cp.response = { action: 'auto-skip', comment: '自动模式跳过', ...r }
        break
      case 'suggest-and-continue':
        cp.status = 'approved'; cp.respondedAt = Date.now()
        cp.response = { action: 'auto-approve', comment: '自动模式采纳建议', ...r }
        break
      case 'wait-for-approval':
        cp.status = 'approved'; cp.respondedAt = Date.now()
        cp.response = { action: 'auto-approve', comment: '自动模式批准', ...r }
        break
      default: return null
    }
    this.save(); this.notify(cp)
    return { status: cp.status, reason: cp.response.action }
  }

  // ===== 响应断点 =====

  respondToCheckpoint(
    id: string,
    status: CheckpointStatus,
    action?: string,
    comment?: string,
  ): Checkpoint | null {
    const cp = this.store.checkpoints[id]
    if (!cp) return null
    if (cp.status !== 'pending') return null

    cp.status = status
    cp.respondedAt = Date.now()
    cp.response = {
      action: action || status,
      comment: comment || '',
      timestamp: Date.now(),
    }

    this.save()
    this.notify(cp)
    return cp
  }

  /** 批准（自动继续） */
  approve(id: string, comment?: string): Checkpoint | null {
    return this.respondToCheckpoint(id, 'approved', 'continue', comment)
  }

  /** 拒绝（需要修改后重试） */
  reject(id: string, comment?: string): Checkpoint | null {
    return this.respondToCheckpoint(id, 'rejected', 'modify', comment)
  }

  /** 重定向（提供了新方向） */
  redirect(id: string, direction: string, comment?: string): Checkpoint | null {
    return this.respondToCheckpoint(id, 'redirected', direction, comment)
  }

  /** 跳过（不处理） */
  skip(id: string): Checkpoint | null {
    return this.respondToCheckpoint(id, 'skipped', 'skip')
  }

  // ===== 查询 =====

  getPendingCheckpoints(): Checkpoint[] {
    return Object.values(this.store.checkpoints)
      .filter(c => c.status === 'pending')
      .sort((a, b) => b.createdAt - a.createdAt)
  }

  getCheckpointsForTask(taskId: string): Checkpoint[] {
    return Object.values(this.store.checkpoints)
      .filter(c => c.taskId === taskId)
      .sort((a, b) => b.createdAt - a.createdAt)
  }

  getAllCheckpoints(): Checkpoint[] {
    return Object.values(this.store.checkpoints)
      .sort((a, b) => b.createdAt - a.createdAt)
  }

  getUnresolvedCount(): number {
    return this.getPendingCheckpoints().length
  }

  /** 清理过期的断点（超时未响应） */
  cleanupExpired(): number {
    let count = 0
    const now = Date.now()
    for (const cp of Object.values(this.store.checkpoints)) {
      if (cp.status === 'pending' && cp.expiresAt && now > cp.expiresAt) {
        cp.status = 'timeout'
        cp.respondedAt = now
        cp.response = { action: 'timeout', comment: '超时未响应', timestamp: now }
        count++
      }
    }
    if (count > 0) this.save()
    return count
  }

  /** 删除已完成的断点 */
  cleanCompleted(olderThanMs?: number): number {
    const cutoff = olderThanMs ?? 24 * 60 * 60 * 1000 // 默认 24 小时
    const now = Date.now()
    const toDelete: string[] = []

    for (const [id, cp] of Object.entries(this.store.checkpoints)) {
      if (cp.status !== 'pending' && cp.respondedAt && (now - cp.respondedAt) > cutoff) {
        toDelete.push(id)
      }
    }

    for (const id of toDelete) {
      delete this.store.checkpoints[id]
    }

    if (toDelete.length > 0) this.save()
    return toDelete.length
  }

  /** 生成断点报告 */
  getStats(): { pending: number; approved: number; rejected: number; total: number } {
    const stats = { pending: 0, approved: 0, rejected: 0, total: 0 }
    for (const cp of Object.values(this.store.checkpoints)) {
      stats.total++
      if (cp.status === 'pending') stats.pending++
      else if (cp.status === 'approved') stats.approved++
      else if (cp.status === 'rejected' || cp.status === 'redirected') stats.rejected++
    }
    return stats
  }
}

// ===== 断点消息格式化 =====

export function formatCheckpointTerminal(checkpoint: Checkpoint): string {
  const reasonLabels: Record<string, string> = {
    'test-failure': '🧪 测试失败',
    'threshold-reached': '⚠️ 达到失败阈值',
    'task-complete': '✅ 任务完成',
    'new-file-creation': '📄 创建新文件',
    'loop-detected': '🔄 检测到循环',
    'dependency-change': '📦 依赖变更',
    'context-too-large': '📏 上下文过大',
    'manual-breakpoint': '✋ 手动断点',
  }

  const modeHints: Record<string, string> = {
    'notify': '（仅通知）',
    'wait-for-approval': '（等待确认）',
    'suggest-and-continue': '（建议已生成，可继续）',
  }

  const lines = [
    '',
    '━'.repeat(50),
    `📌 人类断点 [${checkpoint.id}]`,
    `${reasonLabels[checkpoint.reason] || checkpoint.reason} ${modeHints[checkpoint.mode] || ''}`,
    '',
    `任务: [${checkpoint.taskId}] ${checkpoint.taskTitle}`,
    `消息: ${checkpoint.context.message}`,
  ]

  if (checkpoint.context.suggestion) {
    lines.push('')
    lines.push(`建议: ${checkpoint.context.suggestion}`)
  }
  if (checkpoint.context.error) {
    lines.push(`错误: ${checkpoint.context.error}`)
  }
  if (checkpoint.context.attempts) {
    lines.push(`已尝试: ${checkpoint.context.attempts} 次`)
  }

  if (checkpoint.mode === 'wait-for-approval') {
    lines.push('')
    lines.push(`响应命令:`)
    lines.push(`  批准: orion checkpoint approve ${checkpoint.id} [备注]`)
    lines.push(`  拒绝: orion checkpoint reject ${checkpoint.id} [修改意见]`)
    lines.push(`  重定向: orion checkpoint redirect ${checkpoint.id} <新方向>`)
  }

  lines.push('━'.repeat(50))
  lines.push('')
  return lines.join('\n')
}
