// Orion — 技能系统类型定义

export interface Skill {
  id: string
  name: string
  version: string
  description: string
  author?: string
  tags: string[]

  // 匹配条件
  when: {
    taskTypes?: string[]
    filesPresent?: string[]
    keywords?: string[]
    language?: string
  }

  // 技能内容
  content: SkillContent

  // 依赖
  requires?: {
    bins?: string[]
    packages?: string[]
    env?: string[]
  }

  // 使用统计
  usageStats: {
    successCount: number
    failureCount: number
    avgDurationMs: number
  }
}

export type SkillContent =
  | { type: 'prompt'; system: string; user?: string }
  | { type: 'workflow'; tasks: SkillTaskTemplate[] }
  | { type: 'tool'; toolName: string; config: Record<string, unknown> }
  | { type: 'multi'; steps: SkillStep[] }

export interface SkillTaskTemplate {
  id: string
  title: string
  description: string
  prompt?: string
  dependencies: string[]
  estimatedDuration?: number
}

export interface SkillStep {
  name: string
  tool?: string
  params?: Record<string, unknown>
  prompt?: string
  description?: string
}

export interface SkillMatchResult {
  skill: Skill
  score: number
  matchedOn: string[]
}
