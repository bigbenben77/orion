// Orion — 保护层类型定义

export interface LoopDetectorState {
  history: ActionRecord[]
  patterns: DetectedPattern[]
}

export interface ActionRecord {
  timestamp: number
  tool: string
  params?: string
  result: 'success' | 'failure' | 'timeout'
  file?: string
}

export type LoopPatternType =
  | 'same-tool-repeat'
  | 'fix-fail-cycle'
  | 'file-churn'
  | 'ping-pong'

export interface DetectedPattern {
  type: LoopPatternType
  count: number
  threshold: number
  details: string
}

export type LoopResponseLevel = 'warn' | 'escalate' | 'critical'

export interface LoopResponse {
  level: LoopResponseLevel
  action: 'notify' | 'pause-and-ask' | 'stop-and-wait'
  message: string
  question?: string
}

export interface FailureThresholdConfig {
  maxToolCallsPerTask: number
  maxRetriesPerAction: number
  maxConsecutiveFailures: number
  maxDurationMs: number
  maxCost?: number
}

export interface HumanCheckpointConfig {
  triggers: {
    onTaskComplete: boolean
    onTestFailure: boolean
    onNewFileCreation: boolean
    onThresholdReached: boolean
  }
  mode: 'notify' | 'wait-for-approval' | 'suggest-and-continue'
  channel: 'terminal' | 'web'
}

export interface AgentLimits {
  maxIterations: number
  maxContextRestarts: number
  contextThreshold: number       // 0–1, 当前窗口达到此比例触发重启
  wrapUpAtContext: number        // 0–1, 累计用量达到此比例提示收尾
}

export interface ShieldConfig {
  enabled: boolean
  loopDetection: {
    enabled: boolean
    historySize: number
    warningThreshold: number
    criticalThreshold: number
  }
  failureThreshold: FailureThresholdConfig
  humanCheckpoints: HumanCheckpointConfig
  permissions: PermissionConfig
  agentLimits: AgentLimits
}

// ===== 权限系统 =====

export type PermissionLevel = 'safe' | 'moderate' | 'dangerous'
export type PermissionMode = 'strict' | 'normal' | 'permissive'

export interface PermissionConfig {
  mode: PermissionMode
  rules: Record<string, PermissionLevel>  // toolName → level overrides
}

export interface PermissionCheckResult {
  allowed: boolean
  requireApproval: boolean
  reason?: string
}

export const DEFAULT_PERMISSION_LEVELS: Record<string, PermissionLevel> = {
  read_file: 'safe',
  list_files: 'safe',
  search_code: 'safe',
  execute_command: 'moderate',
  write_file: 'moderate',
  edit_file: 'moderate',
}

export function getPermissionLevel(tool: string, config: PermissionConfig): PermissionLevel {
  return config.rules[tool] || DEFAULT_PERMISSION_LEVELS[tool] || 'dangerous'
}

export function checkPermissionByMode(level: PermissionLevel, mode: PermissionMode): PermissionCheckResult {
  switch (mode) {
    case 'strict':
      // strict: 只自动批准 safe，moderate 需要审批，dangerous 拒绝
      if (level === 'safe') return { allowed: true, requireApproval: false }
      if (level === 'moderate') return { allowed: true, requireApproval: true, reason: `操作需要审批 (模式: 严格, 级别: ${level})` }
      return { allowed: false, requireApproval: false, reason: `危险操作已阻止 (模式: 严格, 级别: ${level})` }
    case 'normal':
      // normal: safe+moderate 自动批准，dangerous 需要审批
      if (level === 'safe' || level === 'moderate') return { allowed: true, requireApproval: false }
      return { allowed: true, requireApproval: true, reason: `危险操作需要审批 (级别: ${level})` }
    case 'permissive':
    default:
      // permissive: 全部自动批准
      return { allowed: true, requireApproval: false }
  }
}
