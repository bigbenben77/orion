// Orion — 记忆系统类型定义

export type MemoryType =
  | 'session'       // 会话记录
  | 'decision'      // 重要决策
  | 'preference'    // 用户偏好
  | 'pattern'       // 代码/工作模式
  | 'fact'          // 项目关键事实
  | 'error'         // 值得记住的错误
  | 'summary'       // 会话摘要

export interface Memory {
  id: string
  type: MemoryType
  content: string
  summary?: string        // 摘要版本（省 token 用）
  tags: string[]
  importance: number      // 1-10，越高越重要
  timestamp: number
  accessedCount: number
  lastAccessed: number
  sessionId?: string
  source?: string         // 来源（任务 ID / 会话 ID）
}

export interface MemoryStore {
  version: string
  memories: Memory[]
  metadata: {
    created: number
    updated: number
    totalMemories: number
    totalSessions: number
  }
}

export interface MemorySearchResult {
  memory: Memory
  relevance: number       // 0-1 相关度
  matchedTags: string[]
}
