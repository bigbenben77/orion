// Orion — Checkpoint 数据模型
// 人类断点的核心类型定义

export type CheckpointReason =
  | 'test-failure'        // 测试失败
  | 'threshold-reached'   // 达到重试/失败上限
  | 'task-complete'       // 任务完成，需要审查
  | 'new-file-creation'   // 创建了新文件
  | 'loop-detected'       // AI 检测到循环
  | 'dependency-change'   // 修改了依赖
  | 'context-too-large'   // 上下文过大
  | 'manual-breakpoint'   // 用户手动设置的断点

export type CheckpointStatus =
  | 'pending'     // 等待用户响应
  | 'approved'    // 用户批准继续
  | 'rejected'    // 用户拒绝，需要修改
  | 'redirected'  // 用户提供了新方向
  | 'timeout'     // 用户超时未响应
  | 'skipped'     // 用户跳过了这个断点

export type CheckpointChannel = 'terminal' | 'web' | 'both'

export type CheckpointMode = 'notify' | 'wait-for-approval' | 'suggest-and-continue'

export interface Checkpoint {
  id: string
  taskId: string
  taskTitle: string
  reason: CheckpointReason
  status: CheckpointStatus
  mode: CheckpointMode
  channel: CheckpointChannel

  // 断点上下文
  context: {
    message: string
    suggestion?: string
    details?: string
    attempts?: number
    error?: string
    filePath?: string
  }

  // 用户响应
  response?: {
    action: string
    comment: string
    timestamp: number
  }

  // 元数据
  createdAt: number
  respondedAt?: number
  expiresAt?: number
}

export interface CheckpointStore {
  version: string
  checkpoints: Record<string, Checkpoint>
  metadata: {
    created: number
    updated: number
  }
}
