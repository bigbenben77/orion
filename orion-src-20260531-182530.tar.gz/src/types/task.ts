// Orion — 任务系统类型定义

export type TaskMode = 'code' | 'architect' | 'ask' | 'debug'

export type TaskStatus =
  | 'pending'
  | 'ready'
  | 'in-progress'
  | 'review'
  | 'blocked'
  | 'done'
  | 'cancelled'
  | 'deferred'
  | 'paused'

export interface TaskAttempt {
  timestamp: number
  result: 'success' | 'failure' | 'timeout'
  error?: string
  durationMs: number
}

export interface TaskVersion {
  commitHash: string
  timestamp: number
  description: string
  filesChanged: string[]
  attemptIndex: number  // 对应 attempts[] 的索引
}

export interface Task {
  id: string
  displayId?: string          // 层级显示 ID: "1", "1.2", "1.2.3"
  title: string
  description: string
  status: TaskStatus
  dependencies: string[]
  priority: 'low' | 'medium' | 'high' | 'critical'

  // 层级结构
  parentId?: string           // 父任务 ID
  subtaskIds: string[]        // 子任务 ID 列表
  details?: string            // 实现细节/笔记
  testStrategy?: string       // 测试策略

  // 执行模式
  mode: TaskMode

  // 上下文控制
  scope: {
    files: string[]
    relatedTasks: string[]
    tags: string[]
    skills: string[]
  }

  // 执行控制
  attempts: TaskAttempt[]
  maxRetries: number
  autoFix: boolean

  // 验收标准
  acceptance: {
    criteria: string[]
    tests: string[]
  }

  // 版本历史
  versions?: TaskVersion[]

  // 产出目录
  outputDir?: string

  // 元数据
  created: number
  updated: number
  duration?: number
  owner?: string
  blockedReason?: string
  assignedProvider?: string
}

export interface TaskStore {
  version: string
  tasks: Record<string, Task>
  metadata: {
    lastTaskId: number
    created: number
    updated: number
    projectName?: string
  }
}
