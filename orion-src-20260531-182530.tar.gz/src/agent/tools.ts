// Orion — Agent 工具系统
// 工具定义 + 执行器 + API 格式转换

import { readFileSync, writeFileSync, readdirSync, existsSync, statSync, mkdirSync } from 'node:fs'
import { execSync, spawnSync } from 'node:child_process'
import { join, resolve, relative } from 'node:path'

// ===== 工具定义 =====

export interface ToolDef {
  name: string
  description: string
  parameters: {
    type: 'object'
    properties: Record<string, { type: string; description: string }>
    required?: string[]
  }
}

export interface ToolCall {
  id: string
  name: string
  input: Record<string, any>
}

export interface ToolResult {
  toolCallId: string
  content: string
  error?: string
}

export interface FileChange {
  path: string
  oldContent: string | null
}

export const ALL_TOOLS: ToolDef[] = [
  {
    name: 'read_file',
    description: '读取文件内容。用于理解现有代码后再修改。',
    parameters: {
      type: 'object',
      properties: {
        path: { type: 'string', description: '相对于项目根目录的文件路径' },
        offset: { type: 'number', description: '起始行号（1-indexed，可选）' },
        limit: { type: 'number', description: '读取行数上限（默认 200，最大 500）' },
      },
      required: ['path'],
    },
  },
  {
    name: 'write_file',
    description: '创建或覆盖文件。会自动创建父目录。用于新建文件或完整重写。',
    parameters: {
      type: 'object',
      properties: {
        path: { type: 'string', description: '相对于项目根目录的文件路径' },
        content: { type: 'string', description: '文件完整内容' },
      },
      required: ['path', 'content'],
    },
  },
  {
    name: 'edit_file',
    description: '精确编辑文件。搜索 old_string 并替换为 new_string。支持多级回退匹配和 SEARCH/REPLACE 块语法。',
    parameters: {
      type: 'object',
      properties: {
        path: { type: 'string', description: '相对于项目根目录的文件路径' },
        old_string: { type: 'string', description: '要替换的文本。支持 <<<<<<< SEARCH / ======= / >>>>>>> REPLACE 块语法' },
        new_string: { type: 'string', description: '替换后的文本（使用 SEARCH/REPLACE 块时可选）' },
        replace_all: { type: 'boolean', description: '替换所有匹配项（默认 false，要求唯一匹配）' },
      },
      required: ['path', 'old_string'],
    },
  },
  {
    name: 'execute_command',
    description: '在项目根目录执行 shell 命令。超时 30 秒，输出上限 10KB。禁止 rm/sudo/chmod 等危险操作。',
    parameters: {
      type: 'object',
      properties: {
        command: { type: 'string', description: '要执行的 shell 命令' },
      },
      required: ['command'],
    },
  },
  {
    name: 'list_files',
    description: '列出目录内容。用于了解项目结构。',
    parameters: {
      type: 'object',
      properties: {
        path: { type: 'string', description: '相对于项目根目录的路径（默认 "."）' },
      },
      required: ['path'],
    },
  },
  {
    name: 'search_code',
    description: '在代码中搜索文本或正则表达式。返回匹配的文件和行。',
    parameters: {
      type: 'object',
      properties: {
        pattern: { type: 'string', description: '搜索文本或正则表达式' },
        path: { type: 'string', description: '搜索子目录（默认项目根目录）' },
      },
      required: ['pattern'],
    },
  },
]

// ===== 模式工具过滤 =====

const MODE_TOOLS: Record<string, string[]> = {
  architect: ['read_file', 'list_files', 'search_code', 'execute_command'],
  ask: ['read_file', 'list_files', 'search_code'],
  debug: ['read_file', 'list_files', 'search_code', 'execute_command', 'edit_file', 'write_file'],
  code: ['read_file', 'list_files', 'search_code', 'execute_command', 'edit_file', 'write_file'],
}

export function getToolsForMode(mode: string): ToolDef[] {
  const allowed = MODE_TOOLS[mode] || MODE_TOOLS.code
  return ALL_TOOLS.filter(t => allowed.includes(t.name))
}

// ===== API 格式转换 =====

export function toAnthropicTools(): any[] {
  return ALL_TOOLS.map(t => ({
    name: t.name,
    description: t.description,
    input_schema: {
      type: 'object',
      properties: t.parameters.properties,
      required: t.parameters.required,
    },
  }))
}

export function toOpenAITools(): any[] {
  return ALL_TOOLS.map(t => ({
    type: 'function',
    function: {
      name: t.name,
      description: t.description,
      parameters: {
        type: 'object',
        properties: t.parameters.properties,
        required: t.parameters.required,
      },
    },
  }))
}

export function toAnthropicToolsForMode(mode: string): any[] {
  return getToolsForMode(mode).map(t => ({
    name: t.name,
    description: t.description,
    input_schema: {
      type: 'object',
      properties: t.parameters.properties,
      required: t.parameters.required,
    },
  }))
}

export function toOpenAIToolsForMode(mode: string): any[] {
  return getToolsForMode(mode).map(t => ({
    type: 'function',
    function: {
      name: t.name,
      description: t.description,
      parameters: {
        type: 'object',
        properties: t.parameters.properties,
        required: t.parameters.required,
      },
    },
  }))
}

// ===== 工具执行 =====

export interface ToolContext {
  projectRoot: string
  snapshots?: FileChange[]
  cache?: Map<string, ToolResult>
}

const DANGEROUS_COMMANDS = /\b(rm\s+-rf|sudo|chmod\s+777|mkfs|dd\s+if|:\(\)\s*\{|>\/dev\/sda|shutdown|reboot)\b/i
const WINDOWS_DANGEROUS = /\bformat\s+[a-zA-Z]:\b/i

export function executeTool(call: ToolCall, ctx: ToolContext): ToolResult {
  const { projectRoot, snapshots, cache } = ctx
  const READ_ONLY = new Set(['read_file', 'list_files', 'search_code'])

  // 缓存命中（仅读操作）
  if (READ_ONLY.has(call.name) && cache) {
    const key = `${call.name}:${JSON.stringify(call.input)}`
    const cached = cache.get(key)
    if (cached) {
      // 返回缓存的副本，但更新 toolCallId
      return { ...cached, toolCallId: call.id }
    }
  }

  try {
    let output = ''
    switch (call.name) {
      case 'read_file':
        output = execReadFile(projectRoot, call.input)
        break
      case 'write_file':
        snapshotBeforeWrite(projectRoot, call.input.path, snapshots)
        output = execWriteFile(projectRoot, call.input)
        invalidateCache(cache, call.input.path)
        break
      case 'edit_file':
        snapshotBeforeWrite(projectRoot, call.input.path, snapshots)
        output = execEditFile(projectRoot, call.input)
        invalidateCache(cache, call.input.path)
        break
      case 'execute_command':
        output = execCommand(projectRoot, call.input)
        break
      case 'list_files':
        output = execListFiles(projectRoot, call.input)
        break
      case 'search_code':
        output = execSearchCode(projectRoot, call.input)
        break
      default:
        return { toolCallId: call.id, content: '', error: `未知工具: ${call.name}` }
    }

    const result: ToolResult = { toolCallId: call.id, content: output }

    // 缓存读操作结果
    if (READ_ONLY.has(call.name) && cache) {
      const key = `${call.name}:${JSON.stringify(call.input)}`
      cache.set(key, result)
    }

    return result
  } catch (e: any) {
    return { toolCallId: call.id, content: '', error: e.message }
  }
}

function invalidateCache(cache: Map<string, any> | undefined, filePath: string | undefined): void {
  if (!cache || !filePath) return
  // 清除所有以该文件路径为参数的读操作缓存
  for (const key of cache.keys()) {
    if (key.includes(JSON.stringify(filePath))) {
      cache.delete(key)
    }
  }
}

function safePath(projectRoot: string, userPath: string): string {
  const resolved = resolve(projectRoot, userPath)
  // 防止目录遍历
  const rel = relative(projectRoot, resolved)
  if (rel.startsWith('..') || resolve(rel) !== resolved) {
    throw new Error(`路径越界: ${userPath}`)
  }
  return resolved
}

// 跟踪哪些项目已在本次进程生命周期内做过 git 备份，以及对应的 commit hash
const _gitBackupHashes = new Map<string, string>()

function gitAutoBackup(root: string): string {
  const existing = _gitBackupHashes.get(root)
  if (existing !== undefined) return existing
  try {
    const gitDir = join(root, '.git')
    if (!existsSync(gitDir)) { _gitBackupHashes.set(root, ''); return '' }
    const status = execSync('git status --porcelain', { cwd: root, encoding: 'utf-8', timeout: 5000, windowsHide: true })
    if (!status.trim()) { _gitBackupHashes.set(root, ''); return '' }
    execSync('git add -u', { cwd: root, encoding: 'utf-8', timeout: 5000, windowsHide: true })
    const taskId = (process.env.ORION_CURRENT_TASK || '').replace(/[^a-zA-Z0-9_-]/g, '')
    const label = taskId ? `auto-backup: task ${taskId}` : 'auto-backup: before Orion task changes'
    execSync(`git commit -m "${label}"`, { cwd: root, encoding: 'utf-8', timeout: 5000, windowsHide: true })
    const hash = execSync('git rev-parse HEAD', { cwd: root, encoding: 'utf-8', timeout: 3000, windowsHide: true }).trim()
    _gitBackupHashes.set(root, hash)
    return hash
  } catch {
    _gitBackupHashes.set(root, '')
    return ''
  }
}

export function getGitBackupHash(root: string): string {
  return _gitBackupHashes.get(root) || ''
}

function snapshotBeforeWrite(root: string, relPath: string | undefined, snapshots?: FileChange[]): void {
  if (!snapshots || !relPath) return
  // 第一次修改前，自动 git commit 备份当前状态
  gitAutoBackup(root)
  // 检查是否已记录过该文件的快照（同一执行中只保留第一次快照）
  if (snapshots.some(s => s.path === relPath)) return
  try {
    const filePath = safePath(root, relPath)
    const oldContent = existsSync(filePath) ? readFileSync(filePath, 'utf-8') : null
    snapshots.push({ path: relPath, oldContent })
  } catch {
    // 读取失败时不记录快照（回滚会跳过该文件）
  }
}

export function rollbackChanges(root: string, changes: FileChange[]): { restored: string[]; failed: string[]; gitReset?: boolean } {
  // 优先尝试 git reset（最彻底，覆盖 Orion 改动 + 任务自身可能产生的中间状态）
  try {
    const gitDir = join(root, '.git')
    if (existsSync(gitDir)) {
      const log = execSync('git log --oneline -1', { cwd: root, encoding: 'utf-8', timeout: 5000, windowsHide: true })
      if (log.includes('auto-backup: before Orion task changes')) {
        execSync('git reset --hard HEAD~1', { cwd: root, encoding: 'utf-8', timeout: 10000, windowsHide: true })
        return { restored: ['git reset --hard 完成，已回退到任务执行前'], failed: [], gitReset: true }
      }
    }
  } catch {
    // git 回滚失败时回退到文件快照回滚
  }

  // 文件快照回滚
  const restored: string[] = []
  const failed: string[] = []
  for (const change of changes) {
    try {
      const filePath = join(root, change.path)
      if (change.oldContent === null) {
        if (existsSync(filePath)) {
          writeFileSync(filePath, '', 'utf-8')
          restored.push(change.path + ' (已清空/删除)')
        } else {
          restored.push(change.path + ' (原本即不存在)')
        }
      } else {
        writeFileSync(filePath, change.oldContent, 'utf-8')
        restored.push(change.path)
      }
    } catch (e: any) {
      failed.push(change.path + ': ' + (e.message || 'unknown'))
    }
  }
  return { restored, failed }
}

/** 清除 git 备份标记（任务完成后调用，防止回滚到更早的状态） */
export function releaseGitBackup(root: string): void {
  _gitBackupHashes.delete(root)
}

function execReadFile(root: string, input: Record<string, any>): string {
  const filePath = safePath(root, String(input.path || ''))
  if (!existsSync(filePath)) return `文件不存在: ${input.path}`
  const stat = statSync(filePath)
  if (stat.isDirectory()) return `这是一个目录: ${input.path}`
  if (stat.size > 1024 * 1024) return `文件过大 (${(stat.size / 1024).toFixed(0)}KB)，请用 offset/limit 分段读取`

  const content = readFileSync(filePath, 'utf-8')
  const lines = content.split('\n')
  const offset = Math.max(1, parseInt(input.offset) || 1)
  const limit = Math.min(500, parseInt(input.limit) || 200)
  const slice = lines.slice(offset - 1, offset - 1 + limit)

  const totalLines = lines.length
  const header = `## ${input.path} (行 ${offset}-${Math.min(offset + limit - 1, totalLines)} / 共 ${totalLines} 行)\n\n`
  return header + slice.map((l, i) => `${offset + i}: ${l}`).join('\n')
}

function execWriteFile(root: string, input: Record<string, any>): string {
  const relPath = String(input.path || '')
  if (!relPath) throw new Error(`路径为空`)
  const content = String(input.content || '')
  if (content.length > 50000) throw new Error(`内容过大 (${content.length} 字符)，超过 50KB 上限`)

  const filePath = safePath(root, relPath)
  const parent = join(filePath, '..')
  if (!existsSync(parent)) mkdirSync(parent, { recursive: true })

  const existed = existsSync(filePath)
  writeFileSync(filePath, content, 'utf-8')
  const action = existed ? '已更新' : '已创建'
  return `${action}: ${relPath} (${content.split('\n').length} 行, ${content.length} 字符)`
}

function execEditFile(root: string, input: Record<string, any>): string {
  const filePath = safePath(root, String(input.path || ''))
  if (!existsSync(filePath)) return `文件不存在: ${input.path}`

  let oldStr = String(input.old_string || '')
  let newStr = String(input.new_string || '')
  const replaceAll = input.replace_all === true

  // 尝试解析 SEARCH/REPLACE 块语法
  const block = parseSearchReplaceBlock(oldStr)
  if (block) {
    oldStr = block.search
    newStr = block.replace
  }

  if (!oldStr) return `错误: old_string 为空`

  const content = readFileSync(filePath, 'utf-8')
  let pos = -1
  let positions: number[] = []
  let matchTier = 'exact'
  const tiers: string[] = []

  // Tier 1: 精确匹配
  const exact = countMatches(content, oldStr)
  if (exact.count > 0) {
    pos = exact.firstPos
    positions = exact.allPositions
    tiers.push('exact')
  }

  // Tier 2: 空白容忍匹配（去掉行尾空白、归一化缩进）
  if (pos === -1) {
    const wsResult = tryWhitespaceMatch(content, oldStr)
    if (wsResult) {
      pos = wsResult.position
      positions = wsResult.positions
      matchTier = 'whitespace'
      tiers.push('whitespace')
      // 用实际文件中的文本替换 oldStr，保证后续替换正确
      if (wsResult.actualText) oldStr = wsResult.actualText
    }
  }

  // Tier 3: 模糊行匹配（Levenshtein 距离）
  if (pos === -1) {
    const fuzzy = tryFuzzyMatch(content, oldStr)
    if (fuzzy) {
      pos = fuzzy.position
      positions = fuzzy.positions
      matchTier = `fuzzy (相似度 ${(fuzzy.similarity * 100).toFixed(0)}%)`
      tiers.push('fuzzy')
      if (fuzzy.actualText) oldStr = fuzzy.actualText
    }
  }

  if (pos === -1) {
    return buildNoMatchError(content, oldStr, tiers)
  }

  // 检查唯一性（非 replace_all 模式）
  if (!replaceAll && positions.length > 1) {
    return `错误: old_string 在文件中出现了 ${positions.length} 次，不够唯一。请包含更多上下文使其唯一，或设置 replace_all: true。`
  }

  // 执行替换
  let newContent: string
  if (replaceAll && positions.length > 1) {
    newContent = applyReplaceAll(content, positions, oldStr, newStr)
  } else {
    newContent = content.substring(0, pos) + newStr + content.substring(pos + oldStr.length)
  }
  writeFileSync(filePath, newContent, 'utf-8')

  const beforeLines = content.substring(0, pos).split('\n')
  const lineNum = beforeLines.length
  const oldLines = oldStr.split('\n').length
  const newLines = newStr.split('\n').length
  const replaced = replaceAll && positions.length > 1 ? ` (${positions.length} 处)` : ''

  let result = `已编辑: ${input.path}\n行 ${lineNum}: ${oldLines} 行 → ${newLines} 行${replaced}`
  if (matchTier !== 'exact') {
    result += `\n匹配方式: ${matchTier}`
  }
  return result
}

function execCommand(root: string, input: Record<string, any>): string {
  const cmd = String(input.command || '')
  if (!cmd.trim()) return '空命令'
  if (DANGEROUS_COMMANDS.test(cmd)) return `危险命令已拦截: ${cmd}`
  if (process.platform === 'win32' && WINDOWS_DANGEROUS.test(cmd)) return `危险命令已拦截: ${cmd}`

  const shell = process.platform === 'win32' ? 'cmd.exe' : '/bin/sh'
  const shellFlag = process.platform === 'win32' ? '/c' : '-c'

  try {
    const result = spawnSync(shell, [shellFlag, cmd], {
      cwd: root,
      timeout: 30000,
      maxBuffer: 10240,
      encoding: 'utf-8',
      windowsHide: true,
    })

    const stdout = (result.stdout || '').trim()
    const stderr = (result.stderr || '').trim()
    const exitCode = result.status ?? (result.error ? -1 : 0)

    let output = ''
    if (stdout) {
      const truncated = stdout.length > 6000 ? stdout.slice(0, 6000) + '\n... [stdout truncated]' : stdout
      output += truncated
    }
    if (stderr) {
      const truncated = stderr.length > 2000 ? stderr.slice(0, 2000) + '\n... [stderr truncated]' : stderr
      output += (output ? '\n' : '') + `[stderr]\n${truncated}`
    }

    if (exitCode !== 0) {
      output += (output ? '\n' : '') + `[exit code: ${exitCode}]`
      const patterns = detectErrorPatterns(stdout + '\n' + stderr)
      if (patterns) output += `\n[检测到: ${patterns}]`
    }

    return output || '(执行成功，无输出)'
  } catch (e: any) {
    return `命令执行异常: ${(e.message || '未知错误').slice(0, 500)}`
  }
}

function detectErrorPatterns(output: string): string | null {
  const patterns: string[] = []
  if (/error TS\d+:/i.test(output)) patterns.push('TypeScript 编译错误')
  if (/\d+ failing/.test(output) || /\bFAIL\b/.test(output)) patterns.push('测试失败')
  if (/ESLint|prettier/i.test(output)) patterns.push('代码规范问题')
  if (/\bfatal:\b/i.test(output)) patterns.push('致命错误')
  if (/cannot find module/i.test(output)) patterns.push('模块未找到')
  if (/permission denied/i.test(output)) patterns.push('权限拒绝')
  if (/out of memory/i.test(output)) patterns.push('内存不足')
  return patterns.length > 0 ? patterns.join(', ') : null
}

function execListFiles(root: string, input: Record<string, any>): string {
  const dirPath = safePath(root, String(input.path || '.'))
  if (!existsSync(dirPath)) return `目录不存在: ${input.path}`
  const stat = statSync(dirPath)
  if (!stat.isDirectory()) return `不是目录: ${input.path}`

  const entries = readdirSync(dirPath, { withFileTypes: true })
  const lines: string[] = []
  for (const e of entries.slice(0, 100)) {
    const type = e.isDirectory() ? '/' : ''
    const size = e.isFile() ? formatSize(statSync(join(dirPath, e.name)).size) : ''
    lines.push(`${e.name}${type} ${size}`.trimEnd())
  }
  const header = `## ${input.path || '.'} (${entries.length} 项${entries.length > 100 ? '，显示前 100 项' : ''})\n\n`
  return header + lines.join('\n')
}

function execSearchCode(root: string, input: Record<string, any>): string {
  const pattern = String(input.pattern || '')
  const searchDir = input.path ? safePath(root, String(input.path)) : root
  if (!existsSync(searchDir)) return `目录不存在: ${input.path || '.'}`

  // Use spawnSync with argument arrays to avoid shell injection
  try {
    const result = spawnSync('rg', ['-n', '--max-count=3', '-e', pattern, searchDir], {
      cwd: root, timeout: 10000, maxBuffer: 20480, encoding: 'utf-8', windowsHide: true,
    })
    if (result.status === 1) return `未找到匹配 "${pattern}"`
    if (result.error) throw result.error
    const lines = result.stdout.split('\n').filter(Boolean)
    if (lines.length === 0) return `未找到匹配 "${pattern}"`
    return `搜索 "${pattern}":\n${lines.slice(0, 30).join('\n')}${lines.length > 30 ? `\n... 还有 ${lines.length - 30} 个结果` : ''}`
  } catch {
    // rg not available, fallback to platform-native tools
  }

  if (process.platform === 'win32') {
    try {
      const result = spawnSync('findstr', ['/s', '/n', '/c:' + pattern, searchDir + '\\*.*'], {
        timeout: 10000, maxBuffer: 20480, encoding: 'utf-8', windowsHide: true,
      })
      if (result.error) throw result.error
      if (!result.stdout.trim()) return `未找到匹配 "${pattern}"`
      return `搜索 "${pattern}":\n${result.stdout.slice(0, 8000)}`
    } catch {
      return `未找到匹配 "${pattern}" (rg 和 findstr 均不可用)`
    }
  }

  // Linux/macOS: fallback to grep
  try {
    const result = spawnSync('grep', ['-rn', '--max-count=3', '-e', pattern, searchDir], {
      timeout: 10000, maxBuffer: 20480, encoding: 'utf-8',
    })
    if (result.status === 1) return `未找到匹配 "${pattern}"`
    if (result.error) throw result.error
    const lines = result.stdout.split('\n').filter(Boolean)
    if (lines.length === 0) return `未找到匹配 "${pattern}"`
    return `搜索 "${pattern}":\n${lines.slice(0, 30).join('\n')}${lines.length > 30 ? `\n... 还有 ${lines.length - 30} 个结果` : ''}`
  } catch {
    return `未找到匹配 "${pattern}" (rg 和 grep 均不可用)`
  }
}

// ===== 智能编辑辅助函数 =====

interface MatchResult {
  position: number
  positions: number[]
  actualText?: string
  similarity?: number
  count: number
  firstPos: number
  allPositions: number[]
}

function countMatches(content: string, search: string): { count: number; firstPos: number; allPositions: number[] } {
  let count = 0
  let pos = -1
  const all: number[] = []
  let idx = 0
  while ((idx = content.indexOf(search, idx)) !== -1) {
    if (count === 0) pos = idx
    count++
    all.push(idx)
    idx++
  }
  return { count, firstPos: pos, allPositions: all }
}

function parseSearchReplaceBlock(input: string): { search: string; replace: string } | null {
  const m = input.match(/^<<<<<<< SEARCH\s*\n([\s\S]*?)\n?=======\s*\n([\s\S]*?)\n?>>>>>>> REPLACE\s*$/)
  if (!m) return null
  return { search: m[1], replace: m[2] }
}

function normalizeLines(text: string): string {
  return text.split('\n').map(l => l.trimEnd()).join('\n')
}

function tryWhitespaceMatch(content: string, search: string): { position: number; positions: number[]; actualText?: string } | null {
  const normalized = normalizeLines(search)
  const contentLines = content.split('\n')
  const searchLines = normalized.split('\n')

  // 在内容中滑动搜索窗口
  for (let i = 0; i <= contentLines.length - searchLines.length; i++) {
    const window = contentLines.slice(i, i + searchLines.length)
    const windowNorm = window.map(l => l.trimEnd()).join('\n')
    if (windowNorm === normalized) {
      const position = contentLines.slice(0, i).join('\n').length + (i > 0 ? 1 : 0)
      const actualText = window.join('\n')
      // 查找所有匹配
      const positions: number[] = []
      let scanIdx = 0
      while ((scanIdx = content.indexOf(actualText, scanIdx)) !== -1) {
        positions.push(scanIdx)
        scanIdx++
      }
      return { position, positions, actualText }
    }
  }
  return null
}

function levenshtein(a: string, b: string): number {
  const m = a.length, n = b.length
  if (m === 0) return n
  if (n === 0) return m
  // 使用单行数组优化空间
  let prev = new Array(n + 1).fill(0)
  let curr = new Array(n + 1).fill(0)
  for (let j = 0; j <= n; j++) prev[j] = j
  for (let i = 1; i <= m; i++) {
    curr[0] = i
    for (let j = 1; j <= n; j++) {
      curr[j] = a[i - 1] === b[j - 1] ? prev[j - 1] : Math.min(prev[j], curr[j - 1], prev[j - 1]) + 1
    }
    const tmp = prev; prev = curr; curr = tmp
  }
  return prev[n]
}

function tryFuzzyMatch(content: string, search: string): { position: number; positions: number[]; actualText?: string; similarity: number } | null {
  const contentLines = content.split('\n')
  const searchLines = search.split('\n')

  // 单行搜索：找最相似的行
  if (searchLines.length === 1 && search.length > 5) {
    let bestIdx = -1
    let bestDist = Infinity
    for (let i = 0; i < contentLines.length; i++) {
      const dist = levenshtein(contentLines[i], search)
      if (dist < bestDist && dist < search.length * 0.4) {
        bestDist = dist
        bestIdx = i
      }
    }
    if (bestIdx >= 0) {
      const actualText = contentLines[bestIdx]
      const pos = contentLines.slice(0, bestIdx).join('\n').length + (bestIdx > 0 ? 1 : 0)
      const similarity = 1 - bestDist / Math.max(actualText.length, search.length)
      return { position: pos, positions: [pos], actualText, similarity }
    }
  }

  // 多行搜索：滑动窗口 + Levenshtein
  if (searchLines.length >= 2) {
    let bestStart = -1
    let bestDist = Infinity
    for (let i = 0; i <= contentLines.length - searchLines.length; i++) {
      const window = contentLines.slice(i, i + searchLines.length).join('\n')
      const dist = levenshtein(window, search)
      if (dist < bestDist && dist < search.length * 0.3) {
        bestDist = dist
        bestStart = i
      }
    }
    if (bestStart >= 0) {
      const actualText = contentLines.slice(bestStart, bestStart + searchLines.length).join('\n')
      const pos = contentLines.slice(0, bestStart).join('\n').length + (bestStart > 0 ? 1 : 0)
      const similarity = 1 - bestDist / Math.max(actualText.length, search.length)
      return { position: pos, positions: [pos], actualText, similarity }
    }
  }

  return null
}

function buildNoMatchError(content: string, search: string, triedTiers: string[]): string {
  const contentLines = content.split('\n')
  const searchLines = search.split('\n')

  // 尝试找出文件中与搜索最接近的行
  let closestLine = ''
  let closestDist = Infinity
  for (const line of contentLines) {
    if (line.trim().length === 0) continue
    const dist = levenshtein(line, searchLines[0] || '')
    if (dist < closestDist) {
      closestDist = dist
      closestLine = line
    }
  }

  let msg = `错误: 未找到匹配文本。已尝试: ${triedTiers.join(' → ') || '精确匹配'}`
  msg += `\n搜索文本: "${search.slice(0, 80)}${search.length > 80 ? '...' : ''}"`
  if (closestLine && closestDist < closestLine.length * 0.5) {
    msg += `\n最相似的行 (距离 ${closestDist}): "${closestLine.slice(0, 80)}"`
    msg += `\n建议: 复制文件中实际的文本作为 old_string`
  }
  // 显示文件上下文帮助 AI 定位
  const previewLines = contentLines.slice(0, 30)
  msg += `\n文件前 30 行预览:\n${previewLines.map((l, i) => `${i + 1}: ${l.slice(0, 100)}`).join('\n')}`
  return msg
}

function applyReplaceAll(content: string, positions: number[], oldStr: string, newStr: string): string {
  // 从后往前替换，保持位置索引不变
  const sorted = [...positions].sort((a, b) => b - a)
  let result = content
  for (const pos of sorted) {
    result = result.substring(0, pos) + newStr + result.substring(pos + oldStr.length)
  }
  return result
}

function formatSize(bytes: number): string {
  if (bytes < 1024) return `${bytes}B`
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)}KB`
  return `${(bytes / (1024 * 1024)).toFixed(1)}MB`
}

// ===== Checkpoint 系统 =====

export interface Checkpoint {
  id: string
  label: string
  timestamp: number
  files: string[]
}

interface CheckpointManifest {
  id: string
  label: string
  timestamp: number
  files: Record<string, string>  // relpath → original content
}

export function saveCheckpoint(root: string, label: string, filePaths: string[]): Checkpoint | null {
  try {
    const ckptDir = join(root, '.orion', 'checkpoints')
    if (!existsSync(ckptDir)) mkdirSync(ckptDir, { recursive: true })

    const id = `ckpt-${Date.now()}`
    const dir = join(ckptDir, id)
    mkdirSync(dir, { recursive: true })

    const files: Record<string, string> = {}
    for (const relPath of filePaths) {
      const fullPath = join(root, relPath)
      if (!existsSync(fullPath)) continue
      const content = readFileSync(fullPath, 'utf-8')
      files[relPath] = content
    }

    const manifest: CheckpointManifest = {
      id,
      label,
      timestamp: Date.now(),
      files,
    }
    writeFileSync(join(dir, 'manifest.json'), JSON.stringify(manifest, null, 2), 'utf-8')

    // 更新索引
    const index = listCheckpoints(root)
    index.push({ id, label, timestamp: manifest.timestamp, files: Object.keys(files) })
    writeFileSync(join(ckptDir, 'index.json'), JSON.stringify(index, null, 2), 'utf-8')

    return { id, label, timestamp: manifest.timestamp, files: Object.keys(files) }
  } catch (e: any) {
    console.error(`[checkpoint] 保存失败: ${e.message}`)
    return null
  }
}

export function listCheckpoints(root: string): Checkpoint[] {
  try {
    const indexPath = join(root, '.orion', 'checkpoints', 'index.json')
    if (!existsSync(indexPath)) return []
    return JSON.parse(readFileSync(indexPath, 'utf-8'))
  } catch {
    return []
  }
}

export function getCheckpointDiff(root: string, id: string): string | null {
  try {
    const manifestPath = join(root, '.orion', 'checkpoints', id, 'manifest.json')
    if (!existsSync(manifestPath)) return null
    const manifest: CheckpointManifest = JSON.parse(readFileSync(manifestPath, 'utf-8'))

    const diffs: string[] = []
    for (const [relPath, oldContent] of Object.entries(manifest.files)) {
      const fullPath = join(root, relPath)
      const currentContent = existsSync(fullPath) ? readFileSync(fullPath, 'utf-8') : '(文件已删除)'
      if (currentContent === oldContent) {
        diffs.push(`## ${relPath} (未变更)`)
        continue
      }
      const oldLines = oldContent.split('\n')
      const newLines = currentContent.split('\n')
      diffs.push(`## ${relPath} (${oldLines.length}行 → ${newLines.length}行)`)
      // 简单 diff: 显示新增和删除的行
      const added = newLines.filter((l: string) => !oldLines.includes(l)).length
      const removed = oldLines.filter((l: string) => !newLines.includes(l)).length
      diffs.push(`  +${added} 行新增, -${removed} 行删除`)
    }

    return diffs.join('\n')
  } catch (e: any) {
    return `diff 错误: ${e.message}`
  }
}

export function restoreCheckpoint(root: string, id: string): { restored: string[]; error?: string } {
  try {
    const manifestPath = join(root, '.orion', 'checkpoints', id, 'manifest.json')
    if (!existsSync(manifestPath)) return { restored: [], error: `checkpoint ${id} 不存在` }
    const manifest: CheckpointManifest = JSON.parse(readFileSync(manifestPath, 'utf-8'))

    const restored: string[] = []
    for (const [relPath, content] of Object.entries(manifest.files)) {
      const fullPath = join(root, relPath)
      const dir = join(fullPath, '..')
      if (!existsSync(dir)) mkdirSync(dir, { recursive: true })
      writeFileSync(fullPath, content, 'utf-8')
      restored.push(relPath)
    }
    return { restored }
  } catch (e: any) {
    return { restored: [], error: e.message }
  }
}
