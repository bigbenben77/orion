// Orion — Agent Loop (Streaming)
// 多轮工具调用循环：LLM 流式输出 → 解析 tool_use → 执行工具 → 观察结果 → 继续

import { writeFileSync } from 'node:fs'
import { join } from 'node:path'
import type { Task } from '../types/task.js'
import type { ExecutionResult } from '../provider/index.js'
import { Shield } from '../shield/index.js'
import {
  ALL_TOOLS,
  toAnthropicTools,
  toOpenAITools,
  toAnthropicToolsForMode,
  toOpenAIToolsForMode,
  executeTool,
  type ToolCall,
  type ToolContext,
} from './tools.js'

const MAX_ITER = 100
const DEFAULT_TIMEOUT_MS = 300000
const MAX_MESSAGES_BEFORE_PRUNE = 14
const MAX_TOOL_CONTENT_LENGTH = 200
const CTX_THRESHOLD = 0.6
const WRAP_AT = 0.45
const MAX_RESTARTS = 5

interface AnthropicMessage {
  role: 'user' | 'assistant'
  content: any
}

interface OpenAIMessage {
  role: 'system' | 'user' | 'assistant' | 'tool'
  content: string | null
  tool_calls?: any[]
  tool_call_id?: string
  name?: string
}

interface APIConfig {
  type: string
  model: string
  apiKey: string
  baseUrl?: string
  timeoutMs?: number
  maxContextTokens?: number
}

interface ContentBlock {
  type: string
  text?: string
  id?: string
  name?: string
  input?: Record<string, any>
}

export interface ContextStats {
  stepIndex: number
  totalInputTokens: number
  totalOutputTokens: number
  cumulativeInputTokens: number
  contextLimit: number
  contextRestarts: number
  contextPct: number
}

interface StreamCallbacks {
  onProgress?: (msg: string) => void
  onStream?: (delta: string) => void
  onContextUpdate?: (stats: ContextStats) => void
}

// ===== Agent 循环入口 =====

export async function runAgentLoop(
  task: Task,
  systemPrompt: string,
  initialPrompt: string,
  config: APIConfig,
  shield: Shield,
  onProgress?: (msg: string) => void,
  onStream?: (delta: string) => void,
  autoMode?: boolean,
  cancelSignal?: AbortSignal,
  onContextUpdate?: (stats: ContextStats) => void,
): Promise<ExecutionResult> {
  const startTime = Date.now()
  const newFiles: string[] = []
  const snapshots: import('./tools.js').FileChange[] = []
  const projectRoot = process.cwd()
  const toolCtx: ToolContext = { projectRoot, snapshots, cache: new Map() }
  const callbacks: StreamCallbacks = { onProgress, onStream, onContextUpdate }

  switch (config.type) {
    case 'anthropic-api':
      return runAnthropicLoop(task, systemPrompt, initialPrompt, config, shield, toolCtx, startTime, newFiles, snapshots, callbacks, autoMode, cancelSignal)
    case 'openai-api':
    case 'openai-compatible':
      return runOpenAILoop(task, systemPrompt, initialPrompt, config, shield, toolCtx, startTime, newFiles, snapshots, callbacks, autoMode, cancelSignal)
    default:
      return { success: false, output: '', error: `不支持的 agent 模式: ${config.type}`, durationMs: 0, changes: [] }
  }
}

// ===== Anthropic Agent 循环（流式） =====

async function runAnthropicLoop(
  task: Task,
  systemPrompt: string,
  initialPrompt: string,
  config: APIConfig,
  shield: Shield,
  toolCtx: ToolContext,
  startTime: number,
  newFiles: string[],
  snapshots: import('./tools.js').FileChange[],
  cb: StreamCallbacks,
  _autoMode?: boolean,
  cancelSignal?: AbortSignal,
): Promise<ExecutionResult> {
  const messages: AnthropicMessage[] = [
    { role: 'user', content: initialPrompt },
  ]
  const tools = toAnthropicToolsForMode(task.mode)
  const limits = shield.getConfig().agentLimits
  const MAX_ITER = limits.maxIterations
  const MAX_RESTARTS = limits.maxContextRestarts
  const CTX_THRESHOLD = limits.contextThreshold
  const WRAP_AT = limits.wrapUpAtContext

  const model = config.model || 'claude-sonnet-4-20250514'
  const timeoutMs = config.timeoutMs || DEFAULT_TIMEOUT_MS
  const contextLimit = config.maxContextTokens || 128_000
  let totalInputTokens = 0
  let totalOutputTokens = 0
  let cumulativeInputTokens = 0
  let contextRestarts = 0
  let wrapUpHintSent = false

  for (let iter = 0; iter < MAX_ITER; iter++) {
    pruneAnthropicMessages(messages)

    // 上下文重启检测：只看当前窗口 token 数，避免重启后立即再次触发
    if (contextLimit > 0) {
      const estimatedTotal = cumulativeInputTokens + totalInputTokens
      // 当前窗口达到阈值 → 重启
      if (totalInputTokens > contextLimit * CTX_THRESHOLD) {
        if (contextRestarts < MAX_RESTARTS) {
          contextRestarts++
          cumulativeInputTokens += totalInputTokens
          totalInputTokens = 0
          wrapUpHintSent = false
          iter = -1 // 重置迭代计数，上下文重启后重新开始计数
          const fileList = [...new Set([...newFiles, ...snapshots.map(s => s.path)])]
          const summary = [
            `[上下文重启 #${contextRestarts}/${MAX_RESTARTS}]`,
            ``,
            `当前进度: 已完成 ${contextRestarts} 次上下文重启，迭代计数已重置。`,
            newFiles.length > 0 ? `已创建文件: ${newFiles.join(', ')}` : '',
            snapshots.length > 0 ? `已修改文件: ${fileList.slice(0, 10).join(', ')}` : '',
            ``,
            `请基于以上已完成的工作继续执行，不要重复操作。`,
            `原始任务: ${task.title}`,
            task.description || '',
          ].filter(Boolean).join('\n')
          messages.length = 0
          messages.push({ role: 'user', content: summary })
          cb.onProgress?.(`🔄 上下文重启 (${contextRestarts}/${MAX_RESTARTS})`)
          continue
        }
        // 已达重启上限，终止任务
        return {
          success: false,
          output: '',
          error: `上下文重启已达上限 (${MAX_RESTARTS}次)，任务终止。已完成 ${iter} 步操作，创建 ${newFiles.length} 个文件，修改 ${snapshots.length} 个文件。请将任务拆分为更小的子任务后重试。`,
          durationMs: Date.now() - startTime,
          tokenUsage: { inputTokens: cumulativeInputTokens + totalInputTokens, outputTokens: totalOutputTokens },
          changes: [...snapshots],
        }
      }
      // 累计用量接近上限 → 提示收尾
      if (estimatedTotal > contextLimit * WRAP_AT && !wrapUpHintSent) {
        wrapUpHintSent = true
        messages.push({ role: 'user', content: '[系统提示] 上下文即将用尽，请尽快完成当前工作并提交结果。如无法在短期内完成，请使用 write_file 保存当前进度。' })
      }
    }

    const body: any = {
      model,
      max_tokens: 8192,
      system: systemPrompt,
      messages,
      tools,
      stream: true,
    }

    try {
      const resp = await fetch('https://api.anthropic.com/v1/messages', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-api-key': config.apiKey,
          'anthropic-version': '2023-06-01',
        },
        body: JSON.stringify(body),
        signal: cancelSignal
          ? AbortSignal.any([AbortSignal.timeout(timeoutMs), cancelSignal])
          : AbortSignal.timeout(timeoutMs),
      })

      if (!resp.ok) {
        const errText = await resp.text()
        return { success: false, output: '', error: `Anthropic ${resp.status}: ${errText}`, durationMs: Date.now() - startTime, changes: [...snapshots] }
      }

      if (!resp.body) {
        return { success: false, output: '', error: 'Anthropic 流式响应无 body', durationMs: Date.now() - startTime, changes: [...snapshots] }
      }

      // 解析 SSE 流
      const contentBlocks: ContentBlock[] = []
      const toolBlocks: ContentBlock[] = []
      let currentBlock: ContentBlock | null = null
      let textOutput = ''
      let usageTokens: any = null

      const reader = resp.body.getReader()
      const decoder = new TextDecoder()
      let buffer = ''

      while (true) {
        const { done, value } = await reader.read()
        if (done) break

        buffer += decoder.decode(value, { stream: true })
        const lines = buffer.split('\n')
        buffer = lines.pop() || ''

        for (const line of lines) {
          const trimmed = line.trim()
          if (!trimmed) continue

          // SSE event line
          if (trimmed.startsWith('event:')) continue

          if (trimmed.startsWith('data:')) {
            const jsonStr = trimmed.slice(5).trim()
            if (!jsonStr) continue

            try {
              const evt = JSON.parse(jsonStr)

              switch (evt.type) {
                case 'message_start':
                  if (evt.message?.usage?.input_tokens) {
                    totalInputTokens += evt.message.usage.input_tokens
                  }
                  break

                case 'content_block_start': {
                  const block = evt.content_block
                  currentBlock = {
                    type: block.type,
                    id: block.id,
                    name: block.name,
                    input: block.type === 'tool_use' ? {} : undefined,
                  }
                  if (block.type === 'text') {
                    currentBlock.text = block.text || ''
                  }
                  contentBlocks.push(currentBlock)
                  if (block.type === 'tool_use') {
                    toolBlocks.push(currentBlock)
                  }
                  break
                }

                case 'content_block_delta': {
                  const delta = evt.delta
                  if (delta.type === 'text_delta' && currentBlock) {
                    currentBlock.text = (currentBlock.text || '') + delta.text
                    textOutput += delta.text
                    cb.onStream?.(delta.text)
                  } else if (delta.type === 'input_json_delta' && currentBlock) {
                    // 累积 tool_use 的 JSON 参数
                    if (!currentBlock.input) currentBlock.input = {}
                    // input_json_delta 给出部分 JSON，需要累积
                    ;(currentBlock as any)._inputJson = ((currentBlock as any)._inputJson || '') + delta.partial_json
                  }
                  break
                }

                case 'content_block_stop':
                  // 如果这是 tool_use block，尝试解析完整的 JSON
                  if (currentBlock && (currentBlock as any)._inputJson) {
                    try {
                      currentBlock.input = JSON.parse((currentBlock as any)._inputJson)
                      delete (currentBlock as any)._inputJson
                    } catch {
                      // 如果 JSON 不完整，保留原始字符串
                      currentBlock.input = {}
                    }
                  }
                  currentBlock = null
                  break

                case 'message_delta':
                  if (evt.usage?.output_tokens) {
                    totalOutputTokens += evt.usage.output_tokens
                  }
                  break

                case 'message_stop':
                  break
              }
            } catch {
              // 忽略解析错误的行
            }
          }
        }
      }

      // 确保 tool_use blocks 已正确记录
      const actualToolBlocks = contentBlocks.filter((c: any) => c.type === 'tool_use')

      // 报告上下文使用情况
      cb.onContextUpdate?.({
        stepIndex: iter,
        totalInputTokens,
        totalOutputTokens,
        cumulativeInputTokens,
        contextLimit,
        contextRestarts,
        contextPct: contextLimit > 0 ? Math.round((cumulativeInputTokens + totalInputTokens) / contextLimit * 100) / 100 : 0,
      })

      // 构建 assistant 消息
      const assistantContent = contentBlocks.map(c => {
        if (c.type === 'text') return { type: 'text', text: c.text || '' }
        if (c.type === 'tool_use') {
          return {
            type: 'tool_use',
            id: c.id,
            name: c.name,
            input: c.input || {},
          }
        }
        return c
      })
      messages.push({ role: 'assistant', content: assistantContent })

      // 如果没有 tool_use，任务完成
      if (actualToolBlocks.length === 0) {
        const durationMs = Date.now() - startTime
        return { success: true, output: textOutput, durationMs, newFiles, tokenUsage: { inputTokens: totalInputTokens, outputTokens: totalOutputTokens }, changes: [...snapshots] }
      }

      // 执行工具调用
      const toolResults: any[] = []
      for (const tb of actualToolBlocks) {
        const call: ToolCall = { id: tb.id || '', name: tb.name || '', input: tb.input || {} }
        cb.onProgress?.(`🔧 ${call.name}(${Object.values(call.input).join(', ').slice(0, 60)})`)

        // 权限检查
        const perm = shield.checkPermission(call.name)
        if (!perm.allowed) {
          toolResults.push({
            type: 'tool_result',
            tool_use_id: call.id,
            content: `权限拒绝: ${perm.reason}`,
          })
          continue
        }

        shield.recordAction({
          tool: call.name,
          params: JSON.stringify(call.input).slice(0, 200),
          result: 'success',
          timestamp: Date.now(),
          file: call.input.path,
        })

        const result = executeTool(call, toolCtx)
        if (result.error) {
          shield.recordAction({
            tool: call.name,
            result: 'failure',
            timestamp: Date.now(),
            file: call.input.path,
          })
        }

        if (call.name === 'write_file' && !result.error) {
          newFiles.push(call.input.path)
        }

        toolResults.push({
          type: 'tool_result',
          tool_use_id: call.id,
          content: result.error ? `错误: ${result.error}` : result.content,
        })
      }

      messages.push({ role: 'user', content: toolResults })
    } catch (e: any) {
      if (e.name === 'AbortError') {
        return { success: false, output: '', error: '任务已被取消', durationMs: Date.now() - startTime, changes: [...snapshots] }
      }
      return { success: false, output: '', error: `Agent loop 错误 (iter ${iter}): ${e.message}`, durationMs: Date.now() - startTime, changes: [...snapshots] }
    }
  }

  return { success: false, output: '', error: `达到最大迭代次数 (${MAX_ITER})`, durationMs: Date.now() - startTime, tokenUsage: { inputTokens: totalInputTokens, outputTokens: totalOutputTokens }, changes: [...snapshots] }
}

// ===== OpenAI Agent 循环（流式） =====

async function runOpenAILoop(
  task: Task,
  systemPrompt: string,
  initialPrompt: string,
  config: APIConfig,
  shield: Shield,
  toolCtx: ToolContext,
  startTime: number,
  newFiles: string[],
  snapshots: import('./tools.js').FileChange[],
  cb: StreamCallbacks,
  _autoMode?: boolean,
  cancelSignal?: AbortSignal,
): Promise<ExecutionResult> {
  const limits = shield.getConfig().agentLimits
  const MAX_ITER = limits.maxIterations
  const MAX_RESTARTS = limits.maxContextRestarts
  const CTX_THRESHOLD = limits.contextThreshold
  const WRAP_AT = limits.wrapUpAtContext

  const messages: OpenAIMessage[] = [
    { role: 'system', content: systemPrompt },
    { role: 'user', content: initialPrompt },
  ]
  const tools = toOpenAIToolsForMode(task.mode)
  const model = config.model || 'gpt-4o'
  const url = (config.baseUrl || 'https://api.openai.com/v1').replace(/\/$/, '') + '/chat/completions'
  const timeoutMs = config.timeoutMs || DEFAULT_TIMEOUT_MS
  const contextLimit = config.maxContextTokens || 128_000
  let totalInputTokens = 0
  let totalOutputTokens = 0
  let cumulativeInputTokens = 0
  let contextRestarts = 0
  let wrapUpHintSent = false

  for (let iter = 0; iter < MAX_ITER; iter++) {
    pruneOpenAIMessages(messages)
    validateOpenAIMessages(messages)

    // 上下文重启检测：只看当前窗口 token 数，避免重启后立即再次触发
    if (contextLimit > 0) {
      const estimatedTotal = cumulativeInputTokens + totalInputTokens
      // 当前窗口达到阈值 → 重启
      if (totalInputTokens > contextLimit * CTX_THRESHOLD) {
        if (contextRestarts < MAX_RESTARTS) {
          contextRestarts++
          cumulativeInputTokens += totalInputTokens
          totalInputTokens = 0
          wrapUpHintSent = false
          iter = -1 // 重置迭代计数，上下文重启后重新开始计数
          const fileList = [...new Set([...newFiles, ...snapshots.map(s => s.path)])]
          const summary = [
            `[上下文重启 #${contextRestarts}/${MAX_RESTARTS}]`,
            ``,
            `当前进度: 已完成 ${contextRestarts} 次上下文重启，迭代计数已重置。`,
            newFiles.length > 0 ? `已创建文件: ${newFiles.join(', ')}` : '',
            snapshots.length > 0 ? `已修改文件: ${fileList.slice(0, 10).join(', ')}` : '',
            ``,
            `请基于以上已完成的工作继续执行，不要重复操作。`,
            `原始任务: ${task.title}`,
            task.description || '',
          ].filter(Boolean).join('\n')
          messages.length = 0
          messages.push({ role: 'system', content: systemPrompt })
          messages.push({ role: 'user', content: summary })
          cb.onProgress?.(`🔄 上下文重启 (${contextRestarts}/${MAX_RESTARTS})`)
          continue
        }
        // 已达重启上限，终止任务
        return {
          success: false,
          output: '',
          error: `上下文重启已达上限 (${MAX_RESTARTS}次)，任务终止。已完成 ${iter} 步操作，创建 ${newFiles.length} 个文件，修改 ${snapshots.length} 个文件。请将任务拆分为更小的子任务后重试。`,
          durationMs: Date.now() - startTime,
          tokenUsage: { inputTokens: cumulativeInputTokens + totalInputTokens, outputTokens: totalOutputTokens },
          changes: [...snapshots],
        }
      } else if (estimatedTotal > contextLimit * WRAP_AT && !wrapUpHintSent) {
        wrapUpHintSent = true
        messages.push({ role: 'user', content: '[系统提示] 上下文即将用尽，请尽快完成当前工作并提交结果。如无法在短期内完成，请使用 write_file 保存当前进度。' })
      }
    }

    const body: any = {
      model,
      messages,
      tools,
      max_tokens: 8192,
      stream: true,
      stream_options: { include_usage: true },
    }

    try {
      const resp = await fetch(url, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${config.apiKey}`,
        },
        body: JSON.stringify(body),
        signal: cancelSignal
          ? AbortSignal.any([AbortSignal.timeout(timeoutMs), cancelSignal])
          : AbortSignal.timeout(timeoutMs),
      })

      if (!resp.ok) {
        const errText = await resp.text()
        return { success: false, output: '', error: `OpenAI ${resp.status}: ${errText}`, durationMs: Date.now() - startTime, changes: [...snapshots] }
      }

      if (!resp.body) {
        return { success: false, output: '', error: 'OpenAI 流式响应无 body', durationMs: Date.now() - startTime, changes: [...snapshots] }
      }

      // 解析 SSE 流
      const reader = resp.body.getReader()
      const decoder = new TextDecoder()
      let buffer = ''

      // 累积完整消息
      let contentText = ''
      const toolCallsAcc: Map<number, { id: string; name: string; args: string }> = new Map()

      while (true) {
        const { done, value } = await reader.read()
        if (done) break

        buffer += decoder.decode(value, { stream: true })
        const lines = buffer.split('\n')
        buffer = lines.pop() || ''

        for (const line of lines) {
          const trimmed = line.trim()
          if (!trimmed || !trimmed.startsWith('data:')) continue

          const data = trimmed.slice(5).trim()
          if (data === '[DONE]') break

          try {
            const chunk = JSON.parse(data)
            const delta = chunk.choices?.[0]?.delta

            // 捕获 token 用量（stream_options.include_usage 开启后出现在最后 chunk）
            if (chunk.usage) {
              if (chunk.usage.prompt_tokens) totalInputTokens += chunk.usage.prompt_tokens
              if (chunk.usage.completion_tokens) totalOutputTokens += chunk.usage.completion_tokens
            }

            if (!delta) continue

            // 文本增量
            if (delta.content) {
              contentText += delta.content
              cb.onStream?.(delta.content)
            }

            // 工具调用增量
            if (delta.tool_calls) {
              for (const tc of delta.tool_calls) {
                const idx = tc.index ?? 0
                if (!toolCallsAcc.has(idx)) {
                  toolCallsAcc.set(idx, { id: tc.id || '', name: '', args: '' })
                }
                const acc = toolCallsAcc.get(idx)!
                if (tc.id) acc.id = tc.id
                if (tc.function?.name) acc.name = tc.function.name  // 覆盖，不拼接（名字不会分片）
                if (tc.function?.arguments) acc.args += tc.function.arguments
              }
            }
          } catch {
            // 忽略解析错误
          }
        }
      }

      // 报告上下文使用情况
      cb.onContextUpdate?.({
        stepIndex: iter,
        totalInputTokens,
        totalOutputTokens,
        cumulativeInputTokens,
        contextLimit,
        contextRestarts,
        contextPct: contextLimit > 0 ? Math.round((cumulativeInputTokens + totalInputTokens) / contextLimit * 100) / 100 : 0,
      })

      // 构建 assistant 消息 (OpenAI)
      const hasToolCalls = toolCallsAcc.size > 0
      const assistantMsg: OpenAIMessage = {
        role: 'assistant',
        content: contentText || null,
      }

      if (hasToolCalls) {
        assistantMsg.tool_calls = Array.from(toolCallsAcc.entries()).map(([idx, tc]) => ({
          index: idx,
          id: tc.id,
          type: 'function',
          function: {
            name: tc.name,
            arguments: tc.args,
          },
        }))
      }

      messages.push(assistantMsg)

      // 如果没有 tool_calls，任务完成
      if (!hasToolCalls) {
        const durationMs = Date.now() - startTime
        return { success: true, output: contentText, durationMs, newFiles, tokenUsage: { inputTokens: totalInputTokens, outputTokens: totalOutputTokens }, changes: [...snapshots] }
      }

      // 执行工具调用
      for (const [_idx, tc] of toolCallsAcc) {
        let input: Record<string, any> = {}
        try { input = JSON.parse(tc.args || '{}') } catch { /* 无效 JSON */ }

        const call: ToolCall = { id: tc.id, name: tc.name, input }
        cb.onProgress?.(`🔧 ${call.name}(${JSON.stringify(call.input).slice(0, 80)})`)

        // 权限检查
        const perm = shield.checkPermission(call.name)
        if (!perm.allowed) {
          messages.push({
            role: 'tool',
            tool_call_id: tc.id,
            content: `权限拒绝: ${perm.reason}`,
          })
          continue
        }

        shield.recordAction({
          tool: call.name,
          params: JSON.stringify(call.input).slice(0, 200),
          result: 'success',
          timestamp: Date.now(),
          file: call.input.path,
        })

        const result = executeTool(call, toolCtx)
        if (result.error) {
          shield.recordAction({
            tool: call.name,
            result: 'failure',
            timestamp: Date.now(),
            file: call.input.path,
          })
        }

        if (call.name === 'write_file' && !result.error) {
          newFiles.push(call.input.path)
        }

        messages.push({
          role: 'tool',
          tool_call_id: tc.id,
          content: result.error ? `错误: ${result.error}` : result.content,
        })
      }
    } catch (e: any) {
      if (e.name === 'AbortError') {
        return { success: false, output: '', error: '任务已被取消', durationMs: Date.now() - startTime, changes: [...snapshots] }
      }
      return { success: false, output: '', error: `Agent loop 错误 (iter ${iter}): ${e.message}`, durationMs: Date.now() - startTime, changes: [...snapshots] }
    }
  }

  return { success: false, output: '', error: `达到最大迭代次数 (${MAX_ITER})`, durationMs: Date.now() - startTime, tokenUsage: { inputTokens: totalInputTokens, outputTokens: totalOutputTokens }, changes: [...snapshots] }
}

// ===== 消息裁剪 =====

function pruneAnthropicMessages(messages: AnthropicMessage[]): void {
  if (messages.length <= MAX_MESSAGES_BEFORE_PRUNE) return
  const keepTail = 8
  const keepHead = 1 // 保留第一条消息（任务描述）
  // 截断中间旧消息的 tool_result 内容，并删除过旧的消息
  for (let i = keepHead; i < messages.length - keepTail; i++) {
    const msg = messages[i]
    if (msg.role === 'user' && Array.isArray(msg.content)) {
      for (const block of msg.content) {
        if (block.type === 'tool_result' && typeof block.content === 'string' && block.content.length > MAX_TOOL_CONTENT_LENGTH) {
          block.content = block.content.slice(0, MAX_TOOL_CONTENT_LENGTH) + '\n... [已截断]'
        }
      }
    }
  }
  // 删除中间的旧消息对，保留头尾
  const removeCount = messages.length - keepHead - keepTail
  if (removeCount > 0) {
    messages.splice(keepHead, removeCount)
  }
}

function pruneOpenAIMessages(messages: OpenAIMessage[]): void {
  if (messages.length <= MAX_MESSAGES_BEFORE_PRUNE) return
  const keepTail = 8
  let keepHead = 2 // 保留 system + 第一条 user 消息
  // 调整 keepHead 到安全边界：tool 消息必须紧跟在 assistant(tool_calls) 之后
  // 不能从 tool 消息中间切断，否则 OpenAI API 返回 400
  while (keepHead < messages.length - keepTail && messages[keepHead]?.role === 'tool') {
    keepHead++
  }
  // 截断中间旧消息的 tool 内容
  for (let i = keepHead; i < messages.length - keepTail; i++) {
    const msg = messages[i]
    if (msg.role === 'tool' && msg.content && msg.content.length > MAX_TOOL_CONTENT_LENGTH) {
      msg.content = msg.content.slice(0, MAX_TOOL_CONTENT_LENGTH) + '\n... [已截断]'
    }
  }
  // 删除中间的消息对
  let removeCount = messages.length - keepHead - keepTail
  if (removeCount > 0) {
    // 确保保留区的第一条不是孤儿 tool 消息（会违反 OpenAI tool_calls 配对规则）
    let orphanIdx = keepHead + removeCount
    while (orphanIdx < messages.length && messages[orphanIdx]?.role === 'tool') {
      removeCount++
      orphanIdx++
    }
    messages.splice(keepHead, removeCount)
  }
}

/** 验证并修复 OpenAI 消息数组：确保 tool 消息之前总是有 assistant(tool_calls) */
function validateOpenAIMessages(messages: OpenAIMessage[]): boolean {
  let fixed = false
  for (let i = 1; i < messages.length; i++) {
    if (messages[i].role !== 'tool') continue
    const prev = messages[i - 1]
    // tool 消息必须紧跟 assistant(tool_calls) 或另一个 tool
    const prevOk = (prev.role === 'assistant' && prev.tool_calls && prev.tool_calls.length > 0)
      || prev.role === 'tool'
    if (!prevOk) {
      console.error(`[orion] 检测到孤儿 tool 消息 (索引 ${i})，已自动移除`)
      // 移除从 i 开始的所有连续 tool 消息
      let end = i
      while (end < messages.length && messages[end].role === 'tool') end++
      messages.splice(i, end - i)
      fixed = true
      i-- // 重新检查当前位置
    }
  }
  return fixed
}
