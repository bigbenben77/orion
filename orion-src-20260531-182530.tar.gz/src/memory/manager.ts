// Orion — 记忆管理器
// 让 AI 记住会话内容 + 自动提炼重点 + 按需检索省 token

import { readFileSync, writeFileSync, existsSync, mkdirSync } from 'node:fs'
import { join, dirname } from 'node:path'
import { randomUUID } from 'node:crypto'
import type { Memory, MemoryType, MemoryStore, MemorySearchResult } from '../types/memory.js'

const DEFAULT_STORE: MemoryStore = {
  version: '1.0.0',
  memories: [],
  metadata: { created: Date.now(), updated: Date.now(), totalMemories: 0, totalSessions: 0 },
}

const MAX_MEMORIES = 500        // 最多存 500 条
const MAX_CONTEXT_TOKENS = 2000 // 给 AI 上下文时最多 2000 token（估算）
const AVG_TOKEN_PER_CHAR = 0.4  // 中英文混合估算

export class MemoryManager {
  private store: MemoryStore
  private storePath: string
  private recentSessionBuffer: string[] = []  // 当前会话临时缓冲区

  constructor(projectRoot?: string) {
    const root = projectRoot || process.cwd()
    const dir = join(root, '.orion', 'memory')
    if (!existsSync(dir)) mkdirSync(dir, { recursive: true })
    this.storePath = join(dir, 'memories.json')
    this.store = this.loadStore()
  }

  private loadStore(): MemoryStore {
    try {
      if (existsSync(this.storePath)) {
        return JSON.parse(readFileSync(this.storePath, 'utf-8'))
      }
    } catch { /* fall through */ }
    return { ...DEFAULT_STORE, metadata: { ...DEFAULT_STORE.metadata, created: Date.now() } }
  }

  private save(): void {
    this.store.metadata.updated = Date.now()
    this.store.metadata.totalMemories = this.store.memories.length
    writeFileSync(this.storePath, JSON.stringify(this.store, null, 2), 'utf-8')
  }

  // ===== 添加记忆 =====

  add(type: MemoryType, content: string, params?: {
    summary?: string
    tags?: string[]
    importance?: number
    sessionId?: string
    source?: string
  }): Memory {
    const memory: Memory = {
      id: `mem-${randomUUID().slice(0, 8)}`,
      type,
      content: content.slice(0, 5000),  // 单条上限 5000 字
      summary: params?.summary,
      tags: params?.tags || [],
      importance: params?.importance ?? 5,
      timestamp: Date.now(),
      accessedCount: 0,
      lastAccessed: Date.now(),
      sessionId: params?.sessionId,
      source: params?.source,
    }

    // 如果超过上限，删除最旧的低重要性记忆
    if (this.store.memories.length >= MAX_MEMORIES) {
      this.store.memories.sort((a, b) => a.importance - b.importance || a.timestamp - b.timestamp)
      this.store.memories = this.store.memories.slice(-MAX_MEMORIES + 50)
    }

    this.store.memories.push(memory)
    this.recentSessionBuffer.push(`${type}: ${params?.summary || content.slice(0, 100)}`)
    this.save()
    return memory
  }

  // ===== 会话记录 =====

  /** 记录一条会话消息 */
  logSession(sessionId: string, role: 'user' | 'assistant' | 'system', message: string): void {
    this.add('session', `[${role}] ${message.slice(0, 500)}`, {
      tags: ['session', `session:${sessionId}`],
      importance: 3,
      sessionId,
      summary: `[${role}] ${message.slice(0, 80)}`,
    })
  }

  /** 记录一次决策 */
  logDecision(decision: string, reason: string, params?: { tags?: string[]; importance?: number; source?: string }): void {
    this.add('decision', `${decision}\n原因: ${reason}`, {
      tags: [...(params?.tags || []), 'decision'],
      importance: params?.importance ?? 7,
      summary: decision.slice(0, 100),
      source: params?.source,
    })
  }

  /** 记录用户偏好 */
  logPreference(preference: string, detail?: string): void {
    this.add('preference', `${preference}${detail ? '\n' + detail : ''}`, {
      tags: ['preference', 'user-preference'],
      importance: 8,
      summary: preference,
    })
  }

  /** 记录值得记住的错误 */
  logError(error: string, solution: string, params?: { tags?: string[] }): void {
    this.add('error', `错误: ${error}\n解决方案: ${solution}`, {
      tags: [...(params?.tags || []), 'error', 'lesson'],
      importance: 6,
      summary: `⚠ ${error.slice(0, 60)} → ${solution.slice(0, 60)}`,
    })
  }

  /** 开始新会话 */
  startSession(sessionId: string): void {
    this.store.metadata.totalSessions++
    this.recentSessionBuffer = []
    this.add('summary', `会话 ${sessionId} 开始`, {
      tags: ['session-start', `session:${sessionId}`],
      importance: 2,
      sessionId,
    })
  }

  /** 结束会话并生成摘要 */
  endSession(sessionId: string, summary?: string): void {
    const defaultSummary = this.recentSessionBuffer.length > 0
      ? `会话摘要: ${this.recentSessionBuffer.slice(-5).join('; ')}`
      : `会话 ${sessionId} 结束`
    this.add('summary', summary || defaultSummary, {
      tags: ['session-end', `session:${sessionId}`],
      importance: 4,
      sessionId,
    })
    this.recentSessionBuffer = []
  }

  // ===== 检索 =====

  /** 搜索相关记忆（按相关度排序） */
  search(query: string, maxResults = 5): MemorySearchResult[] {
    const queryLower = query.toLowerCase()
    const queryWords = queryLower.split(/\s+/).filter(w => w.length > 1)
    const results: MemorySearchResult[] = []

    for (const mem of this.store.memories) {
      const matchedTags: string[] = []
      let score = 0

      // 标签匹配（权重高）
      for (const tag of mem.tags) {
        if (queryLower.includes(tag.toLowerCase())) {
          score += 0.3
          matchedTags.push(tag)
        }
      }

      // 内容关键词匹配
      const contentLower = (mem.content + ' ' + (mem.summary || '')).toLowerCase()
      for (const word of queryWords) {
        if (contentLower.includes(word)) {
          score += 0.15
        }
      }

      // 重要度加成（重要记忆更容易被召回）
      score += (mem.importance / 10) * 0.2

      // 时间衰减（越新的记忆权重越高）
      const daysOld = (Date.now() - mem.timestamp) / (1000 * 60 * 60 * 24)
      score *= Math.max(0.3, 1 - daysOld * 0.05)

      if (score > 0.3) {
        results.push({ memory: mem, relevance: Math.min(score, 1), matchedTags })
      }
    }

    return results.sort((a, b) => b.relevance - a.relevance).slice(0, maxResults)
  }

  /** 检索最近 N 条记忆 */
  getRecent(count = 10): Memory[] {
    return [...this.store.memories]
      .sort((a, b) => b.timestamp - a.timestamp)
      .slice(0, count)
  }

  /** 按类型检索 */
  getByType(type: MemoryType, limit = 20): Memory[] {
    return this.store.memories
      .filter(m => m.type === type)
      .sort((a, b) => b.timestamp - a.timestamp)
      .slice(0, limit)
  }

  /** 检索最重要的记忆 */
  getImportant(threshold = 7): Memory[] {
    return this.store.memories
      .filter(m => m.importance >= threshold)
      .sort((a, b) => b.importance - a.importance)
  }

  // ===== 上下文构建（省 token 核心！） =====

  /**
   * 为 AI 构建记忆上下文
   * 根据 token 预算，只返回最相关的记忆
   * 优先级: 决策 > 偏好 > 错误 > 模式 > 事实 > 摘要 > 会话
   */
  buildContext(query: string, budget = MAX_CONTEXT_TOKENS): string {
    const results = this.search(query, 20)

    // 按重要性加权排序
    const prioritized = results.sort((a, b) => {
      const order: Record<string, number> = { decision: 7, preference: 6, error: 5, pattern: 4, fact: 3, summary: 2, session: 1 }
      const aScore = (order[a.memory.type] || 0) + a.memory.importance
      const bScore = (order[b.memory.type] || 0) + b.memory.importance
      return bScore - aScore
    })

    const lines: string[] = ['--- [记忆上下文] ---']
    let tokenUsed = 0

    for (const { memory, relevance } of prioritized) {
      if (tokenUsed >= budget) break

      // 优先用摘要（省 token）
      const text = memory.summary || memory.content
      const tokenCost = Math.ceil(text.length * AVG_TOKEN_PER_CHAR)

      if (tokenUsed + tokenCost > budget) {
        // 预算不够就截断
        const remaining = Math.floor((budget - tokenUsed) / AVG_TOKEN_PER_CHAR)
        if (remaining > 20) {
          lines.push(`[${memory.type}] ${text.slice(0, remaining)}...`)
        }
        break
      }

      const date = new Date(memory.timestamp).toLocaleDateString('zh-CN')
      const tags = memory.tags.length > 0 ? ` [${memory.tags.slice(0, 3).join(', ')}]` : ''
      lines.push(`[${memory.type}|${relevance.toFixed(1)}|${date}]${tags} ${text}`)
      tokenUsed += tokenCost
    }

    if (lines.length === 1) return ''
    lines.push('---')
    return lines.join('\n')
  }

  /** 获取简短的状态摘要（用于顶栏/状态命令） */
  getStats(): { total: number; byType: Record<string, number>; important: number } {
    const byType: Record<string, number> = {}
    for (const m of this.store.memories) {
      byType[m.type] = (byType[m.type] || 0) + 1
    }
    return {
      total: this.store.memories.length,
      byType,
      important: this.store.memories.filter(m => m.importance >= 7).length,
    }
  }

  /** 清理过期低价值记忆 */
  cleanup(): number {
    const before = this.store.memories.length
    const cutoff = Date.now() - 30 * 24 * 60 * 60 * 1000 // 30 天
    this.store.memories = this.store.memories.filter(m =>
      m.importance >= 4 || m.timestamp > cutoff
    )
    const removed = before - this.store.memories.length
    if (removed > 0) this.save()
    return removed
  }
}
