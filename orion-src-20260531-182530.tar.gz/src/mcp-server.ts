// Orion MCP Server
// 让 Claude Code / Cursor / Roo Code 通过 MCP 协议调用 Orion
//
// MCP 协议: JSON-RPC 2.0 over stdio
// 参考: https://modelcontextprotocol.io

import { readFileSync, writeFileSync, existsSync, mkdirSync } from 'node:fs'
import { join, dirname } from 'node:path'

import { TaskOrchestrator } from './orchestrator/index.js'
import { Shield } from './shield/index.js'
import { SkillsEngine } from './skills/index.js'
import type { TaskStatus } from './types/task.js'

// ===== MCP 协议实现 =====

interface JsonRpcRequest {
  jsonrpc: '2.0'
  id: number | string
  method: string
  params?: any
}

interface JsonRpcResponse {
  jsonrpc: '2.0'
  id: number | string
  result?: any
  error?: { code: number; message: string; data?: any }
}

interface McpTool {
  name: string
  description: string
  inputSchema: {
    type: 'object'
    properties: Record<string, any>
    required?: string[]
  }
}

class StdioTransport {
  private buffer = ''

  onMessage(handler: (msg: JsonRpcRequest) => void): void {
    process.stdin.setEncoding('utf-8')
    process.stdin.on('data', (chunk: string) => {
      this.buffer += chunk
      const lines = this.buffer.split('\n')
      this.buffer = lines.pop() || ''
      for (const line of lines) {
        const trimmed = line.trim()
        if (!trimmed) continue
        try {
          const msg = JSON.parse(trimmed) as JsonRpcRequest
          handler(msg)
        } catch (e) {
          this.sendError(null, -32700, `Parse error: ${e}`)
        }
      }
    })
  }

  send(msg: JsonRpcResponse): void {
    const raw = JSON.stringify(msg) + '\n'
    process.stdout.write(raw)
  }

  sendResult(id: number | string | null, result: any): void {
    if (id === null) return // notification
    this.send({ jsonrpc: '2.0', id, result })
  }

  sendError(id: number | string | null, code: number, message: string, data?: any): void {
    if (id === null) return
    this.send({ jsonrpc: '2.0', id, error: { code, message, data } })
  }
}

// ===== Orion MCP Server =====

export class OrionMCPServer {
  private transport: StdioTransport
  private orion: TaskOrchestrator
  private shield: Shield
  private skills: SkillsEngine
  private initialized = false

  constructor() {
    this.transport = new StdioTransport()
    this.orion = new TaskOrchestrator()
    this.shield = new Shield()
    this.skills = new SkillsEngine()
    this.skills.loadAll()
  }

  start(): void {
    this.transport.onMessage((msg) => this.handleMessage(msg))
    // Signal readiness
    console.error('[orion-mcp] MCP Server 已启动，等待工具调用...')
  }

  private handleMessage(msg: JsonRpcRequest): void {
    try {
      switch (msg.method) {
        case 'initialize':
          this.handleInitialize(msg)
          break
        case 'notifications/initialized':
          this.initialized = true
          break
        case 'tools/list':
          this.handleListTools(msg)
          break
        case 'tools/call':
          this.handleCallTool(msg)
          break
        default:
          this.transport.sendError(msg.id, -32601, `未知方法: ${msg.method}`)
      }
    } catch (e: any) {
      this.transport.sendError(msg.id, -32603, `内部错误: ${e.message}`)
    }
  }

  private handleInitialize(msg: JsonRpcRequest): void {
    this.initialized = true
    this.transport.sendResult(msg.id, {
      protocolVersion: '2025-03-26',
      capabilities: {
        tools: {},
      },
      serverInfo: {
        name: 'orion',
        version: '0.1.0',
      },
    })
  }

  private handleListTools(msg: JsonRpcRequest): void {
    const tools: McpTool[] = [
      // ===== 任务管理 =====
      {
        name: 'task_create',
        description: '创建一个新任务',
        inputSchema: {
          type: 'object',
          properties: {
            title: { type: 'string', description: '任务标题' },
            description: { type: 'string', description: '任务详细描述' },
            dependencies: { type: 'array', items: { type: 'string' }, description: '依赖任务 ID 列表' },
            priority: { type: 'string', enum: ['low', 'medium', 'high', 'critical'], description: '优先级' },
            files: { type: 'array', items: { type: 'string' }, description: '关联文件路径' },
            tags: { type: 'array', items: { type: 'string' }, description: '标签' },
            mode: { type: 'string', enum: ['code', 'architect', 'ask', 'debug'], description: '执行模式 (code/architect/ask/debug)' },
            maxRetries: { type: 'number', description: '最大重试次数' },
          },
          required: ['title'],
        },
      },
      {
        name: 'task_list',
        description: '列出任务，可按状态/优先级筛选',
        inputSchema: {
          type: 'object',
          properties: {
            status: { type: 'string', description: '按状态筛选' },
            priority: { type: 'string', description: '按优先级筛选' },
          },
        },
      },
      {
        name: 'task_update',
        description: '更新任务状态或内容',
        inputSchema: {
          type: 'object',
          properties: {
            id: { type: 'string', description: '任务 ID' },
            status: { type: 'string', description: '新状态' },
            blockedReason: { type: 'string', description: '阻塞原因' },
          },
          required: ['id'],
        },
      },
      {
        name: 'task_get',
        description: '查看单个任务详情',
        inputSchema: {
          type: 'object',
          properties: {
            id: { type: 'string', description: '任务 ID' },
          },
          required: ['id'],
        },
      },
      {
        name: 'task_ready',
        description: '获取当前可执行的任务列表（依赖已满足）',
        inputSchema: { type: 'object', properties: {} },
      },
      {
        name: 'task_blocked',
        description: '获取被阻塞的任务及其原因',
        inputSchema: { type: 'object', properties: {} },
      },
      {
        name: 'task_stats',
        description: '获取任务统计信息',
        inputSchema: { type: 'object', properties: {} },
      },
      {
        name: 'task_reset',
        description: '重置所有进行中任务为 pending（中断恢复用）',
        inputSchema: { type: 'object', properties: {} },
      },
      {
        name: 'task_delete',
        description: '删除任务',
        inputSchema: {
          type: 'object',
          properties: { id: { type: 'string' } },
          required: ['id'],
        },
      },

      // ===== 技能 =====
      {
        name: 'skill_list',
        description: '列出所有可用技能',
        inputSchema: { type: 'object', properties: {} },
      },
      {
        name: 'skill_match',
        description: '为任务标题匹配合适的技能',
        inputSchema: {
          type: 'object',
          properties: {
            title: { type: 'string', description: '任务标题' },
            description: { type: 'string', description: '任务描述' },
          },
          required: ['title'],
        },
      },

      // ===== 保护层 =====
      {
        name: 'shield_status',
        description: '获取保护层状态和配置',
        inputSchema: { type: 'object', properties: {} },
      },
      {
        name: 'shield_check_action',
        description: '记录一个动作并检测是否有循环',
        inputSchema: {
          type: 'object',
          properties: {
            tool: { type: 'string', description: '工具名称' },
            result: { type: 'string', enum: ['success', 'failure', 'timeout'], description: '执行结果' },
            file: { type: 'string', description: '涉及的文件' },
          },
          required: ['tool', 'result'],
        },
      },

      // ===== 项目上下文 =====
      {
        name: 'context_slice',
        description: '获取任务相关的文件列表（上下文切片）',
        inputSchema: {
          type: 'object',
          properties: {
            taskId: { type: 'string', description: '任务 ID' },
            maxFiles: { type: 'number', description: '最大文件数' },
          },
          required: ['taskId'],
        },
      },
    ]

    this.transport.sendResult(msg.id, { tools })
  }

  private handleCallTool(msg: JsonRpcRequest): void {
    const { name, arguments: args } = msg.params || {}
    if (!name) {
      this.transport.sendError(msg.id, -32602, '缺少工具名称')
      return
    }

    try {
      switch (name) {
        case 'task_create': return this.cmdTaskCreate(msg, args)
        case 'task_list': return this.cmdTaskList(msg, args)
        case 'task_update': return this.cmdTaskUpdate(msg, args)
        case 'task_get': return this.cmdTaskGet(msg, args)
        case 'task_ready': return this.cmdTaskReady(msg)
        case 'task_blocked': return this.cmdTaskBlocked(msg)
        case 'task_stats': return this.cmdTaskStats(msg)
        case 'task_reset': return this.cmdTaskReset(msg)
        case 'task_delete': return this.cmdTaskDelete(msg, args)
        case 'skill_list': return this.cmdSkillList(msg)
        case 'skill_match': return this.cmdSkillMatch(msg, args)
        case 'shield_status': return this.cmdShieldStatus(msg)
        case 'shield_check_action': return this.cmdShieldCheckAction(msg, args)
        case 'context_slice': return this.cmdContextSlice(msg, args)
        default:
          this.transport.sendError(msg.id, -32601, `未知工具: ${name}`)
      }
    } catch (e: any) {
      this.transport.sendError(msg.id, -32603, `工具执行错误: ${e.message}`)
    }
  }

  // ===== 工具实现 =====

  private cmdTaskCreate(msg: JsonRpcRequest, args: any): void {
    const task = this.orion.createTask({
      title: args.title,
      description: args.description || args.title,
      dependencies: args.dependencies,
      priority: args.priority,
      files: args.files,
      tags: args.tags,
      maxRetries: args.maxRetries,
    })

    // 自动匹配技能
    const matched = this.skills.matchSkills(task)

    const result: any = {
      id: task.id,
      title: task.title,
      status: task.status,
      dependencies: task.dependencies,
      priority: task.priority,
    }

    if (matched.length > 0) {
      result.matchedSkills = matched.slice(0, 3).map(m => ({
        name: m.skill.name,
        score: Math.round(m.score * 100),
        matchedOn: m.matchedOn,
      }))
    }

    this.transport.sendResult(msg.id, { content: [{ type: 'text', text: JSON.stringify(result, null, 2) }] })
  }

  private cmdTaskList(msg: JsonRpcRequest, args: any): void {
    let tasks = this.orion.getAllTasks()
    if (args?.status) tasks = tasks.filter(t => t.status === args.status)
    if (args?.priority) tasks = tasks.filter(t => t.priority === args.priority)

    const result = tasks.map(t => ({
      id: t.id,
      title: t.title,
      status: t.status,
      priority: t.priority,
      dependencies: t.dependencies,
      attempts: t.attempts.length,
    }))

    this.transport.sendResult(msg.id, { content: [{ type: 'text', text: JSON.stringify(result, null, 2) }] })
  }

  private cmdTaskUpdate(msg: JsonRpcRequest, args: any): void {
    if (args.status) {
      const task = this.orion.updateStatus(args.id, args.status as TaskStatus, args.blockedReason)
      if (!task) {
        this.transport.sendError(msg.id, -32602, `任务 ${args.id} 不存在`)
        return
      }
      this.transport.sendResult(msg.id, {
        content: [{ type: 'text', text: JSON.stringify({ id: task.id, status: task.status }, null, 2) }],
      })
    } else {
      this.transport.sendError(msg.id, -32602, '缺少 status 参数')
    }
  }

  private cmdTaskGet(msg: JsonRpcRequest, args: any): void {
    const task = this.orion.getTask(args.id)
    if (!task) {
      this.transport.sendError(msg.id, -32602, `任务 ${args.id} 不存在`)
      return
    }
    this.transport.sendResult(msg.id, { content: [{ type: 'text', text: JSON.stringify(task, null, 2) }] })
  }

  private cmdTaskReady(msg: JsonRpcRequest): void {
    const ready = this.orion.getReadyTasks()
    this.transport.sendResult(msg.id, {
      content: [{ type: 'text', text: JSON.stringify(ready.map(t => ({ id: t.id, title: t.title })), null, 2) }],
    })
  }

  private cmdTaskBlocked(msg: JsonRpcRequest): void {
    const blocked = this.orion.getBlockedTasks()
    this.transport.sendResult(msg.id, {
      content: [{ type: 'text', text: JSON.stringify(blocked.map(b => ({ id: b.task.id, title: b.task.title, reason: b.reason })), null, 2) }],
    })
  }

  private cmdTaskStats(msg: JsonRpcRequest): void {
    const stats = this.orion.getStats()
    this.transport.sendResult(msg.id, { content: [{ type: 'text', text: JSON.stringify(stats, null, 2) }] })
  }

  private cmdTaskReset(msg: JsonRpcRequest): void {
    const count = this.orion.resetActiveTasks()
    this.transport.sendResult(msg.id, {
      content: [{ type: 'text', text: JSON.stringify({ resetCount: count }, null, 2) }],
    })
  }

  private cmdTaskDelete(msg: JsonRpcRequest, args: any): void {
    const ok = this.orion.deleteTask(args.id)
    this.transport.sendResult(msg.id, {
      content: [{ type: 'text', text: JSON.stringify({ deleted: ok }, null, 2) }],
    })
  }

  private cmdSkillList(msg: JsonRpcRequest): void {
    const all = this.skills.getAllSkills()
    this.transport.sendResult(msg.id, {
      content: [{ type: 'text', text: JSON.stringify(all.map(s => ({
        name: s.name,
        version: s.version,
        description: s.description,
        tags: s.tags,
        content: s.content.type,
      })), null, 2) }],
    })
  }

  private cmdSkillMatch(msg: JsonRpcRequest, args: any): void {
    const matched = this.skills.matchSkills({ title: args.title, description: args.description })
    this.transport.sendResult(msg.id, {
      content: [{ type: 'text', text: JSON.stringify(matched.map(m => ({
        name: m.skill.name,
        score: Math.round(m.score * 100),
        matchedOn: m.matchedOn,
        content: m.skill.content.type,
      })), null, 2) }],
    })
  }

  private cmdShieldStatus(msg: JsonRpcRequest): void {
    const cfg = this.shield.getConfig()
    this.transport.sendResult(msg.id, {
      content: [{ type: 'text', text: JSON.stringify({
        enabled: cfg.enabled,
        loopDetection: cfg.loopDetection,
        failureThreshold: cfg.failureThreshold,
      }, null, 2) }],
    })
  }

  private cmdShieldCheckAction(msg: JsonRpcRequest, args: any): void {
    this.shield.recordAction({
      timestamp: Date.now(),
      tool: args.tool,
      result: args.result,
      file: args.file,
    })
    const loop = this.shield.detectLoop()
    this.transport.sendResult(msg.id, {
      content: [{ type: 'text', text: JSON.stringify({ recorded: true, loopDetected: !!loop, warning: loop }, null, 2) }],
    })
  }

  private cmdContextSlice(msg: JsonRpcRequest, args: any): void {
    const task = this.orion.getTask(args.taskId)
    if (!task) {
      this.transport.sendError(msg.id, -32602, `任务 ${args.taskId} 不存在`)
      return
    }

    const maxFiles = args.maxFiles || 10
    const files = task.scope.files.slice(0, maxFiles)

    // 检查文件是否存在
    const existingFiles = files.filter(f => existsSync(join(process.cwd(), f)))

    this.transport.sendResult(msg.id, {
      content: [{ type: 'text', text: JSON.stringify({
        taskId: task.id,
        title: task.title,
        relevantFiles: existingFiles,
        totalFiles: task.scope.files.length,
        tags: task.scope.tags,
        matchedSkills: task.scope.skills,
      }, null, 2) }],
    })
  }
}

// ===== 启动入口 =====

// 当直接运行时启动 MCP Server
const isMain = process.argv[1]?.endsWith('mcp-server.js') ||
               process.argv[1]?.endsWith('mcp-server.ts')

if (isMain) {
  const server = new OrionMCPServer()
  server.start()
}
