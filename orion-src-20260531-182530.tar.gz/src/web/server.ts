// Orion — Web UI (文件版本)
// 从外部 HTML 文件加载，避免 TypeScript 模板字面量问题

import { createServer } from 'node:http'
import { readFileSync, existsSync, writeFileSync, mkdirSync, rmSync } from 'node:fs'
import { execSync } from 'node:child_process'
import { join, dirname, resolve, relative } from 'node:path'
import { fileURLToPath } from 'node:url'
import { URL } from 'node:url'
import { TaskOrchestrator } from '../orchestrator/index.js'
import { Shield } from '../shield/index.js'
import { SkillsEngine } from '../skills/index.js'
import { CheckpointManager, formatCheckpointTerminal } from '../checkpoint/manager.js'
import { ProviderEngine } from '../provider/index.js'
import { rollbackChanges, saveCheckpoint, listCheckpoints, getCheckpointDiff, restoreCheckpoint } from '../agent/tools.js'
import { detectOutputActions, executeOutputActions } from '../utils/output-handler.js'
import type { Task, TaskStatus } from '../types/task.js'
import type { FileChange } from '../agent/tools.js'

const __dirname = dirname(fileURLToPath(import.meta.url))

export class WebServer {
  private port: number
  private orion: TaskOrchestrator
  private shield: Shield
  private skills: SkillsEngine
  private checkpoints: CheckpointManager
  private sseClients: Set<import('node:http').ServerResponse> = new Set()
  private runningJobs: Set<string> = new Set()
  private taskControllers: Map<string, AbortController> = new Map()
  private taskProviders: Map<string, string> = new Map()
  private lastTaskChanges: Map<string, FileChange[]> = new Map()
  private htmlContent: string

  constructor(orion: TaskOrchestrator, shield: Shield, skills: SkillsEngine, port = 3939) {
    this.port = port
    this.orion = orion
    this.shield = shield
    this.skills = skills
    this.skills.loadAll()
    this.checkpoints = new CheckpointManager()

    this.checkpoints.onCheckpoint((cp) => {
      this.broadcastSSE({ type: 'checkpoint', checkpoint: cp })
      console.error(formatCheckpointTerminal(cp))
    })

    // 从外部文件加载 HTML
    const htmlPath = join(__dirname, '..', '..', 'orion-web.html')
    if (existsSync(htmlPath)) {
      this.htmlContent = readFileSync(htmlPath, 'utf-8')
    } else {
      this.htmlContent = '<html><body><h1>Orion Web UI</h1><p>Missing orion-web.html</p></body></html>'
      console.error('[orion-web] 未找到 orion-web.html，请运行: npm run build:web')
    }
  }

  private broadcastSSE(data: any): void {
    const msg = `data: ${JSON.stringify(data)}\n\n`
    for (const client of this.sseClients) {
      try { client.write(msg) } catch { this.sseClients.delete(client) }
    }
  }

  start(): void {
    const server = createServer((req, res) => {
      const url = new URL(req.url || '/', `http://${req.headers.host || 'localhost'}`)
      const path = url.pathname
      res.setHeader('Access-Control-Allow-Origin', '*')
      res.setHeader('Access-Control-Allow-Methods', 'GET,POST,OPTIONS')
      res.setHeader('Access-Control-Allow-Headers', 'Content-Type')
      if (req.method === 'OPTIONS') { res.writeHead(204); res.end(); return }

      if (path === '/events') {
        res.writeHead(200, { 'Content-Type': 'text/event-stream; charset=utf-8', 'Cache-Control': 'no-cache', 'Connection': 'keep-alive' })
        res.write('data: {"type":"connected"}\n\n')
        this.sseClients.add(res)
        req.on('close', () => this.sseClients.delete(res))
        return
      }

      if (path.startsWith('/api/')) { this.handleAPI(req, res, url); return }
      if (path === '/' || path === '/index.html') {
        res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' })
        res.end(this.htmlContent)
        return
      }
      res.writeHead(404); res.end('Not Found')
    })

    server.listen(this.port, () => {
      console.error(`\n[orion-web] http://localhost:${this.port}`)
    })
  }

  private async handleAPI(req: import('node:http').IncomingMessage, res: import('node:http').ServerResponse, url: URL): Promise<void> {
    const path = url.pathname.slice(5)
    const method = req.method || 'GET'
    const body = (method === 'POST' || method === 'PATCH') ? JSON.parse(await this.readBody(req) || '{}') : {}
    const json = (data: any) => { res.writeHead(200, { 'Content-Type': 'application/json' }); res.end(JSON.stringify(data)) }
    const err = (code: number, msg: string) => { res.writeHead(code); res.end(JSON.stringify({ error: msg })) }

    try {
      const provider = this.getProvider()

      // Checkpoints
      if (path === 'checkpoints' && method === 'GET') return json(this.checkpoints.getPendingCheckpoints())
      if (path === 'checkpoints/all' && method === 'GET') return json(this.checkpoints.getAllCheckpoints())
      if (path === 'checkpoints/stats' && method === 'GET') return json(this.checkpoints.getStats())
      // 文件状态 Checkpoints（快照/回滚）
      if (path === 'checkpoints/files' && method === 'GET') return json(listCheckpoints(process.cwd()))
      if (path === 'checkpoints/save' && method === 'POST') {
        const ckpt = saveCheckpoint(process.cwd(), body.label || '', body.files || [])
        return ckpt ? json(ckpt) : err(500, 'checkpoint 保存失败')
      }
      if (path === 'checkpoints/diff' && method === 'POST') {
        const diff = getCheckpointDiff(process.cwd(), body.id || '')
        return diff !== null ? json({ diff }) : err(404, 'checkpoint 不存在')
      }
      if (path === 'checkpoints/restore' && method === 'POST') {
        const result = restoreCheckpoint(process.cwd(), body.id || '')
        this.broadcastSSE({ type: 'checkpoint-restored', id: body.id, result })
        return json(result)
      }
      if (path.startsWith('checkpoints/') && method === 'POST') {
        const id = path.split('/')[1]
        let cp: any
        switch (body.action || 'approve') {
          case 'approve': cp = this.checkpoints.approve(id, body.comment); break
          case 'reject': cp = this.checkpoints.reject(id, body.comment); break
          case 'redirect': cp = this.checkpoints.redirect(id, body.direction || '', body.comment); break
          case 'skip': cp = this.checkpoints.skip(id); break
        }
        if (!cp) return err(404, 'checkpoint not found')
        if ((body.action || 'approve') === 'approve' && cp.taskId) {
          this.orion.updateStatus(cp.taskId, 'ready')
          this.broadcastSSE({ type: 'task-update', taskId: cp.taskId, status: 'ready' })
        }
        return json(cp)
      }

      // Skills
      if (path === 'skills/learn' && method === 'POST') {
        const task = this.orion.getTask(body.taskId)
        if (!task) return err(404, 'task not found')
        const skillName = body.skillName || task.title
        const result = this.skills.learnFromTask(task, skillName)
        if (!result) return err(500, 'failed to create skill')
        this.broadcastSSE({ type: 'skill-learned', skillPath: result.path })
        return json(result)
      }

      // Tasks
      if (path === 'tasks' && method === 'GET') return json(this.orion.getAllTasks())
      if (path === 'tasks/stats' && method === 'GET') return json(this.orion.getStats())
      if (path === 'tasks/ready' && method === 'GET') return json(this.orion.getReadyTasks())
      if (path === 'tasks/blocked' && method === 'GET') return json(this.orion.getBlockedTasks())
      if (path === 'tasks/reset' && method === 'POST') return json({ resetCount: this.orion.resetActiveTasks() })
      if (path === 'tasks/next' && method === 'GET') {
        const next = this.orion.getNextTask()
        return json(next ? { task: next, progress: this.orion.getSubtaskProgress(next.id) } : { task: null, message: '所有任务已完成' })
      }
      if (path === 'tasks/tree' && method === 'GET') {
        const tree = this.orion.getTaskTree()
        return json(tree.map(t => ({
          ...t,
          subtasks: this.orion.getSubtasks(t.id),
          progress: this.orion.getSubtaskProgress(t.id),
        })))
      }
      if (path === 'tasks' && method === 'POST') {
        const task = this.orion.createTask(body)
        const matchedSkills = this.skills.matchSkills(task)
        // 如果有匹配的工作流技能，自动展开子任务
        let subTasks: Task[] = []
        const workflowSkill = this.skills.getBestWorkflowSkill(task)
        if (workflowSkill) {
          subTasks = this.skills.expandWorkflow(task, workflowSkill, this.orion)
        }
        return json({ task, matchedSkills, subTasks })
      }
      if (path.startsWith('tasks/') && method === 'GET') {
        const t = this.orion.getTask(path.slice(6))
        return t ? json(t) : err(404, 'task not found')
      }
      if (path.startsWith('tasks/') && method === 'PATCH') {
        const id = path.slice(6)
        if (body.status) this.orion.updateStatus(id, body.status, body.blockedReason)
        if (body.title || body.description) this.orion.updateTask(id, body)
        return json(this.orion.getTask(id))
      }
      if (path.startsWith('tasks/') && method === 'DELETE') {
        const id = path.slice(6)
        const task = this.orion.getTask(id)
        if (task?.outputDir && existsSync(task.outputDir)) {
          // 验证 outputDir 在项目根目录内，防止路径篡改
          const resolvedDir = resolve(task.outputDir)
          const projectRoot = resolve('.')
          if (relative(projectRoot, resolvedDir).startsWith('..') || resolvedDir === projectRoot) {
            console.error(`[orion-web] 拒绝删除: outputDir 路径越界 ${task.outputDir}`)
            return json({ deleted: false, error: 'outputDir 路径校验失败' })
          }

          // 打包备份
          const ts = new Date().toISOString().replace(/[:.]/g, '-').slice(0, 19)
          const safeTitle = task.title.replace(/[\\/:*?"<>|]/g, '').replace(/\s+/g, '-').slice(0, 50)
          const archiveName = `${safeTitle}-${ts}`
          const archiveDir = join(process.cwd(), 'src', 'Projects')
          mkdirSync(archiveDir, { recursive: true })

          let archiveOk = false
          try {
            if (process.platform === 'win32') {
              const zipPath = join(archiveDir, archiveName + '.zip')
              execSync(`powershell -Command "Compress-Archive -Path '${resolvedDir}' -DestinationPath '${zipPath}' -Force"`, { stdio: 'pipe', windowsHide: true })
            } else {
              const tgzPath = join(archiveDir, archiveName + '.tar.gz')
              const parent = dirname(resolvedDir)
              const dirName = resolvedDir.split(/[/\\]/).pop()
              execSync(`tar -czf "${tgzPath}" -C "${parent}" "${dirName}"`, { stdio: 'pipe' })
            }
            archiveOk = true
          } catch (e: any) {
            console.error(`[orion-web] 归档失败: ${e.message}`)
          }

          if (archiveOk) {
            try { rmSync(resolvedDir, { recursive: true, force: true }) } catch (e: any) {
              console.error(`[orion-web] 删除产出目录失败: ${e.message}`)
            }
          }
        }
        return json({ deleted: this.orion.deleteTask(id) })
      }

      // Execute
      if (path === 'tasks/execute-ready' && method === 'POST') {
        const ready = this.orion.getReadyTasks()
        if (!ready.length) return json({ executed: 0, message: '没有可执行任务' })

        const { ModelManager: MM } = await import('../model/manager.js')
        const mm = new MM()
        const providerCounts = new Map<string, number>()
        for (const [_, p] of this.taskProviders) {
          providerCounts.set(p, (providerCounts.get(p) || 0) + 1)
        }

        const running: string[] = []
        for (const t of ready) {
          if (this.runningJobs.has(t.id)) continue
          const pid = t.assignedProvider || mm.getActiveProvider()?.id || 'local'
          const pconfig = mm.getProvider(pid)
          const maxConc = pconfig?.maxConcurrency ?? 99
          const current = providerCounts.get(pid) || 0
          if (current >= maxConc) continue
          providerCounts.set(pid, current + 1)
          this.executeTaskAsync(t.id, pid)
          running.push(t.id)
        }
        return json({ executed: running.length, tasks: running })
      }
      if (path.startsWith('tasks/') && path.endsWith('/execute') && method === 'POST') {
        const id = path.slice(6).replace('/execute', '')
        const task = this.orion.getTask(id)
        if (!task) return err(404, 'task not found')
        if (this.runningJobs.has(id)) return json({ status: 'already-running', taskId: id })

        // 并发检查：统计当前使用同一 provider 的运行中任务数
        const { ModelManager: MM } = await import('../model/manager.js')
        const mm = new MM()
        const providerId = task.assignedProvider || mm.getActiveProvider()?.id || 'local'
        const providerConfig = mm.getProvider(providerId)
        const maxConcurrency = providerConfig?.maxConcurrency ?? 99
        const currentCount = Array.from(this.taskProviders.values()).filter(p => p === providerId).length
        if (currentCount >= maxConcurrency) {
          return json({ status: 'queued', taskId: id, reason: `${providerId} 已达到最大并发数 ${maxConcurrency}` })
        }

        this.executeTaskAsync(id, providerId)
        return json({ status: 'started', taskId: id })
      }
      if (path.startsWith('tasks/') && path.endsWith('/pause') && method === 'POST') {
        const id = path.slice(6).replace('/pause', '')
        const controller = this.taskControllers.get(id)
        if (controller) { controller.abort(); this.taskControllers.delete(id) }
        this.orion.updateStatus(id, 'paused', '用户暂停')
        this.runningJobs.delete(id)
        this.taskProviders.delete(id)
        this.broadcastSSE({ type: 'task-paused', taskId: id })
        return json({ status: 'paused', taskId: id })
      }
      if (path.startsWith('tasks/') && path.endsWith('/resume') && method === 'POST') {
        const id = path.slice(6).replace('/resume', '')
        const task = this.orion.getTask(id)
        if (!task) return err(404, 'task not found')
        this.orion.updateStatus(id, 'ready')
        this.executeTaskAsync(id, task.assignedProvider)
        this.broadcastSSE({ type: 'task-resumed', taskId: id })
        return json({ status: 'resumed', taskId: id })
      }
      if (path.startsWith('tasks/') && path.endsWith('/stop') && method === 'POST') {
        const id = path.slice(6).replace('/stop', '')
        const controller = this.taskControllers.get(id)
        if (controller) { controller.abort(); this.taskControllers.delete(id) }
        this.orion.updateStatus(id, 'cancelled', '用户取消')
        this.runningJobs.delete(id)
        this.taskProviders.delete(id)
        this.broadcastSSE({ type: 'task-cancelled', taskId: id })
        return json({ status: 'cancelled', taskId: id })
      }

      // Skills
      if (path === 'skills' && method === 'GET') return json(this.skills.getAllSkills())
      if (path === 'skills/match' && method === 'POST') return json(this.skills.matchSkills(body))

      // Shield
      if (path === 'shield' && method === 'GET') return json(this.shield.getConfig())
      if (path === 'shield' && method === 'POST') {
        this.shield.updateConfig(body)
        return json({ ok: true, config: this.shield.getConfig() })
      }

      // Automation
      // Permissions
      if (path === 'shield/permissions' && method === 'GET') return json(this.shield.getPermissionConfig())
      if (path === 'shield/permissions/mode' && method === 'POST') {
        this.shield.setPermissionMode(body.mode || 'normal')
        return json({ ok: true, mode: body.mode })
      }
      if (path === 'shield/permissions/tool' && method === 'POST') {
        this.shield.setToolPermission(body.tool || '', body.level || 'moderate')
        return json({ ok: true })
      }
      // Automation
      if (path === 'automation' && method === 'GET') return json({ autoMode: this.checkpoints.isAutoMode() })
      if (path === 'automation' && method === 'POST') {
        if (body.enabled === true) this.checkpoints.setAutoMode(true)
        else if (body.enabled === false) this.checkpoints.setAutoMode(false)
        else this.checkpoints.toggleAutoMode()
        this.broadcastSSE({ type: 'automation-change', autoMode: this.checkpoints.isAutoMode() })
        return json({ autoMode: this.checkpoints.isAutoMode() })
      }

      // Versions
      if (path.startsWith('tasks/') && path.endsWith('/versions') && method === 'GET') {
        const id = path.slice(6).replace('/versions', '')
        return json(this.orion.getVersions(id))
      }

      // Rollback
      if (path.startsWith('tasks/') && path.endsWith('/rollback') && method === 'POST') {
        const id = path.slice(6).replace('/rollback', '')
        const changes = this.lastTaskChanges.get(id)
        if (!changes || changes.length === 0) return json({ rolledBack: false, message: '没有可供回滚的更改' })
        const result = rollbackChanges(process.cwd(), changes)
        this.lastTaskChanges.delete(id)
        this.broadcastSSE({ type: 'rollback-complete', taskId: id, result })
        return json({
          rolledBack: true,
          ...result,
          message: result.gitReset
            ? '已通过 git reset --hard 回退到任务执行前的状态'
            : `已回滚 ${result.restored.length} 个文件`,
        })
      }

      // Workflow: 展开任务为子任务
      if (path.startsWith('tasks/') && path.endsWith('/expand') && method === 'POST') {
        const id = path.slice(6).replace('/expand', '')
        const task = this.orion.getTask(id)
        if (!task) return err(404, 'task not found')
        try {
          const prompt = provider.buildExpansionPrompt(task)
          const subtaskData = await provider.executeAIAction(prompt)
          if (!Array.isArray(subtaskData) || subtaskData.length === 0) {
            return err(400, 'AI 未能生成有效的子任务，请重试')
          }
          const created = this.orion.createSubtasks(id, subtaskData)
          this.broadcastSSE({ type: 'task-expanded', taskId: id, subtaskCount: created.length })
          return json({ task: this.orion.getTask(id), subtasks: created })
        } catch (e: any) { return err(500, e.message) }
      }
      // Workflow: 追加实现笔记
      if (path.startsWith('tasks/') && path.endsWith('/notes') && method === 'POST') {
        const id = path.slice(6).replace('/notes', '')
        const updated = this.orion.updateSubtask(id, body.notes || '')
        return updated ? json(updated) : err(404, 'task not found')
      }
      // Workflow: 与运行中任务交互
      if (path.startsWith('tasks/') && path.endsWith('/chat') && method === 'POST') {
        const id = path.slice(6).replace('/chat', '')
        const message = body.message || ''
        if (!message) return err(400, 'message is required')
        // 检查是否有待处理的断点，如果有则自动重定向
        const pending = this.checkpoints.getPendingCheckpoints()
        const taskCp = pending.find((cp: any) => cp.taskId === id)
        if (taskCp) {
          this.checkpoints.redirect(taskCp.id, message, '用户通过聊天输入')
          this.broadcastSSE({ type: 'chat-message', taskId: id, message, redirected: true })
          return json({ status: 'redirected', checkpointId: taskCp.id })
        }
        // 广播消息给正在执行的任务
        this.broadcastSSE({ type: 'chat-message', taskId: id, message })
        return json({ status: 'sent' })
      }
      // Workflow: 解析 PRD
      if (path === 'tasks/parse-prd' && method === 'POST') {
        try {
          const prompt = provider.buildPRDParsePrompt(body.prd || '')
          const taskTree = await provider.executeAIAction(prompt)
          if (!Array.isArray(taskTree) || taskTree.length === 0) {
            return err(400, 'AI 未能从 PRD 中解析出任务，请检查 PRD 内容')
          }
          const allCreated: Task[] = []
          for (const node of taskTree) {
            const parent = this.orion.createTask({
              title: node.title,
              description: node.description,
              priority: node.priority || 'medium',
            })
            allCreated.push(parent)
            if (node.subtasks && Array.isArray(node.subtasks)) {
              const subs = this.orion.createSubtasks(parent.id, node.subtasks)
              allCreated.push(...subs)
            }
          }
          this.broadcastSSE({ type: 'prd-parsed', taskCount: allCreated.length })
          return json({ tasks: allCreated, count: allCreated.length })
        } catch (e: any) { return err(500, e.message) }
      }
      // Models
      if (path === 'models' && method === 'GET') {
        const { ModelManager } = await import('../model/manager.js')
        return json(new ModelManager().listProviders())
      }
      if (path === 'models/switch' && method === 'POST') {
        const { ModelManager } = await import('../model/manager.js')
        const mm = new ModelManager()
        return json(body.id && mm.switchProvider(body.id) ? { ok: true, active: body.id } : { ok: false })
      }
      if (path === 'models/key' && method === 'POST') {
        const { ModelManager } = await import('../model/manager.js')
        const mm = new ModelManager()
        if (body.id && body.apiKey) { mm.setApiKey(body.id, body.apiKey); return json({ ok: true }) }
        return json({ ok: false })
      }

      err(404, 'not found')
    } catch (e: any) { err(500, e.message) }
  }

  private async executeTaskAsync(taskId: string, providerId?: string): Promise<void> {
    this.runningJobs.add(taskId)
    const task = this.orion.getTask(taskId)
    if (providerId) this.taskProviders.set(taskId, providerId)

    // 创建产出目录（解析为绝对路径，防止创建到错误位置）
    if (task?.outputDir) {
      const absDir = resolve(process.cwd(), task.outputDir)
      mkdirSync(absDir, { recursive: true })
    }

    const controller = new AbortController()
    this.taskControllers.set(taskId, controller)

    this.broadcastSSE({ type: 'execution-started', taskId, taskTitle: task?.title, providerId, outputDir: task?.outputDir })

    const autoMode = this.checkpoints.isAutoMode()
    const provider = new ProviderEngine(this.orion, this.shield, this.skills)
    try {
      const result = await provider.executeTask(taskId,
        (msg) => {
          this.broadcastSSE({ type: 'execution-progress', taskId, message: msg })
        },
        (delta) => {
          this.broadcastSSE({ type: 'execution-stream', taskId, delta })
        },
        autoMode,
        controller.signal,
        (stats) => {
          this.broadcastSSE({ type: 'context-update', taskId, stats })
        },
      )
      if (result.changes && result.changes.length > 0) {
        this.lastTaskChanges.set(taskId, result.changes)
      }
      this.broadcastSSE({
        type: result.success ? 'execution-complete' : 'execution-error',
        taskId,
        success: result.success,
        output: result.output?.slice(0, 500),
        error: result.error,
        durationMs: result.durationMs,
        tokenUsage: result.tokenUsage,
        hasRollback: !!(result.changes && result.changes.length > 0),
      })

      // 自动模式: 检测并执行/打开产出物
      if (result.success && autoMode) {
        const newFiles = result.newFiles || []
        const changes = result.changes || []
        if (newFiles.length > 0 || changes.length > 0) {
          const actions = detectOutputActions(newFiles, changes, process.cwd())
          if (actions.length > 0) {
            const outputResults = executeOutputActions(actions, process.cwd(), (msg) => {
              this.broadcastSSE({ type: 'execution-progress', taskId, message: msg })
            })
            this.broadcastSSE({
              type: 'output-actions',
              taskId,
              actions: actions.map(a => a.description),
              results: outputResults,
            })
          }
        }
      }
    } catch (e: any) {
      this.broadcastSSE({ type: 'execution-error', taskId, error: e.message })
    } finally {
      this.runningJobs.delete(taskId)
      this.taskControllers.delete(taskId)
      this.taskProviders.delete(taskId)
    }
  }

  private getProvider(): ProviderEngine {
    return new ProviderEngine(this.orion, this.shield, this.skills)
  }

  private readBody(req: import('node:http').IncomingMessage): Promise<string> {
    return new Promise(r => { let d = ''; req.on('data', (c: string) => d += c); req.on('end', () => r(d)) })
  }
}
