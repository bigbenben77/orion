// Orion — 文件监听器
// 自动检测项目文件变化，触发任务相关操作

import { watch } from 'chokidar'
import { join, relative } from 'node:path'
import { existsSync, readFileSync } from 'node:fs'
import type { Task } from '../types/task.js'
import { TaskOrchestrator } from '../orchestrator/index.js'

export class FileWatcher {
  private watcher: ReturnType<typeof watch> | null = null
  private orion: TaskOrchestrator
  private onChange?: (event: FileChangeEvent) => void

  constructor(orion: TaskOrchestrator) {
    this.orion = orion
  }

  start(cwd: string, onChange?: (event: FileChangeEvent) => void): void {
    this.onChange = onChange
    const watchDirs = [
      join(cwd, 'src'),
      join(cwd, '.orion'),
    ].filter(d => existsSync(d))

    if (watchDirs.length === 0) {
      watchDirs.push(cwd)
    }

    this.watcher = watch(watchDirs, {
      ignored: /(node_modules|\.git|dist|\.orion\/tasks\.json)/,
      persistent: true,
      ignoreInitial: true,
      depth: 5,
    })

    this.watcher
      .on('add', (path) => this.handleEvent('add', path, cwd))
      .on('change', (path) => this.handleEvent('change', path, cwd))
      .on('unlink', (path) => this.handleEvent('unlink', path, cwd))

    const watched = watchDirs.join(', ')
    console.error(`[orion-watch] 监听: ${watched}`)
  }

  stop(): void {
    if (this.watcher) {
      this.watcher.close()
      this.watcher = null
    }
  }

  private handleEvent(type: 'add' | 'change' | 'unlink', filePath: string, cwd: string): void {
    const relPath = relative(cwd, filePath).replace(/\\/g, '/')

    // 自动匹配到相关任务
    const relatedTasks = this.findRelatedTasks(relPath)

    const event: FileChangeEvent = {
      type,
      path: relPath,
      relatedTasks,
      timestamp: Date.now(),
    }

    if (this.onChange) {
      this.onChange(event)
    } else {
      this.defaultHandler(event)
    }
  }

  private findRelatedTasks(filePath: string): Task[] {
    return this.orion.getAllTasks().filter(t =>
      t.status !== 'done' &&
      t.scope.files.some(f => filePath.includes(f) || f.includes(filePath))
    )
  }

  private defaultHandler(event: FileChangeEvent): void {
    const icon = { add: '📄', change: '✏️', unlink: '🗑️' }[event.type]
    console.error(`[orion-watch] ${icon} ${event.path}`)

    if (event.relatedTasks.length > 0) {
      for (const task of event.relatedTasks) {
        console.error(`  → 关联任务: [${task.id}] ${task.title} (${task.status})`)
      }
    }
  }
}

export interface FileChangeEvent {
  type: 'add' | 'change' | 'unlink'
  path: string
  relatedTasks: Task[]
  timestamp: number
}
