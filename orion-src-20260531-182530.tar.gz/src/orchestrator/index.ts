// Orion — Task Orchestrator (任务编排引擎)
// 负责 tasks.json 的读写、状态管理、依赖解析

import { readFileSync, writeFileSync, existsSync, mkdirSync } from 'node:fs'
import { join, dirname } from 'node:path'
import type { Task, TaskMode, TaskStore, TaskStatus, TaskAttempt, TaskVersion } from '../types/task.js'

const DEFAULT_STORE: TaskStore = {
  version: '1.0.0',
  tasks: {},
  metadata: {
    lastTaskId: 0,
    created: Date.now(),
    updated: Date.now(),
  },
}

export class TaskOrchestrator {
  private store: TaskStore
  private storePath: string

  constructor(projectRoot?: string) {
    const root = projectRoot || process.cwd()
    this.storePath = join(root, '.orion', 'tasks.json')
    this.store = this.loadStore()
  }

  // ===== 读写 =====

  private loadStore(): TaskStore {
    try {
      if (existsSync(this.storePath)) {
        const raw = readFileSync(this.storePath, 'utf-8')
        return JSON.parse(raw) as TaskStore
      }
    } catch {
      console.warn('[orion] 无法读取 tasks.json，使用默认空状态')
    }
    return { ...DEFAULT_STORE, metadata: { ...DEFAULT_STORE.metadata, created: Date.now() } }
  }

  save(): void {
    this.store.metadata.updated = Date.now()
    const dir = dirname(this.storePath)
    if (!existsSync(dir)) mkdirSync(dir, { recursive: true })
    writeFileSync(this.storePath, JSON.stringify(this.store, null, 2), 'utf-8')
  }

  // ===== 任务 CRUD =====

  createTask(params: {
    title: string
    description: string
    dependencies?: string[]
    priority?: 'low' | 'medium' | 'high' | 'critical'
    mode?: TaskMode
    files?: string[]
    tags?: string[]
    skills?: string[]
    maxRetries?: number
  }): Task {
    this.store.metadata.lastTaskId++
    const id = `task-${this.store.metadata.lastTaskId}`
    const slug = slugify(params.title, 40)

    const task: Task = {
      id,
      displayId: String(this.store.metadata.lastTaskId),
      title: params.title,
      description: params.description,
      status: 'pending',
      outputDir: `src/Projects/${id}-${slug}`,
      dependencies: params.dependencies || [],
      subtaskIds: [],
      priority: params.priority || 'medium',
      mode: params.mode || 'code',
      scope: {
        files: params.files || [],
        relatedTasks: [],
        tags: params.tags || [],
        skills: params.skills || [],
      },
      attempts: [],
      maxRetries: params.maxRetries ?? 3,
      autoFix: true,
      acceptance: {
        criteria: [],
        tests: [],
      },
      created: Date.now(),
      updated: Date.now(),
    }

    this.store.tasks[id] = task
    this.save()
    return task
  }

  getTask(id: string): Task | undefined {
    return this.store.tasks[id]
  }

  getAllTasks(): Task[] {
    return Object.values(this.store.tasks)
  }

  updateStatus(id: string, status: TaskStatus, reason?: string): Task | undefined {
    const task = this.store.tasks[id]
    if (!task) return undefined

    task.status = status
    task.updated = Date.now()
    if (status === 'blocked') task.blockedReason = reason
    this.save()
    return task
  }

  addAttempt(id: string, attempt: TaskAttempt): void {
    const task = this.store.tasks[id]
    if (!task) return
    task.attempts.push(attempt)
    task.updated = Date.now()
    this.save()
  }

  addVersions(id: string, versions: TaskVersion[]): void {
    const task = this.store.tasks[id]
    if (!task) return
    task.versions = versions
    task.updated = Date.now()
    this.save()
  }

  getVersions(id: string): TaskVersion[] {
    const task = this.store.tasks[id]
    return task?.versions || []
  }

  deleteTask(id: string): boolean {
    if (!this.store.tasks[id]) return false
    delete this.store.tasks[id]
    this.save()
    return true
  }

  updateTask(id: string, updates: Partial<Task>): Task | undefined {
    const task = this.store.tasks[id]
    if (!task) return undefined
    Object.assign(task, updates, { updated: Date.now() })
    this.save()
    return task
  }

  // ===== 依赖解析 =====

  /** 返回当前可执行的任务（所有依赖已完成） */
  getReadyTasks(): Task[] {
    return this.getAllTasks().filter(t => {
      if (t.status !== 'pending' && t.status !== 'deferred') return false
      return t.dependencies.every(depId => {
        const dep = this.store.tasks[depId]
        return dep?.status === 'done'
      })
    })
  }

  /** 返回阻塞的任务及其原因 */
  getBlockedTasks(): { task: Task; reason: string }[] {
    const result: { task: Task; reason: string }[] = []
    for (const task of this.getAllTasks()) {
      if (task.status !== 'pending') continue
      for (const depId of task.dependencies) {
        const dep = this.store.tasks[depId]
        if (!dep || dep.status === 'cancelled') {
          result.push({ task, reason: `依赖 ${depId} 不存在或已取消` })
          break
        } else if (dep.status === 'blocked') {
          result.push({ task, reason: `依赖 ${depId} 被阻塞: ${dep.blockedReason || '未知'}` })
          break
        }
      }
    }
    return result
  }

  /** 生成任务依赖图（用于可视化） */
  getDependencyGraph(): { nodes: string[]; edges: [string, string][] } {
    const nodes = this.getAllTasks().map(t => t.id)
    const edges: [string, string][] = []
    for (const task of this.getAllTasks()) {
      for (const dep of task.dependencies) {
        edges.push([dep, task.id])
      }
    }
    return { nodes, edges }
  }

  /** 按状态分组统计 */
  getStats(): Record<TaskStatus, number> {
    const stats: Record<string, number> = {
      pending: 0, ready: 0, 'in-progress': 0, review: 0,
      blocked: 0, done: 0, cancelled: 0, deferred: 0, paused: 0,
    }
    for (const task of this.getAllTasks()) {
      stats[task.status] = (stats[task.status] || 0) + 1
    }
    return stats as Record<TaskStatus, number>
  }

  /** 重置所有进行中/ready 任务为 pending（用于中断后恢复） */
  resetActiveTasks(): number {
    let count = 0
    for (const task of this.getAllTasks()) {
      if (task.status === 'in-progress' || task.status === 'ready') {
        task.status = 'pending'
        task.updated = Date.now()
        count++
      }
    }
    if (count > 0) this.save()
    return count
  }

  // ===== 任务工作流 =====

  /** 返回下一个可执行的任务（优先子任务、高优先级、依赖已满足） */
  getNextTask(): Task | null {
    const priorityOrder = { critical: 0, high: 1, medium: 2, low: 3 }

    const candidates = this.getAllTasks().filter(t => {
      if (t.status === 'done' || t.status === 'cancelled' || t.status === 'blocked' || t.status === 'in-progress') return false
      // 检查依赖是否都已完成
      return t.dependencies.every(depId => {
        const dep = this.store.tasks[depId]
        return dep?.status === 'done'
      })
    })

    // 排序: 有父任务的优先（子任务先做），然后按优先级，然后按创建时间
    candidates.sort((a, b) => {
      const aHasParent = a.parentId ? 0 : 1
      const bHasParent = b.parentId ? 0 : 1
      if (aHasParent !== bHasParent) return aHasParent - bHasParent
      const pa = priorityOrder[a.priority] ?? 2
      const pb = priorityOrder[b.priority] ?? 2
      if (pa !== pb) return pa - pb
      return a.created - b.created
    })

    return candidates[0] || null
  }

  /** 向任务追加实现笔记 */
  updateSubtask(taskId: string, notes: string): Task | undefined {
    const task = this.store.tasks[taskId]
    if (!task) return undefined
    const ts = new Date().toISOString().slice(0, 19)
    const entry = `\n### ${ts}\n${notes}`
    task.details = (task.details || '') + entry
    task.updated = Date.now()
    this.save()
    return task
  }

  /** 基于 AI 输出创建子任务 */
  createSubtasks(parentId: string, subtaskData: { title: string; description: string; priority?: string; details?: string; testStrategy?: string }[]): Task[] {
    const parent = this.store.tasks[parentId]
    if (!parent) return []

    const parentDisplayId = parent.displayId || parent.id
    const created: Task[] = []

    for (let i = 0; i < subtaskData.length; i++) {
      const sd = subtaskData[i]
      this.store.metadata.lastTaskId++
      const id = `task-${this.store.metadata.lastTaskId}`
      const displayId = `${parentDisplayId}.${i + 1}`
      const slug = slugify(sd.title, 40)

      const task: Task = {
        id,
        displayId,
        title: sd.title,
        description: sd.description,
        status: 'pending',
        outputDir: `src/Projects/${id}-${slug}`,
        dependencies: [],
        subtaskIds: [],
        priority: (sd.priority as any) || parent.priority,
        mode: parent.mode,
        parentId,
        details: sd.details || '',
        testStrategy: sd.testStrategy || '',
        scope: { ...parent.scope },
        attempts: [],
        maxRetries: parent.maxRetries,
        autoFix: parent.autoFix,
        acceptance: { criteria: [], tests: [] },
        created: Date.now(),
        updated: Date.now(),
      }

      this.store.tasks[id] = task
      parent.subtaskIds.push(id)
      created.push(task)
    }

    // 更新父任务设为 review 状态
    parent.status = 'review'
    parent.updated = Date.now()
    this.save()
    return created
  }

  /** 获取任务树（递归，用于 UI 渲染） */
  getTaskTree(): Task[] {
    // 返回顶层任务（无父任务的），子任务通过 subtaskIds 关联
    return this.getAllTasks().filter(t => !t.parentId)
  }

  /** 获取任务的子任务列表 */
  getSubtasks(taskId: string): Task[] {
    const task = this.store.tasks[taskId]
    if (!task || !task.subtaskIds.length) return []
    return task.subtaskIds.map(id => this.store.tasks[id]).filter(Boolean)
  }

  /** 获取子任务完成进度 */
  getSubtaskProgress(taskId: string): { done: number; total: number } {
    const subtasks = this.getSubtasks(taskId)
    const done = subtasks.filter(s => s.status === 'done').length
    return { done, total: subtasks.length }
  }
}

function slugify(text: string, maxLen: number): string {
  return text
    .replace(/[\\/:*?"<>|]/g, '')  // 去掉非法文件名字符
    .replace(/[\s.。#@!$%^&()+=[\]{}|;',~`]+/g, '-')  // 分隔符替换为连字符
    .replace(/-+/g, '-')  // 合并连续连字符
    .replace(/^-|-$/g, '')  // 去掉首尾连字符
    .slice(0, maxLen)
    .toLowerCase()
}
