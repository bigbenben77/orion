// Orion — Provider 引擎（真模型版）
// 从 ModelManager 读配置，调用真实 AI API 执行任务

import { execSync, spawnSync } from 'node:child_process'
import { existsSync, readFileSync, writeFileSync } from 'node:fs'
import { join, resolve } from 'node:path'
import type { Task } from '../types/task.js'
import { TaskOrchestrator } from '../orchestrator/index.js'
import { Shield } from '../shield/index.js'
import { SkillsEngine } from '../skills/index.js'
import { ModelManager } from '../model/manager.js'
import { MemoryManager } from '../memory/manager.js'
import { runAgentLoop } from '../agent/index.js'
import { releaseGitBackup, getGitBackupHash, saveCheckpoint } from '../agent/tools.js'

export interface ExecutionResult {
  success: boolean
  output: string
  error?: string
  durationMs: number
  newFiles?: string[]
  tokenUsage?: {
    inputTokens: number
    outputTokens: number
  }
  changes?: import('../agent/tools.js').FileChange[]
}

export class ProviderEngine {
  private orion: TaskOrchestrator
  private shield: Shield
  private skills: SkillsEngine
  private models: ModelManager
  private memory: MemoryManager

  constructor(orion: TaskOrchestrator, shield: Shield, skills: SkillsEngine) {
    this.orion = orion
    this.shield = shield
    this.skills = skills
    this.models = new ModelManager()
    this.memory = new MemoryManager()
  }

  async executeTask(taskId: string, onProgress?: (msg: string) => void, onStream?: (delta: string) => void, autoMode?: boolean, cancelSignal?: AbortSignal, onContextUpdate?: (stats: import('../agent/index.js').ContextStats) => void): Promise<ExecutionResult> {
    const task = this.orion.getTask(taskId)
    if (!task) return { success: false, output: '', error: `任务 ${taskId} 不存在`, durationMs: 0 }

    const startTime = Date.now()
    this.orion.updateStatus(taskId, 'in-progress')

    // 保存执行前 checkpoint
    saveCheckpoint(process.cwd(), `[预执行] ${task.title}`, task.scope.files || [])

    try {
      const activeProvider = this.models.getActiveProvider()
      const providerId = task.assignedProvider || activeProvider?.id || 'local'
      const providerConfig = this.models.getProvider(providerId)
      if (!providerConfig || providerId === 'local') {
        return this.executeLocal(task)
      }

      // Shield: 记录执行动作
      this.shield.recordAction({
        tool: 'execute-task',
        params: taskId,
        result: 'success',
        timestamp: startTime,
      })

      const ctx = await this.buildTaskContext(task)
      const prompt = this.buildExecutionPrompt(task, ctx)

      // 记录到记忆
      this.memory.logSession('task-' + taskId, 'user', `执行任务: ${task.title}`)

      let result: ExecutionResult
      const cfg = providerConfig

      switch (cfg.type) {
        case 'anthropic-api':
        case 'openai-api':
        case 'openai-compatible':
          result = await runAgentLoop(
            task,
            this.getModeInstructions(task.mode),
            prompt,
            {
              type: cfg.type,
              model: cfg.model || '',
              apiKey: cfg.apiKey || '',
              baseUrl: cfg.baseUrl,
              timeoutMs: cfg.timeoutMs,
              maxContextTokens: cfg.maxContextTokens,
            },
            this.shield,
            onProgress || ((msg) => {
              if (msg) console.error(`[orion] ${msg}`)
            }),
            onStream,
            autoMode,
            cancelSignal,
            onContextUpdate,
          )
          break
        case 'claude-code':
          result = this.callClaudeCode(prompt, cfg.timeoutMs)
          break
        default:
          result = this.executeLocal(task)
      }

      result.durationMs = Date.now() - startTime

      // Shield: 记录 provider 调用结果
      this.shield.recordAction({
        tool: `provider:${cfg.type}`,
        params: cfg.model,
        result: result.success ? 'success' : 'failure',
        timestamp: Date.now(),
      })

      // Shield: 检测循环
      const loop = this.shield.detectLoop()
      if (loop && (loop.level === 'critical' || loop.level === 'escalate')) {
        console.error(`[orion] ${loop.message}`)
        if (loop.level === 'critical') {
          this.memory.logError('循环检测触发', loop.message, { tags: ['shield', 'loop', ...task.scope.tags] })
          return { success: false, output: '', error: `循环保护: ${loop.message}`, durationMs: result.durationMs }
        }
      }

      // 记录尝试
      this.orion.addAttempt(taskId, {
        timestamp: startTime,
        result: result.success ? 'success' : 'failure',
        error: result.error,
        durationMs: result.durationMs,
      })

      // 记录版本历史
      const commitHash = getGitBackupHash(process.cwd())
      const filesChanged = (result.changes || []).map(c => c.path)
      if (commitHash || filesChanged.length > 0) {
        const versions = task.versions || []
        versions.push({
          commitHash: commitHash || '',
          timestamp: startTime,
          description: result.success
            ? `完成: ${task.title}`
            : `尝试: ${task.title} (${result.error ? '失败: ' + result.error.slice(0, 80) : '未成功'})`,
          filesChanged,
          attemptIndex: task.attempts.length - 1,
        })
        this.orion.addVersions(taskId, versions)
      }

      if (result.success) {
        // 保存 AI 输出到文件
        if (result.output && result.output.length > 50) {
          const outPath = join(process.cwd(), '.orion', `output-${taskId}.md`)
          writeFileSync(outPath, result.output, 'utf-8')
          this.memory.logDecision(`完成任务: ${task.title}`, result.output.slice(0, 200), {
            tags: task.scope.tags, importance: 5, source: taskId,
          })
        }
        this.orion.updateStatus(taskId, 'done')
        releaseGitBackup(process.cwd())
      } else {
        const threshold = this.shield.checkFailureThreshold(task)
        if (threshold !== 'ok') {
          this.orion.updateStatus(taskId, 'blocked', `执行失败: ${result.error}`)
          this.memory.logError(task.title + ' 失败', result.error || '未知错误', {
            tags: task.scope.tags,
          })
          console.error(`[orion] 任务 ${taskId} 阻塞: ${result.error?.slice(0, 100) || ''}`)
        } else {
          this.orion.updateStatus(taskId, 'ready')
        }
      }

      return result
    } catch (e: any) {
      const durationMs = Date.now() - startTime
      this.orion.addAttempt(taskId, { timestamp: startTime, result: 'failure', error: e.message, durationMs })
      this.orion.updateStatus(taskId, 'blocked', `异常: ${e.message}`)
      return { success: false, output: '', error: e.message, durationMs }
    }
  }

  // ===== API 调用 =====

  private callClaudeCode(prompt: string, timeoutMs = 120000): ExecutionResult {
    const startTime = Date.now()
    try {
      const result = spawnSync('claude', ['-p', '-'], {
        input: prompt,
        timeout: timeoutMs,
        maxBuffer: 10 * 1024 * 1024,
        encoding: 'utf-8',
        windowsHide: true,
      })
      if (result.error) throw result.error
      return { success: true, output: (result.stdout || '').trim(), durationMs: Date.now() - startTime }
    } catch (e: any) {
      return { success: false, output: '', error: e.stderr?.toString() || e.message, durationMs: Date.now() - startTime }
    }
  }

  private executeLocal(task: Task): ExecutionResult {
    const plan = [
      `## 执行计划: ${task.title}`,
      `关联文件: ${task.scope.files.join(', ') || '无'}`,
      `标签: ${task.scope.tags.join(', ') || '无'}`,
      '',
      '### 步骤',
      '1. 分析当前代码结构',
      '2. 实现所需功能',
      '3. 验证结果',
      '',
      '---',
      '要真正执行，请先在 Web UI 中切换模型:',
      '  orion model list',
      '  orion model switch deepseek',
      '  orion model key deepseek sk-xxx',
      '然后: orion execute task ' + task.id,
    ].join('\n')

    const planPath = join(process.cwd(), '.orion', `plan-${task.id}.md`)
    writeFileSync(planPath, plan, 'utf-8')
    return { success: true, output: plan, durationMs: 0 }
  }

  // ===== 上下文构建 =====

  private async buildTaskContext(task: Task): Promise<string> {
    const sections: string[] = []

    // 记忆上下文
    try {
      const memCtx = this.memory.buildContext(`${task.title} ${task.description} ${task.scope.tags.join(' ')}`, 1500)
      if (memCtx) sections.push(memCtx)
    } catch { /* no memory */ }

    // 任务信息
    const displayId = task.displayId || task.id
    sections.push(`## 任务 ${displayId}\n${task.title}\n\n${task.description}`)

    // 父任务上下文
    if (task.parentId) {
      const parent = this.orion.getTask(task.parentId)
      if (parent) {
        sections.push(`## 父任务 ${parent.displayId || parent.id}\n${parent.title}\n\n${parent.description.slice(0, 300)}`)
      }
    }

    // 实现细节/笔记
    if (task.details) {
      sections.push(`## 实现笔记\n${task.details.slice(-2000)}`)
    }

    // 测试策略
    if (task.testStrategy) {
      sections.push(`## 测试策略\n${task.testStrategy}`)
    }

    // 子任务列表
    const subtasks = this.orion.getSubtasks(task.id)
    if (subtasks.length > 0) {
      const progress = this.orion.getSubtaskProgress(task.id)
      const list = subtasks.map(s => {
        const statusIcon = s.status === 'done' ? '✅' : s.status === 'in-progress' ? '🔄' : '⬜'
        return `${statusIcon} ${s.displayId || s.id}: ${s.title} [${s.status}]`
      }).join('\n')
      sections.push(`## 子任务进度 (${progress.done}/${progress.total})\n${list}\n\n请从第一个未完成的子任务开始，逐一完成。`)
    }

    // 产出目录（使用绝对路径，避免模型误解析到错误位置）
    if (task.outputDir) {
      const absDir = resolve(process.cwd(), task.outputDir)
      sections.push(`## 输出目录\n所有新建和修改的文件必须放在此目录下: \`${absDir}\`\n不要将代码写入项目根目录、src/、或其他位置。使用绝对路径进行文件操作。\n**重要**: 如果是前端/游戏项目，必须产出至少一个 HTML 入口文件使其可在浏览器直接打开。不要只生成项目脚手架或构建配置。`)
    }

    // 相关文件（只列路径，AI 用 read_file 按需获取内容，省 token）
    if (task.scope.files.length > 0) {
      const existing = task.scope.files.filter(f => existsSync(join(process.cwd(), f)))
      if (existing.length > 0) {
        sections.push('## 相关文件（使用 read_file 工具读取内容）\n' + existing.map(f => `- ${f}`).join('\n'))
      }
    }

    // 匹配技能
    const matched = this.skills.matchSkills(task)
    if (matched.length > 0) {
      sections.push('## 推荐工作流\n' + matched.slice(0, 2).map(m =>
        `- ${m.skill.name}: ${m.skill.content.type === 'workflow' ? m.skill.content.tasks.map((t: any) => t.title).join(' → ') : ''}`
      ).join('\n'))
    }

    sections.push('## 工作方式\n1. 先用 read_file 了解现有代码\n2. 用 edit_file 精确修改（不要整文件重写）\n3. 用 execute_command 验证（如运行测试、类型检查）\n4. 观察结果，必要时继续修改\n5. 全部完成后给出总结')

    return sections.join('\n\n')
  }

  // ===== 任务展开 Prompt =====

  /** 构建任务展开 prompt：让 AI 将任务分解为子任务 */
  buildExpansionPrompt(task: Task): string {
    return `你是项目管理专家。请将以下任务分解为 3-7 个具体的子任务。

## 父任务
- 标题: ${task.title}
- 描述: ${task.description}
- 模式: ${task.mode}
${task.scope.files.length > 0 ? `- 相关文件: ${task.scope.files.join(', ')}` : ''}

## 要求
1. 每个子任务应该是独立可完成的单元
2. 子任务之间应该有明确的先后依赖关系（后一个依赖前一个）
3. 优先考虑: 先设计/分析，再实现，最后测试/验证
4. 给出精确的输出 JSON，格式如下：

\`\`\`json
[
  {
    "title": "子任务标题",
    "description": "详细描述",
    "priority": "high|medium|low",
    "details": "实现要点和技术方案",
    "testStrategy": "如何验证这个子任务完成"
  }
]
\`\`\`

只输出 JSON 数组，不要其他内容。`
  }

  /** 构建 PRD 解析 prompt：让 AI 从需求文档生成任务树 */
  buildPRDParsePrompt(prdContent: string): string {
    return `你是项目管理专家。请分析以下需求文档，生成完整的任务分解方案。

## 需求文档
${prdContent}

## 要求
1. 识别主要功能模块作为顶层任务
2. 每个顶层任务分解为 2-5 个子任务
3. 标注任务之间的依赖关系
4. 评估每个任务的优先级
5. 输出 JSON 格式：

\`\`\`json
[
  {
    "title": "顶层任务标题",
    "description": "任务描述",
    "priority": "high|medium|low",
    "subtasks": [
      {
        "title": "子任务标题",
        "description": "详细描述",
        "priority": "high|medium|low",
        "details": "实现要点",
        "testStrategy": "验证方法"
      }
    ]
  }
]
\`\`\`

只输出 JSON 数组，不要其他内容。`
  }

  /** 通用 AI 调用（用于 parsePRD / expandTask 等非 agent 任务） */
  async executeAIAction(prompt: string): Promise<any> {
    const active = this.models.getActiveProvider()
    if (!active || active.id === 'local') {
      throw new Error('没有可用的 AI 模型，请先在 Web UI 中切换模型')
    }

    const cfg = active.config
    const systemPrompt = '你是 Orion 项目管理助手。严格按照要求输出结构化 JSON，不要添加额外内容。'

    switch (cfg.type) {
      case 'anthropic-api': {
        const resp = await fetch('https://api.anthropic.com/v1/messages', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json', 'x-api-key': cfg.apiKey || '', 'anthropic-version': '2023-06-01' },
          body: JSON.stringify({
            model: cfg.model || 'claude-sonnet-4-20250514',
            max_tokens: 4096,
            system: systemPrompt,
            messages: [{ role: 'user', content: prompt }],
          }),
          signal: AbortSignal.timeout(cfg.timeoutMs || 120000),
        })
        if (!resp.ok) throw new Error(`API 错误 ${resp.status}: ${await resp.text()}`)
        const data: any = await resp.json()
        const text = data.content?.map((c: any) => c.text).join('\n') || ''
        return this.extractJSON(text)
      }
      case 'openai-api':
      case 'openai-compatible': {
        const url = (cfg.baseUrl || 'https://api.openai.com/v1').replace(/\/$/, '') + '/chat/completions'
        const resp = await fetch(url, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${cfg.apiKey || ''}` },
          body: JSON.stringify({
            model: cfg.model || 'gpt-4o',
            messages: [{ role: 'system', content: systemPrompt }, { role: 'user', content: prompt }],
            max_tokens: 4096,
          }),
          signal: AbortSignal.timeout(cfg.timeoutMs || 120000),
        })
        if (!resp.ok) throw new Error(`API 错误 ${resp.status}: ${await resp.text()}`)
        const data: any = await resp.json()
        const text = data.choices?.[0]?.message?.content || ''
        return this.extractJSON(text)
      }
      default:
        throw new Error(`不支持的 provider 类型: ${cfg.type}`)
    }
  }

  /** 从 AI 输出中提取 JSON */
  private extractJSON(text: string): any {
    // 尝试直接解析
    try { return JSON.parse(text) } catch {}
    // 尝试提取 ```json ... ``` 块
    const m = text.match(/```(?:json)?\s*([\s\S]*?)```/)
    if (m) {
      try { return JSON.parse(m[1]) } catch {}
    }
    // 尝试提取 JSON 数组
    const arrMatch = text.match(/\[\s*\{[\s\S]*\}\s*\]/)
    if (arrMatch) {
      try { return JSON.parse(arrMatch[0]) } catch {}
    }
    throw new Error(`无法从 AI 输出中解析 JSON: ${text.slice(0, 200)}`)
  }

  private buildExecutionPrompt(task: Task, context: string): string {
    const modeInstructions = this.getModeInstructions(task.mode)
    return `${modeInstructions}\n\n${context}`
  }

  private getModeInstructions(mode: string): string {
    switch (mode) {
      case 'architect':
        return `## 模式: 架构师\n你是软件架构师。你的任务是分析和设计，不编写实现代码。\n1. 分析现有架构和设计模式\n2. 提出 2-3 个可行方案，比较其优缺点\n3. 给出推荐方案及理由\n4. 绘制关键组件和接口的关系\n不要输出具体代码实现，只输出设计文档。`
      case 'ask':
        return `## 模式: 问答\n你是技术专家。你的任务是解释和教学。\n1. 用清晰的语言解释概念\n2. 提供代码示例辅助理解\n3. 指出常见的陷阱和最佳实践\n4. 如果不确定，诚实说明\n回答要有教育意义，帮助用户真正理解。`
      case 'debug':
        return `## 模式: 调试\n你是调试专家。你的任务是找到并修复 Bug。\n1. 分析错误日志和症状\n2. 定位根因（不是表面现象）\n3. 给出最小修复方案（不要顺手重构）\n4. 解释为什么这个修复是正确的\n修复要精确，只改必要的地方，避免引入新问题。`
      case 'code':
      default:
        return `## 模式: 编码\n你是软件工程师。你的任务是编写高质量的代码。\n1. 理解需求，分析当前代码\n2. 实现功能，输出可运行的完整代码\n3. 新文件标明路径，修改标明位置\n4. 代码要安全、简洁、可维护`
    }
  }
}

export function createDefaultProvider(orion: TaskOrchestrator, shield: Shield, skills: SkillsEngine, _providerType?: string): ProviderEngine {
  return new ProviderEngine(orion, shield, skills)
}
