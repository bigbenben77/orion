// Validate orion-web.html JS
const fs = require('fs')
let c = fs.readFileSync('orion-web.html', 'utf8')

// extract JS
const ss = c.indexOf('<script>') + 8
const se = c.indexOf('</script>')
const js = c.substring(ss, se)

// Check quotes
const sq = (js.match(/'/g) || []).length
const dq = (js.match(/"/g) || []).length
const bt = (js.match(/`/g) || []).length

console.log('JS size:', js.length)
console.log("single quotes:", sq, sq % 2 === 0 ? 'OK' : 'UNPAIRED!')
console.log('double quotes:', dq, dq % 2 === 0 ? 'OK' : 'UNPAIRED!')
console.log('backticks:', bt, bt % 2 === 0 ? 'OK' : 'UNPAIRED!')
console.log('has u0027:', js.includes('u0027'))

// Find lines with html += that might have broken quoting
const lines = js.split('\n')
let problemLines = []
for (let i = 0; i < lines.length; i++) {
  const l = lines[i]
  // Count quotes on this line
  const lineSq = (l.match(/'/g) || []).length
  const lineDq = (l.match(/"/g) || []).length
  if ((lineSq + lineDq) % 2 !== 0) {
    problemLines.push({ line: i+1, text: l.trim().substring(0, 120), sq: lineSq, dq: lineDq })
  }
}

if (problemLines.length > 0) {
  console.log('\nProblem lines (odd quotes):')
  problemLines.forEach(p => {
    console.log(`  Line ${p.line}: '${p.sq}"/${p.dq} -> ${p.text}`)
  })
} else {
  console.log('\nAll lines have paired quotes')
}

// Find specific patterns
console.log('\nselectProviderForKey usage:')
const spIdx = js.indexOf('selectProviderForKey')
if (spIdx >= 0) {
  console.log(js.substring(spIdx, spIdx + 120))
}
