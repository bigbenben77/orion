// Orion Web UI 服务器 — 纯静版本
// HTML 从外部文件加载，避免模板字面量冲突

const fs = require('fs')
const path = require('path')

// 读当前的 server.ts
const file = path.join(__dirname, '..', 'src', 'web', 'server.ts')
let c = fs.readFileSync(file, 'utf8')

// 找到 generateHTML 函数末尾，替换为外部文件加载
const genStart = c.indexOf('private generateHTML()')
const genBodyStart = c.indexOf('{', genStart)
const genBodyEnd = c.indexOf('}', genBodyStart)

// 找到 generateHTML 内部的 return 模板
const retStart = c.indexOf('return', genBodyStart)
const retEnd = c.indexOf(';', retStart)

// 替换 generateHTML 函数体，改为加载外部 HTML 文件
const newGenBody = [
  'private generateHTML(): string {',
  '    try {',
  '      const htmlPath = path.join(__dirname, "..", "orion-web.html")',
  '      if (fs.existsSync(htmlPath)) {',
  '        return fs.readFileSync(htmlPath, "utf-8")',
  '      }',
  '    } catch {}',
  '    return "<html><body><h1>Orion Web UI</h1><p>Missing orion-web.html</p></body></html>"',
  '  }',
  '',
  '  private buildHTML(): string {',
  '    return this.generateHTML()',
  '  }',
].join('\n')

c = c.substring(0, genStart) + newGenBody + c.substring(genBodyEnd + 1)

fs.writeFileSync(file, c, 'utf8')
console.log('OK server.ts 已更新')
