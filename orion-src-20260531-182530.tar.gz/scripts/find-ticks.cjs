// 修复 Orion Web UI - 替换 JS 中的反引号为普通字符串拼接
const fs = require('fs')

let c = fs.readFileSync('src/web/server.ts', 'utf8')

// 找到 generateHTML() 函数体
const fnMatch = /private generateHTML\(\)[^]*?\{[^]*?\n\s+\}/.exec(c)
if (!fnMatch) {
  console.log('未找到 generateHTML')
  process.exit(1)
}

const fnBody = fnMatch[0]
// 找到反引号模板范围
const tmplStart = fnBody.indexOf('`')
const tmplEnd = fnBody.lastIndexOf('`')
if (tmplStart === -1 || tmplEnd === tmplStart) {
  console.log('未找到模板字面量')
  process.exit(1)
}

const tmpl = fnBody.substring(tmplStart + 1, tmplEnd)
console.log('模板长度:', tmpl.length)

// 检查模板内的反引号
let tickCount = 0
for (let i = 0; i < tmpl.length; i++) {
  if (tmpl[i] === '`') tickCount++
}
console.log('模板内反引号:', tickCount)

// 找到 JS 中的反引号
const lines = tmpl.split('\n')
for (let i = 0; i < lines.length; i++) {
  const line = lines[i]
  const idx = line.indexOf('`')
  if (idx !== -1) {
    console.log(`行 ${i + 1}: ${line.trim().substring(0, 100)}`)
  }
}

// 检查是否有模板插值 $
const dollarBrace = tmpl.match(/\$\{/g)
console.log('模板插值 ${} 数量:', dollarBrace ? dollarBrace.length : 0)
