// 提取 generateHTML 内容到单独 HTML 文件
const fs = require('fs')
const c = fs.readFileSync('src/web/server.ts', 'utf8')

// 找到 generateHTML 函数中的 return 模板
const genIdx = c.indexOf('private generateHTML()')
const retIdx = c.indexOf('`', c.indexOf('return', genIdx))

// 找到模板结束 - 从 retIdx+1 开始数反引号
let depth = 1
let i = retIdx + 1
while (i < c.length && depth > 0) {
  if (c[i] === '`') depth--
  else if (c[i] === '$' && c[i+1] === '{') {
    // 跳过模板插值 ${...}
    i += 2
    let braceDepth = 1
    while (i < c.length && braceDepth > 0) {
      if (c[i] === '{') braceDepth++
      else if (c[i] === '}') braceDepth--
      i++
    }
    continue
  }
  i++
}

const html = c.substring(retIdx + 1, i - 1)
fs.writeFileSync('orion-web.html', html, 'utf8')
console.log('OK 提取完成, 大小:', html.length, '字节')
console.log('模板起始:', retIdx, '模板结束:', i)
