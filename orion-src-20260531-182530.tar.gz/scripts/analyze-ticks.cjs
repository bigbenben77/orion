// 分析并修复 generateHTML 模板字面量
const fs = require('fs')
let c = fs.readFileSync('src/web/server.ts', 'utf8')

// 1. 找到 generateHTML 函数范围
const genIdx = c.indexOf('private generateHTML()')
console.log('generateHTML at:', genIdx)

// 找到 return 后面的模板字面量起始
const retBacktick = c.indexOf('`', c.indexOf('return', genIdx))
console.log('return backtick at:', retBacktick)

// 找到 generateHTML 结束的 } 
// 策略：从 retBacktick 往后找 `` 配对
let depth = 1  // 我们已经在模板内
let i = retBacktick + 1
const fileLen = c.length
let foundEnd = -1

while (i < fileLen && depth > 0) {
  if (c[i] === '`') {
    depth--
    if (depth === 0) {
      foundEnd = i
      break
    }
  } else if (c[i] === '$' && i + 1 < fileLen && c[i + 1] === '{') {
    // 模板插值 ${...} 内的反引号不计
    i += 2
    let braceDepth = 1
    while (i < fileLen && braceDepth > 0) {
      if (c[i] === '{') braceDepth++
      else if (c[i] === '}') braceDepth--
      i++
    }
    continue
  }
  i++
}

if (foundEnd === -1) {
  console.log('错误：模板字面量没有结束反引号！文件已损坏')
  // 找最后一个反引号
  const lastTick = c.lastIndexOf('`')
  console.log('最后一个反引号在:', lastTick)
  console.log('上下文:', c.substring(Math.max(0, lastTick - 30), Math.min(fileLen, lastTick + 30)))
} else {
  const tmplLen = foundEnd - retBacktick + 1
  console.log('模板字面量长度:', tmplLen)
  console.log('结束反引号在:', foundEnd)
  
  // 检查模板内部的反引号
  const inner = c.substring(retBacktick + 1, foundEnd)
  let innerTicks = 0
  let innerPositions = []
  for (let j = 0; j < inner.length; j++) {
    if (inner[j] === '`') {
      innerTicks++
      innerPositions.push(retBacktick + 1 + j)
    }
  }
  console.log('模板内部反引号:', innerTicks)
  
  if (innerTicks > 0) {
    console.log('\n位置和上下文:')
    for (let k = 0; k < Math.min(5, innerPositions.length); k++) {
      const pos = innerPositions[k]
      const start = Math.max(0, pos - 20)
      const end = Math.min(fileLen, pos + 30)
      console.log(`  ${pos}: ...${c.substring(start, end).replace(/\n/g, '\\n')}...`)
    }
    
    // 修复：替换模板内部的 JS 反引号为 \` 转义
    // 注意：不能简单 replaceAll，JS 里的 ${} 也需要处理
    // 但最简单的方式：找出所有不在模板插值内的反引号
    console.log('\n修复方案：需要将这些 JS 反引号改为字符串拼接')
  }
}
