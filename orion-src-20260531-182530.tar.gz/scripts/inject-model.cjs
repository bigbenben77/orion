// Orion — 注入模型面板 (v2)
const fs = require('fs')
const path = require('path')

const file = path.join(__dirname, '..', 'src', 'web', 'server.ts')
let c = fs.readFileSync(file, 'utf8')

// 找到 Shield 面板的起始位置
const shieldStart = c.indexOf('<h2 style="margin-bottom:4px">')

// 往前找到包含 panel div 的行
const beforeShield = c.lastIndexOf('<div class="panel"', shieldStart)

// 注入模型面板 HTML
const modelPanel = [
  '<div class="panel" style="margin-top:24px">',
  '    <h2>xxx 模型 <span id="currentModelBadge" style="font-size:12px;font-weight:400;color:var(--muted)">...</span></h2>',
  '    <div id="modelList" style="display:grid;grid-template-columns:repeat(auto-fill,minmax(220px,1fr));gap:8px;margin-top:12px">',
  '      <div class="loading"><div class="spinner"></div></div>',
  '    </div>',
  '    <div style="margin-top:12px;display:flex;gap:8px;align-items:center">',
  '      <input type="text" id="apiKeyProvider" readonly style="width:100px;padding:6px 10px;background:#1f2937;border:1px solid var(--border);border-radius:6px;color:var(--muted);font-size:13px" placeholder="click model">',
  '      <input type="password" id="apiKeyInput" placeholder="paste API key..." style="flex:1;padding:6px 10px;background:#0d1117;border:1px solid var(--border);border-radius:6px;color:var(--text);font-size:13px">',
  '      <button class="btn btn-sm btn-primary" onclick="setApiKey()">Save Key</button>',
  '      <span id="keyStatus" style="font-size:12px;color:var(--green);display:none">OK</span>',
  '    </div>',
  '  </div>',
  '',
].join('\n')

c = c.slice(0, beforeShield) + modelPanel + c.slice(beforeShield)

fs.writeFileSync(file, c, 'utf8')
console.log('OK 模型面板 HTML 已注入')
