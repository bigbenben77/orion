// Orion — 注入模型面板到 Web UI
const fs = require('fs')
const path = require('path')

const file = path.join(__dirname, '..', 'src', 'web', 'server.ts')
let c = fs.readFileSync(file, 'utf8')

// 1. 模型面板 HTML（shield 面板前）
const panelHTML = `  <!-- 模型切换面板 -->
  <div class="panel" style="margin-top:24px">
    <h2>📡 模型 <span id="currentModelBadge" style="font-size:12px;font-weight:400;color:var(--muted)">加载中...</span></h2>
    <div id="modelList" style="display:grid;grid-template-columns:repeat(auto-fill,minmax(220px,1fr));gap:8px;margin-top:12px">
      <div class="loading"><div class="spinner"></div></div>
    </div>
    <div style="margin-top:12px;display:flex;gap:8px;align-items:center">
      <input type="text" id="apiKeyProvider" readonly style="width:100px;padding:6px 10px;background:#1f2937;border:1px solid var(--border);border-radius:6px;color:var(--muted);font-size:13px" placeholder="点模型选">
      <input type="password" id="apiKeyInput" placeholder="粘贴 API Key..." style="flex:1;padding:6px 10px;background:#0d1117;border:1px solid var(--border);border-radius:6px;color:var(--text);font-size:13px">
      <button class="btn btn-sm btn-primary" onclick="setApiKey()">保存 Key</button>
      <span id="keyStatus" style="font-size:12px;color:var(--green);display:none">OK 已保存</span>
    </div>
  </div>

  <div class="panel" style="margin-top:24px;display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap">`

c = c.replace(
  '<div class="panel" style="margin-top:24px;display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap">',
  panelHTML
)

// 2. JS 函数
const modelJS = `
let _selectedProvider = null

function selectProviderForKey(id, name) {
  _selectedProvider = id
  document.getElementById('apiKeyProvider').value = name
  document.getElementById('apiKeyInput').placeholder = '粘贴 ' + id + ' 的 Key...'
  document.getElementById('keyStatus').style.display = 'none'
}

async function switchModel(id) {
  await api('/models/switch', { method: 'POST', body: JSON.stringify({ id }) })
  loadModels()
}

async function setApiKey() {
  const key = document.getElementById('apiKeyInput').value.trim()
  if (!key || !_selectedProvider) return
  await api('/models/key', { method: 'POST', body: JSON.stringify({ id: _selectedProvider, apiKey: key }) })
  document.getElementById('keyStatus').style.display = 'inline'
  document.getElementById('apiKeyInput').value = ''
  setTimeout(function() { document.getElementById('keyStatus').style.display = 'none' }, 2000)
  loadModels()
}

async function loadModels() {
  try {
    var list = await api('/models')
    var html = ''
    var activeName = ''
    for (var p of list) {
      var active = p.active ? ' style="border-color:var(--green);background:rgba(63,185,80,.08)"' : ''
      var keyIcon = p.config.apiKey ? '🔑' : '⚪'
      if (p.active) activeName = p.config.name
      html += '<div class="skill-card" style="cursor:pointer"' + active + ' onclick="selectProviderForKey(\"' + p.id + '\",\"' + p.config.name + '\");switchModel(\"' + p.id + '\")">'
      html += '<div class="skill-name">' + p.config.name + (p.active ? ' ⬅️' : '') + '</div>'
      html += '<div style="font-size:11px;color:var(--muted)">' + p.config.model + '</div>'
      html += '<div style="font-size:11px;color:var(--muted);margin-top:2px">' + keyIcon + ' ' + (p.config.apiKey ? '已设 Key' : '未设 Key') + '</div>'
      html += '</div>'
    }
    document.getElementById('modelList').innerHTML = html || '<p style="color:var(--muted)">无可用模型</p>'
    document.getElementById('currentModelBadge').textContent = activeName ? '⬅️ ' + activeName : ''
  } catch(e) { document.getElementById('modelList').innerHTML = '<p style="color:var(--red)">加载失败</p>' }
}`

// 在 loadShield 函数后注入
c = c.replace(
  'async function loadShield() {',
  modelJS + '\n\nasync function loadShield() {'
)

// 修改 loadAll 加 loadModels
c = c.replace(
  'async function loadAll() { await Promise.all([loadTasks(), loadSkills(), loadStats(), loadShield()]); const r = await api(\'/automation\'); updateAutoToggle(r.autoMode) }',
  'async function loadAll() { await Promise.all([loadTasks(), loadSkills(), loadStats(), loadShield(), loadModels()]); const r = await api(\'/automation\'); updateAutoToggle(r.autoMode) }'
)

fs.writeFileSync(file, c, 'utf8')
console.log('OK 模型面板已注入 Web UI')
