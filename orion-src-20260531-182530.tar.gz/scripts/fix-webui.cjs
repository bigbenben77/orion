// 重写 Orion Web UI 模型面板（一次性搞定）
const fs = require('fs')
let c = fs.readFileSync('src/web/server.ts', 'utf8')

// 找到模型面板区域并替换
const oldPanel = `  <!-- 保护层 -->
  <div class="panel" style="margin-top:24px">
    <h2>?? 模型 <span id="currentModelBadge" style="font-size:12px;font-weight:400;color:var(--muted)">...</span></h2>
    <div id="modelList" style="display:grid;grid-template-columns:repeat(auto-fill,minmax(220px,1fr));gap:8px;margin-top:12px">
      <div class="loading"><div class="spinner"></div></div>
    </div>
    <div style="margin-top:12px;display:flex;gap:8px;align-items:center">
      <input type="text" id="apiKeyProvider" readonly style="width:100px;padding:6px 10px;background:#1f2937;border:1px solid var(--border);border-radius:6px;color:var(--muted);font-size:13px" placeholder="click model">
      <input type="password" id="apiKeyInput" placeholder="paste API key..." style="flex:1;padding:6px 10px;background:#0d1117;border:1px solid var(--border);border-radius:6px;color:var(--text);font-size:13px">
      <button class="btn btn-sm btn-primary" onclick="setApiKey()">Save Key</button>
      <span id="keyStatus" style="font-size:12px;color:var(--green);display:none">OK</span>
    </div>
  </div>`

const newPanel = `  <!-- 模型面板 -->
  <div class="panel" style="margin-top:24px">
    <h2>xxx 模型 <span id="currentModelBadge" style="font-size:12px;font-weight:400;color:var(--muted)">...</span></h2>
    <div id="modelList" style="display:grid;grid-template-columns:repeat(auto-fill,minmax(220px,1fr));gap:8px;margin-top:12px">
      <div class="loading"><div class="spinner"></div></div>
    </div>
    <div style="margin-top:12px;display:flex;gap:8px;align-items:center">
      <div id="apiKeyHint" style="font-size:12px;color:var(--muted);padding:6px 0;flex:1">点击上方模型卡片选中，再贴 Key</div>
      <input type="password" id="apiKeyInput" placeholder="API Key..." style="flex:1;padding:6px 10px;background:#0d1117;border:1px solid var(--border);border-radius:6px;color:var(--text);font-size:13px;display:none">
      <button class="btn btn-sm btn-primary" id="saveKeyBtn" onclick="setApiKey()" style="display:none">Save</button>
      <span id="keyStatus" style="font-size:12px;color:var(--green);display:none">OK</span>
    </div>
  </div>`

if (c.includes(oldPanel)) {
  c = c.replace(oldPanel, newPanel)
  console.log('OK 面板已替换')
} else {
  // try partial match
  if (c.includes('apiKeyProvider')) {
    // just fix the emoji
    c = c.replace('<h2>?? 模型', '<h2>xxx 模型')
    c = c.replace('<h2>?? 模型', '<h2>xxx 模型')
    console.log('OK emoji 已修复')
  } else {
    console.log('未找到模型面板，检查位置...')
    const idx = c.indexOf('margin-top:24px')
    console.log('margin-top:24px 位置:', idx)
    console.log('上下文:', c.substring(Math.max(0,idx-50), idx+100))
  }
}

// 修复 loadModels 函数中的 onclick
const oldLoad = `    html += '<div class="skill-card" style="cursor:pointer"' + active + ' onclick="`
if (c.includes(oldLoad)) {
  // 替换整个 loadModels 函数
  const funcStart = c.indexOf('async function loadModels()')
  const funcEnd = c.indexOf('async function loadShield()')
  if (funcStart > 0 && funcEnd > funcStart) {
    const newFunc = [
      'async function loadModels() {',
      '  try {',
      '    var list = await api("/models")',
      '    var html = ""',
      '    var activeName = ""',
      '    for (var p of list) {',
      '      var isActive = p.active',
      '      var keyIcon = p.config.apiKey ? "key" : "no"',
      '      if (p.active) activeName = p.config.name',
      '      html += "<div class=\\"skill-card\\" style=\\"cursor:pointer\\"" + (isActive ? " style=\\"border-color:var(--green)\\"": "")',
      '      html += " data-pid=\\"" + p.id + "\\">"',
      '      html += "<div class=\\"skill-name\\">" + p.config.name + (isActive ? " active" : "") + "</div>"',
      '      html += "<div class=\\"skill-name\\" style=\\"font-size:11px;color:var(--muted);font-weight:400\\">" + p.config.model + "</div>"',
      '      html += "<div style=\\"font-size:11px;color:var(--muted)\\">" + keyIcon + " " + (p.config.apiKey ? "has key" : "no key") + "</div>"',
      '      html += "</div>"',
      '    }',
      '    document.getElementById("modelList").innerHTML = html',
      '    document.getElementById("currentModelBadge").textContent = activeName ? activeName : ""',
      '    document.querySelectorAll("#modelList .skill-card").forEach(function(el) {',
      '      el.addEventListener("click", function() {',
      '        var pid = this.getAttribute("data-pid")',
      '        document.getElementById("apiKeyHint").style.display = "none"',
      '        document.getElementById("apiKeyInput").style.display = ""',
      '        document.getElementById("saveKeyBtn").style.display = ""',
      '        document.getElementById("apiKeyInput").placeholder = "API key for " + pid',
      '        _selectedProvider = pid',
      '        switchModel(pid)',
      '      })',
      '    })',
      '  } catch(e) {',
      '    document.getElementById("modelList").innerHTML = "<p style=\\"color:var(--red)\\">error</p>"',
      '  }',
      '}',
    ].join('\n')
    
    c = c.substring(0, funcStart) + newFunc + '\n\n' + c.substring(funcEnd)
    console.log('OK loadModels 函数已替换')
  }
}

// 修复 loadAll 函数
c = c.replace(
  'async function loadAll() { await Promise.all([loadTasks(), loadSkills(), loadStats(), loadShield(), loadModels()]); const r = await api(\'/automation\'); updateAutoToggle(r.autoMode) }',
  'async function loadAll() { await Promise.all([loadTasks(), loadSkills(), loadStats(), loadShield(), loadModels()]); const r = await api("/automation"); updateAutoToggle(r.autoMode) }'
)

fs.writeFileSync('src/web/server.ts', c, 'utf8')
console.log('OK 写入完成')
