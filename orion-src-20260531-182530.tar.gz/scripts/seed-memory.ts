// Orion 记忆种子脚本
// 注入一些示例记忆让主人体验
import { MemoryManager } from '../src/memory/manager.js'
import { TaskOrchestrator } from '../src/orchestrator/index.js'

const mm = new MemoryManager()
const orion = new TaskOrchestrator()

// 从已有任务学习
for (const task of orion.getAllTasks()) {
  if (task.status === 'done' && task.attempts.length > 0) {
    mm.logDecision(
      `完成: ${task.title}`,
      `任务 ${task.id} 成功完成，尝试了 ${task.attempts.length} 次`,
      { tags: task.scope.tags, importance: 6, source: task.id }
    )
  }
  if (task.blockedReason) {
    mm.logError(
      `阻塞: ${task.title}`,
      task.blockedReason,
      { tags: task.scope.tags }
    )
  }
}

// 通用最佳实践记忆
mm.logDecision('使用 React Query 管理服务端状态', '避免重复请求，自动缓存和刷新', { tags: ['react', 'state-management'], importance: 8 })
mm.logPreference('主人喜欢 TypeScript 严格模式', '所有项目启用 strict: true')
mm.logError('忘记处理 API 超时导致页面白屏', '所有 fetch 调用加 AbortSignal.timeout()', { tags: ['api', 'error-handling', 'lesson'] })
mm.logDecision('API 端点按模块分组', 'routes/ 下按功能模块划分子目录', { tags: ['api', 'architecture'], importance: 6 })
mm.logDecision('错误处理统一中间件', '所有 API 错误通过 errorHandler 中间件统一处理', { tags: ['api', 'error-handling'], importance: 7 })

console.log('✅ 记忆种子注入完成')
console.log(JSON.stringify(mm.getStats(), null, 2))
