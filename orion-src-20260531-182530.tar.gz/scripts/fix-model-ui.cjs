// 修复 Orion Web UI 的模型面板 onclick 引号
const fs = require('fs')
let c = fs.readFileSync('src/web/server.ts', 'utf8')

// 找到 loadModels 中的 onclick 那一行，修复引号
// 旧的: onclick="selectProviderForKey(" + p.id + ... 
// 新的: onclick='selectProviderForKey(' + p.id + ...

// 方案1: 用反引号模板来构建 HTML
const oldHtml = [
  "html += '<div class=\"skill-card\" style=\"cursor:pointer\"' + active + ' onclick=\"selectProviderForKey(\"' + p.id + '\",\"' + p.config.name + '\");switchModel(\"' + p.id + '\")\">'",
  "html += '<div class=\"skill-name\">' + p.config.name + (p.active ? ' ⬅️' : '') + '</div>'",
  "html += '<div style=\"font-size:11px;color:var(--muted)\">' + p.config.model + '</div>'",
  "html += '<div style=\"font-size:11px;color:var(--muted);margin-top:2px\">' + keyIcon + ' ' + (p.config.apiKey ? '已设 Key' : '未设 Key') + '</div>'",
  "html += '</div>'",
].join('\n')

// 使用反引号模板解决引号嵌套问题
const newHtml = [
  "html += '<div class=\"skill-card\" style=\"cursor:pointer\"' + active + ' onclick=\"selectProviderForKey(\\u0027' + p.id + '\\u0027,\\u0027' + p.config.name.replace(/'/g,'') + '\\u0027);switchModel(\\u0027' + p.id + '\\u0027)\">'",
  "html += '<div class=\"skill-name\">' + p.config.name + (p.active ? ' ⬅️' : '') + '</div>'",
  "html += '<div style=\"font-size:11px;color:var(--muted)\">' + p.config.model + '</div>'",
  "html += '<div style=\"font-size:11px;color:var(--muted);margin-top:2px\">' + keyIcon + ' ' + (p.config.apiKey ? '已设 Key' : '未设 Key') + '</div>'",
  "html += '</div>'",
].join('\n')

c = c.replace(oldHtml, newHtml)

fs.writeFileSync('src/web/server.ts', c, 'utf8')
console.log('OK onclick 引号已修复')
