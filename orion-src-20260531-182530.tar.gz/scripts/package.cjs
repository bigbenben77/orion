// Orion 打包脚本
const { execSync } = require('child_process');
const fs = require('fs');
const path = require('path');

const ROOT = process.cwd();
console.log('=== Orion 打包工具 ===');

// 1. 修复 tsconfig
console.log('\n1. 配置 tsconfig...');
let tsconfig = fs.readFileSync('tsconfig.json', 'utf8');
tsconfig = tsconfig.replace('"strict": true,', '"strict": true,\n    "types": ["node"],\n    "lib": ["ES2022"],');
fs.writeFileSync('tsconfig.json', tsconfig);

// 2. 构建
console.log('2. 构建 TypeScript...');
try {
  execSync('npx tsc 2>&1', { stdio: 'pipe', cwd: ROOT });
  console.log('   OK 构建成功');
} catch (e) {
  console.log('   注意: 有编译警告，tsx 可直接运行');
}

// 3. 创建 bin 包装器
console.log('3. 创建 CLI 包装器...');
var binWrapper = '#!/usr/bin/env node\n';
binWrapper += 'import { spawn } from "node:child_process";\n';
binWrapper += 'import { fileURLToPath } from "node:url";\n';
binWrapper += 'import { dirname, join } from "node:path";\n';
binWrapper += 'var __dirname = dirname(fileURLToPath(import.meta.url));\n';
binWrapper += 'var entry = join(__dirname, "..", "src", "index.ts");\n';
binWrapper += 'var child = spawn(\n';
binWrapper += '  process.execPath,\n';
binWrapper += '  [join(__dirname, "..", "node_modules", ".bin", "tsx"), entry].concat(process.argv.slice(2)),\n';
binWrapper += '  { stdio: "inherit", windowsHide: true }\n';
binWrapper += ');\n';
binWrapper += 'child.on("exit", function(c) { process.exit(c || 1); });\n';
binWrapper += 'process.on("SIGINT", function() { child.kill("SIGINT"); });\n';
binWrapper += 'process.on("SIGTERM", function() { child.kill("SIGTERM"); });\n';

fs.mkdirSync('bin', { recursive: true });
fs.writeFileSync('bin/orion.js', binWrapper);

// 4. 更新 package.json
console.log('4. 更新 package.json...');
var pkg = JSON.parse(fs.readFileSync('package.json', 'utf8'));
pkg.bin = { 'orion': 'bin/orion.js' };
pkg.files = ['src/', 'bin/', '.orion/skills/', 'package.json', 'tsconfig.json'];
fs.writeFileSync('package.json', JSON.stringify(pkg, null, 2) + '\n');

// 5. npm pack
console.log('5. 创建 npm 包...');
try {
  execSync('npm pack 2>&1', { stdio: 'pipe', cwd: ROOT });
  var tgz = fs.readdirSync(ROOT).find(function(f) { return f.endsWith('.tgz'); });
  if (tgz) {
    var size = fs.statSync(tgz).size;
    console.log('   OK 创建: ' + tgz + ' (' + (size / 1024 / 1024).toFixed(1) + 'MB)');
  }
} catch (e) {
  console.log('   npm pack 失败: ' + e.message.slice(0, 100));
}

// 6. 创建安装脚本
console.log('6. 创建安装脚本...');

var winInstall = '';
winInstall += '# Orion 安装脚本 (Windows)\n';
winInstall += '# powershell -ExecutionPolicy Bypass -File install.ps1\n';
winInstall += '\n';
winInstall += 'Write-Host "=== Orion 安装工具 ===" -ForegroundColor Cyan\n';
winInstall += 'try { $v = node --version; Write-Host "Node.js: $v" -ForegroundColor Green }\n';
winInstall += 'catch { Write-Host "需要 Node.js >=18" -ForegroundColor Red; exit 1 }\n';
winInstall += 'npm install\n';
winInstall += 'npm link\n';
winInstall += 'Write-Host "Orion 安装完成!" -ForegroundColor Green\n';

var linuxInstall = '';
linuxInstall += '#!/bin/bash\n';
linuxInstall += 'set -e\n';
linuxInstall += 'echo "=== Orion 安装工具 ==="\n';
linuxInstall += 'if ! command -v node &> /dev/null; then\n';
linuxInstall += '  echo "需要 Node.js >=18"; exit 1; fi\n';
linuxInstall += 'echo "Node.js: $(node --version)"\n';
linuxInstall += 'npm install --silent\n';
linuxInstall += 'npm link\n';
linuxInstall += 'echo "Orion 安装完成!"\n';

fs.writeFileSync('install.ps1', winInstall);
fs.writeFileSync('install.sh', linuxInstall);
try { fs.chmodSync('install.sh', '755'); } catch(e) {}

console.log('   OK install.ps1');
console.log('   OK install.sh');

// 7. 创建压缩包
console.log('7. 创建压缩包...');
var ver = pkg.version || '0.1.0';
if (process.platform === 'win32') {
  try {
    execSync('powershell -Command "Compress-Archive -Path \'' + ROOT + '\\*\' -DestinationPath \'' + ROOT + '\\..\\orion-v' + ver + '.zip\' -Force" 2>&1', { stdio: 'pipe' });
    console.log('   OK orion-v' + ver + '.zip');
  } catch (e) {
    console.log('   zip 失败, 尝试 tar: ' + e.message.slice(0, 60));
    try {
      execSync('tar -czf "' + ROOT + '/../orion-v' + ver + '.tar.gz" -C "' + ROOT + '" . 2>&1', { stdio: 'pipe' });
      console.log('   OK orion-v' + ver + '.tar.gz');
    } catch (e2) {
      console.log('   压缩失败: ' + e2.message.slice(0, 80));
    }
  }
} else {
  try {
    execSync('tar -czf "' + ROOT + '/../orion-v' + ver + '.tar.gz" -C "' + ROOT + '" . 2>&1', { stdio: 'pipe' });
    console.log('   OK orion-v' + ver + '.tar.gz');
  } catch (e) {
    console.log('   压缩失败: ' + e.message.slice(0, 80));
  }
}

// 8. 摘要
console.log('\n=== 打包完成 ===');
console.log('npm 包: orion-' + ver + '.tgz');
console.log('压缩包: orion-v' + ver + (process.platform === 'win32' ? '.zip' : '.tar.gz') + ' (在上级目录)');
console.log('安装:   npm install -g orion-*.tgz');
