// 重写 Orion Web UI - 完整修复 generateHTML 模板字面量
// 根因：JS 代码中的反引号与 TypeScript 模板字面量冲突

const fs = require('fs')
let c = fs.readFileSync('src/web/server.ts', 'utf8')

// 1. 找到旧 generateHTML 的返回值范围
const fnStart = c.indexOf('private generateHTML()')
const fnEnd = c.indexOf('}', fnStart + 100)
const retStart = c.indexOf('return `', fnStart)
const retEnd = c.lastIndexOf('`;')
if (retEnd === -1) {
  // 模板字面量已经坏了，搜索最后一个 `; 模式
  const lastTick = c.lastIndexOf('`')
  console.log('最后一个反引号位置:', lastTick)
  console.log('上下文:', c.substring(lastTick - 20, lastTick + 20))
  process.exit(1)
}

// 提取旧的 JS 部分（找 </script> 前面的内容）
const scriptEnd = c.lastIndexOf('</script>')
const beforeScript = c.substring(0, scriptEnd)
const lastStyle = beforeScript.lastIndexOf('</style>')
const htmlBodyStart = c.indexOf('<body>', lastStyle)
const htmlBodyEnd = scriptEnd

const oldBody = c.substring(htmlBodyStart, htmlBodyEnd)
console.log('旧 HTML body 长度:', oldBody.length)

// 2. 新 HTML body - 把 JS 代码中的反引号全部替换为 \`
const newBody = oldBody
  .replace(/`/g, '\\`')  // 转义所有反引号
  .replace(/\${/g, '\\${') // 转义所有模板插值

// 3. 替换
c = c.substring(0, htmlBodyStart) + newBody + c.substring(htmlBodyEnd)

fs.writeFileSync('src/web/server.ts', c, 'utf8')
console.log('OK 反引号已转义')
